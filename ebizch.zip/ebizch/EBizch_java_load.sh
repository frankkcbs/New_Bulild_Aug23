#!/bin/sh
printf "Enter Username: "
stty -echo
read UserName1
export UserName1;
printf "\nEnter $UserName1 password: "
stty -echo
read Password1
export Password1;
printf "\nEnter APPS Database Host: "
stty -echo
read DbIp
export DbIp;
printf "\nEnter Sid: "
stty -echo
read Sid
export Sid;
printf "\nEnter  Port: "
stty -echo
read Port
export Port; 
export dwldPath=$JAVA_TOP/ebizch/oracle/apps/fnd/dwld/webui/;
export IerPath=$JAVA_TOP/ebizch/oracle/apps/fnd/ier/webui/;
export PmrPath=$JAVA_TOP/ebizch/oracle/apps/fnd/pmr/webui/;
export UpldPath=$JAVA_TOP/ebizch/oracle/apps/fnd/upld/webui/;
export QuickCodePath=$JAVA_TOP/ebizch/oracle/apps/fnd/quickcode/webui/;
export CommPath=$JAVA_TOP/ebizch/oracle/apps/fnd/comm/webui/;
export ArinvPath=$JAVA_TOP/ebizch/oracle/apps/fnd/arinv/webui/;
export RtSyncPath=$JAVA_TOP/ebizch/oracle/apps/fnd/rtsync/webui/;
export setupPath=$JAVA_TOP/ebizch/oracle/apps/fnd/setup/webui/;
java oracle.jrad.tools.xml.importer.XMLImporter $dwldPath"EbizChargeInboundDataPG.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $dwldPath"EbizchWltTransHistPG.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $IerPath"EbizChReqBulkEmailPayPG4.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $PmrPath"EbizChRequestPayAll.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $RtSyncPath"EbizCh_WLT_Pre_Auth_Tbl.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $RtSyncPath"EbizChWltCreditCardPG.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $RtSyncPath"EbizChWltPrePayment.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $ArinvPath"EbizChargeARInvWoSo.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $ArinvPath"EbizChCaptureInvoicesPG.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"
java oracle.jrad.tools.xml.importer.XMLImporter $PmrPath"EbizChargeRequestPayMethodPG.xml" -rootdir $JAVA_TOP -username $UserName1 -password $Password1 -dbconnection "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=$DbIp)(PORT=$Port))(CONNECT_DATA=(SERVICE_NAME=$Sid)))"