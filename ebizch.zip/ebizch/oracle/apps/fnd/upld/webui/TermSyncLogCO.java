 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import java.sql.CallableStatement;
 import java.sql.SQLException;



 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;


 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;
 import ebizch.oracle.apps.fnd.upld.server.PayTermsVO_LogImpl;
 import ebizch.oracle.apps.fnd.upld.server.PayTermsVO_LogRowImpl;

import java.sql.Types;


/**
 * Controller for ...
 */
 public class TermSyncLogCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initPayTermsSyncVOLog();
   }

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processFormRequest(pageContext, webBean);
         
       if (pageContext.getParameter("PayTermsBtnSave") != null) {
  int success_count = 0;
                  int error_count = 0;
                 EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
                 PayTermsVO_LogImpl PayTermsVo = am.getPayTermsVOLog();
                 PayTermsVO_LogRowImpl PayTermsRowVo = null;
                 String excCollectAdd = " ";
                 Boolean PayTermStatus = false; 
         
                 
                 Row rows[] = PayTermsVo.getFilteredRows("ViewAttr", "Y");
                 int rowsLength = rows.length;


                 if (rowsLength > 0) {
                     for (int i = 0; i < rowsLength; i++) {
                         PayTermsRowVo = (PayTermsVO_LogRowImpl) rows[i];
             
                         Number TermId = (Number) PayTermsRowVo.getAttribute("TermId");
                         String TermsIdString = TermId.toString();
                      
                         
                         String TermsNameString = (String) PayTermsRowVo.getAttribute("Name");
                       
                         
                         String TermsDescString = (String) PayTermsRowVo.getAttribute("Description");
                       
                         
                          String StatusString = (String) PayTermsRowVo.getAttribute("InUse");
                                         String checkActStatus = "Active"; 
                                           if(StatusString.equals(checkActStatus)){
                                               PayTermStatus = true;
                                           }
                                           else{
                                               PayTermStatus = false;
                                           }
                                       
                       String[]term= createTerm(pageContext, webBean, TermsIdString,TermsNameString,TermsDescString,"","","");
                                               
                                                if (term[0]!="E" || !term[0].equals("E"))
                                                                               {
                                                                               excCollectAdd = excCollectAdd + "Success: The PayTerm "+TermsNameString+" ("+TermsDescString+") has been synced to EbizCharge.";
                                                                               success_count++;       
                                                                                am.initPayTermsSyncVOLog();
                                                                               }
                                                                               else
                                                                               {
                                                                               
                                                                                   excCollectAdd = excCollectAdd + " Error: The PayTerm "+TermsNameString+" ("+TermsDescString+") has not synced in EbizCharge.";
                                                                                                                    error_count++;
                                                                                     am.initPayTermsSyncVOLog();
                                                                               
                                                                               
                                                                               
                                                                               }    
                                         
                         
                     
                   }
                                          if(success_count ==  1 ){
              throw new OAException(excCollectAdd, OAException.INFORMATION);
                          }
                          
                          if(error_count == 1 ){
              throw new OAException(excCollectAdd, OAException.INFORMATION);
                          }
                          
                          if(success_count > 1 && error_count < 1){
                                  throw new OAException("Success: "+ success_count +" items has synced in EBizCharge.", OAException.INFORMATION);
                          }
                          
                          if(success_count < 1 && error_count > 1){
                                  throw new OAException("Error: "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
                          }
                          
                          if(success_count > 1 && error_count > 1){
                                  throw new OAException("Success: "+ success_count +" items has synced in EBizCharge but the "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
                          }
                                   
                 } 
                 else {
                       throw new OAException("No Rows Selected: "+rowsLength +". ", OAException.ERROR);
                 }
                 
                
             throw new OAException(excCollectAdd, OAException.INFORMATION);
             }
       super.processFormRequest(pageContext, webBean);

   }
     public String[] createTerm(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String termId,String termName,String termDesc,String NetDueInDays,String DiscountPercentage,String DiscountIfPaidWithinDays){
                           String[] sendInvDetails = new String[2]; 
                           CallableStatement sendtermDetails;
                           try {
                                 OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                                 sendtermDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_terms(:1,:2,:3,:4,:5,:6,:7,:8); end;",
                                                         OADBTransaction.DEFAULT);
                                                 
                                                 
                                                       
                                                sendtermDetails.setString(1, termId);
                                                sendtermDetails.setString(2, termName);
                                                sendtermDetails.setString(3, termDesc);
                                                sendtermDetails.setString(4, NetDueInDays);
                                               sendtermDetails.setString(5, DiscountPercentage);
                                                  sendtermDetails.setString(6, DiscountIfPaidWithinDays);
                                                 sendtermDetails.registerOutParameter(7, Types.VARCHAR);
                                                 sendtermDetails.registerOutParameter(8, Types.VARCHAR);
                                                                                     
                                                sendtermDetails.execute();
                                                 
                                                 sendInvDetails[0] = sendtermDetails.getString(7);
                                                 sendInvDetails[1] = sendtermDetails.getString(8);
                                                                                     
                                                 sendtermDetails.close();   
                                                 
                             } catch (SQLException e) {
                                 throw new OAException("Error While creating the term into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                             }
                                         
                                         return sendInvDetails;
               }      
 }
