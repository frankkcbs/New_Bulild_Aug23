 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import java.sql.CallableStatement;
 import java.sql.SQLException;


 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;

 import ebizch.oracle.apps.fnd.upld.server.PayTermsVOImpl;
 import ebizch.oracle.apps.fnd.upld.server.PayTermsVORowImpl;
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

import java.sql.Types;

/**
 * Controller for ...
 */
 public class TermSyncCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initPayTermsSyncVO();
   }

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processFormRequest(pageContext, webBean);

       if (pageContext.getParameter("PayTermsBtnSave") != null) {
  int success_count = 0;
                  int error_count = 0;
                 EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
                 PayTermsVOImpl PayTermsVo = am.getPayTermsVO1();
                 PayTermsVORowImpl PayTermsRowVo = null;
                 String excCollectAdd = " ";
                 Boolean PayTermStatus = false;
                 String messageValue="";
                 Row rows[] = PayTermsVo.getFilteredRows("ViewAttr", "Y");
                 int rowsLength = rows.length;

                 if (rowsLength > 0) {
                     for (int i = 0; i < rowsLength; i++) {
                         PayTermsRowVo = (PayTermsVORowImpl) rows[i];

                         Number TermId = (Number) PayTermsRowVo.getAttribute("TermId");
                         String TermsIdString = TermId.toString();

                        String TermsNameString = (String) PayTermsRowVo.getAttribute("Name");

                        String TermsDescString = (String) PayTermsRowVo.getAttribute("Description");

                        String StatusString = (String) PayTermsRowVo.getAttribute("InUse");
						//String DueDaysString 	=  (String) PayTermsRowVo.getAttribute("DueDays");
                        Number DueDays = (Number) PayTermsRowVo.getAttribute("DueDays");//DueDays
											
                                         String checkActStatus = "Active";
                                           if(StatusString.equals(checkActStatus)){
                                               PayTermStatus = true;
                                           }
                                           else{
                                               PayTermStatus = false;
                                           }


                       String[] validationsMessage = isValidate(TermsIdString,TermsNameString,TermsDescString,  DueDays);

                       if (validationsMessage[0].equals("1")) {
                         messageValue = messageValue + validationsMessage[1];
                       }
                           /*New Code by hamza*/
                       if (validationsMessage[0].equals("1")){
                          error_count++;
						   throw new OAException("Data Is not Validated due to Term id / due days / term name, ", OAException.ERROR);
                       }
                       else{

                          String[]term= createTerm(pageContext, webBean, TermsIdString,TermsNameString,TermsDescString,DueDays.toString(),"","");

                           if (term[0]!="E" || !term[0].equals("E"))
                                                          {
                                                          excCollectAdd = excCollectAdd + "Success: The PayTerm "+TermsNameString+" ("+TermsDescString+") has been synced to EbizCharge.";
                                                          success_count++;
                                                           am.initPayTermsSyncVO();
                                                          }
                                                          else
                                                          {

                                                              excCollectAdd = excCollectAdd + " Error: The PayTerm "+TermsNameString+" ("+TermsDescString+") has not synced in EbizCharge.";
                                                                                               error_count++;
                                                                am.initPayTermsSyncVO();



                                                          }
                       }

                   }
                                          if(success_count ==  1 ){
                                                  am.initPayTermsSyncVO();
              throw new OAException(excCollectAdd, OAException.INFORMATION);

                          }

                          if(error_count == 1 ){
                                  am.initPayTermsSyncVO();
                                                                   throw new OAException(excCollectAdd, OAException.ERROR);

                          }

                          if(success_count > 1 && error_count < 1){
                                  am.initPayTermsSyncVO();
                                  throw new OAException("Success: "+ success_count +" items has synced in EBizCharge.", OAException.INFORMATION);
                          }

                          if(success_count < 1 && error_count > 1){
                                  am.initPayTermsSyncVO();
                             throw new OAException("Error: "+ error_count +" items has not synced in EBizCharge." , OAException.ERROR);
                          }

                          if(success_count > 1 && error_count > 1){
                                  am.initPayTermsSyncVO();
                              throw new OAException("Success: "+ success_count +" items has synced in EBizCharge but the "+ error_count +" items has not synced in EBizCharge.", OAException.WARNING);
                          }

                 }
                 else {
                       throw new OAException("No Rows Selected: ", OAException.ERROR);
                 }
                 am.initPayTermsSyncVO();

             throw new OAException(excCollectAdd, OAException.INFORMATION);
             }
       super.processFormRequest(pageContext, webBean);

   }
     public String[] createTerm(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String termId,String termName,String termDesc,String NetDueInDays,String DiscountPercentage,String DiscountIfPaidWithinDays){
                       String[] sendInvDetails = new String[2];
                       CallableStatement sendtermDetails;
                       try {
                             OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                             sendtermDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_terms(:1,:2,:3,:4,:5,:6,:7,:8); end;",
                                                     OADBTransaction.DEFAULT);



                                            sendtermDetails.setString(1, termId);
                                            sendtermDetails.setString(2, termName);
                                            sendtermDetails.setString(3, termDesc);
                                            sendtermDetails.setString(4, NetDueInDays);
                                           sendtermDetails.setString(5, DiscountPercentage);
                                              sendtermDetails.setString(6, DiscountIfPaidWithinDays);
                                             sendtermDetails.registerOutParameter(7, Types.VARCHAR);
                                             sendtermDetails.registerOutParameter(8, Types.VARCHAR);

                                            sendtermDetails.execute();

                                             sendInvDetails[0] = sendtermDetails.getString(7);
                                             sendInvDetails[1] = sendtermDetails.getString(8);

                                             sendtermDetails.close();

                         } catch (SQLException e) {
                             throw new OAException("Error While creating the term into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                         }

                                     return sendInvDetails;
           }
     public String[] isValidate(String termId,String termName,String termDesc , Number DueDays ) {
       String retMessage = "";
       String retValue = "null";
       String[] output = new String[2];
       output[0] = "0";
       if ("null".equals(String.valueOf(termId))) {
         retMessage = retMessage + "Term Id,";
       }

       if ("null".equals(String.valueOf(termName))) {
         retMessage = retMessage + "Term Name,";
       }
	   if ("null".equals(DueDays)) {
       retMessage = retMessage + "Due Days,";
                                
        }

      /* if ("null".equals(String.valueOf(orclPayTermsObj.getTermsDescription())) || String.valueOf(orclPayTermsObj.getTermsDescription()) == null) {
         retMessage = retMessage + "Description,";
       }*/


       if (retMessage != "" ) {//||  !"".equals(String.valueOf(retMessage)) || !"null".equals(String.valueOf(retMessage))
         output[0] = "1";
         retValue = retMessage + " are not found against your selected Term Id" + " : " + termId;
         output[1] = retValue;
       } else if (retMessage=="" ) {
         output[0] = "0";
         output[1] = "Terms data is validated.";
       }
       return output;
     }
 }
