 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

import ebizch.oracle.apps.fnd.setup.webui.EbizChargeOrclTokenCall;

import java.math.BigDecimal;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;


 import oracle.jbo.Row;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;

 import ebizch.oracle.apps.fnd.upld.server.SOSyncVOImpl;
 import ebizch.oracle.apps.fnd.upld.server.SOSyncVORowImpl;

import java.sql.CallableStatement;

import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;


/**
 * Controller for ...
 */
 public class SOSyncLogCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
     String insideCalls = "Call: ";

   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initSOSyncVOLog();
   }

  
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       if (pageContext.getParameter("custSOSaveBtn1") != null) {
		    int success_count = 0;
		 int error_count = 0;
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       SOSyncVOImpl soVo = am.getSOSyncVO1();
       SOSyncVORowImpl soRowVo = null;
     
       String excCollectAdd = " ";
       String excCollectUp = "Updated: ";
       String testing = "";
       
     
       Row rows[] = soVo.getFilteredRows("ViewAttr", "Y");
       int rowsLength = rows.length;

       if (rowsLength > 0) {
           for (int i = 0; i < rowsLength; i++) {
               soRowVo = (SOSyncVORowImpl) rows[i];

               
               Number soCustId = (Number) soRowVo.getAttribute("CustomerId");
               String soCustIdStr = soCustId.toString() ;
               //int soCustIdInt = soCustId.intValue();
               //soObj.setSoCustomerId(soCustIdStr);
               
               Number soOrgId = (Number) soRowVo.getAttribute("Orgid");
               String soOrgIdStr = soOrgId.toString();
               
               String soOUname = (String) soRowVo.getAttribute("Ouname");            
               
               String soInvorg = (String) soRowVo.getAttribute("Invorg");
                
                             
               String CustNoString = (String) soRowVo.getAttribute("CustomerNumber");

               Number soOrdNum = (Number) soRowVo.getAttribute("SalesOrderNumber");
               
               
               String soOrdNumStr = soOrdNum.toString() ;
        
               int soOrdNumInt = soOrdNum.intValue();
               String soPoNum = (String) soRowVo.getAttribute("CustPoNumber");
               String soCustomerName = (String) soRowVo.getAttribute("CustomerName");
           
               
               Number soTaxAmt = (Number) soRowVo.getAttribute("TotalTaxAmount");
               String soTaxAmtStr = soTaxAmt.toString();
               BigDecimal soTaxAmtBD = new BigDecimal(soTaxAmtStr);
               int soTaxAmtInt = soTaxAmt.intValue();            
               
               
               Number soAmt = (Number) soRowVo.getAttribute("TotOrderAmt");
               String soAmtStr = soAmt.toString();
               BigDecimal soAmtBD = new BigDecimal(soAmtStr);
               int soAmtInt = soAmt.intValue();
               
               Number soAmtDue = (Number) soRowVo.getAttribute("Amountdue");
               String soAmtDueStr = soAmtDue.toString();
               BigDecimal soAmtDueBD = new BigDecimal(soAmtDueStr);
               int soAmtDueInt = soAmtDue.intValue();
               
               Date sodate = (Date) soRowVo.getAttribute("OrderedDate");
               String sodateStr = sodate.toString();
               
               Date soShipDate = (Date) soRowVo.getAttribute("OrderedDate");
               String soShipDateStr = soShipDate.toString();              

               
               String soShipVia = (String) soRowVo.getAttribute("ShipVia");

               
               String soCurr = (String) soRowVo.getAttribute("Currency");
               
               Number soInvoiceTo = (Number) soRowVo.getAttribute("InvoiceToOrgId");
               String soInvoiceToStr = soInvoiceTo.toString() ;
               int soInvoiceToInt = soInvoiceTo.intValue();
               
               Number soShipTo = (Number) soRowVo.getAttribute("ShipToOrgId");
               String soShipToStr = soShipTo.toString() ;
               int soShipToInt = soShipTo.intValue();
              
         
               String[] sendinv=sendSaleOrder(pageContext, webBean, CustNoString,soOrdNumStr,soInvorg);
                            
                            if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                                                           {
                                                               excCollectAdd =  excCollectAdd + " Success: SaleOrder " + soOrdNumStr + " have synced to EBizCharge.";
                                                               success_count++;
                                                                am.initSOSyncVOLog();
                                                            } 
                                                            else
                                                            {
                                                                excCollectAdd = 
                                                                        excCollectAdd + " Error: SaleOrder " + 
                                                                        soOrdNumStr + 
                                                                        " have synced to EBizCharge.";
                                                                error_count++;
                                                                am.initSOSyncVOLog();
                                                            
                                                            }
                                                            
             
           }
		   	 if(success_count ==  1 ){
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(error_count == 1 ){
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(success_count > 1 && error_count < 1){
				 throw new OAException("Success: "+ success_count +" sale order  has synced in EBizCharge.", OAException.INFORMATION);
			 }
			 
			 if(success_count < 1 && error_count > 1){
				 throw new OAException("Error: "+ error_count +" sale order  has not synced in EBizCharge.", OAException.ERROR);
			 }
			 
			 if(success_count > 1 && error_count > 1){
				 throw new OAException("Success: "+ success_count +" sale order has synced in EBizCharge but the "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
			 }
               
           
       }
           
              throw new OAException(excCollectAdd, OAException.INFORMATION);
       }
       
       
     super.processFormRequest(pageContext, webBean);
   }
     public String[] sendSaleOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId){
                         String[] sendInvDetails = new String[2]; 
                         CallableStatement sendInvoiceDetails;
                         try {
                               OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                               sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.send_saleorder(:1,:2,:3,:4,:5); end;",
                                                       OADBTransaction.DEFAULT);
                                               
                                               
                                                     
                                              sendInvoiceDetails.setString(1, custNum);
                                              sendInvoiceDetails.setString(2, inSO);
                                              sendInvoiceDetails.setString(3, orgId);
                                               sendInvoiceDetails.registerOutParameter(4, Types.VARCHAR);
                                               sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                                                                   
                                              sendInvoiceDetails.execute();
                                               
                                               sendInvDetails[0] = sendInvoiceDetails.getString(4);
                                               sendInvDetails[1] = sendInvoiceDetails.getString(5);
                                                                                   
                                               sendInvoiceDetails.close();   
                                               
                           } catch (SQLException e) {
                               throw new OAException("Error While Sending the saleorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                           }
                                       
                                       return sendInvDetails;
             }
      
  
 }
