 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

 import java.sql.CallableStatement;

 import java.sql.SQLException;
 import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.apps.fnd.framework.OAException;


 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;

 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;
 import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
 import oracle.jbo.RowSetIterator;

 import ebizch.oracle.apps.fnd.upld.server.EbizchRefundsImpl;
 import ebizch.oracle.apps.fnd.upld.server.EbizchRefundsRowImpl;
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

 /**
  * Controller for ...
  */
 public class EbizchrefundsCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");


   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = 
           (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
       am.initEbizchRefunds();
           
   }

   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {

           String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
         
         if("SelectAll".equals(eventParam)) {
                         EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
             EbizchRefundsImpl refundsVo = am.getEbizchRefunds();
             RowSetIterator rowSetIterator = refundsVo.createRowSetIterator("TestIter");
             rowSetIterator.reset();
             while (rowSetIterator.hasNext()){
                 Row row = rowSetIterator.next();
                 row.setAttribute("ViewAttr","Y");
             }
             rowSetIterator.closeRowSetIterator();
         }
                 
         else if ("SelectNone".equals(eventParam)){
                         EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
             EbizchRefundsImpl refundsVo = am.getEbizchRefunds();
             int rowCount = refundsVo.getRowCount();
             RowSetIterator rowSetIterator = refundsVo.createRowSetIterator("TestIter"); 
             rowSetIterator.setRangeStart(0); 
             rowSetIterator.setRangeSize(rowCount);
             for (int i = 0; i < rowCount; i++) {
                 Row row = rowSetIterator.getRowAtRangeIndex(i); 
                 row.setAttribute("ViewAttr","N");
             }
             rowSetIterator.closeRowSetIterator();
         }   
      
       if (pageContext.getParameter("RefundsSync") != null) {
           String orderNumber= "";
           String refNum ="";
           String orclCustNum = "";
           Number amountApplied ;
           String amountAppliedstr = "";
           String customerNo="";
           String authCode="";
           String refundStatus = "";
           String messageValue="";
		   String receiptNo ="";
           int error_count = 0;
           EbizChUpldAMImpl am = 
               (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
           
           EbizchRefundsImpl  refunds = am.getEbizchRefunds();
           EbizchRefundsRowImpl refundsRow = null;
              
           Row rows[] = refunds.getFilteredRows("ViewAttr", "Y");
           int rowsLength = rows.length;
           if (rowsLength > 0) {
           for (int i = 0; i < rowsLength; i++) {
             refundsRow = (EbizchRefundsRowImpl)rows[i];
             customerNo = (String)refundsRow.getAttribute("CustomerNumber");
             String customerName = (String)refundsRow.getAttribute("CustomerName");
              receiptNo = (String)refundsRow.getAttribute("ReceiptNumber");
             String origReceiptNo = (String)refundsRow.getAttribute("OrigReceiptNo");          
             refNum = (String)refundsRow.getAttribute("Prepaymentrefnum");
          
          /* if (true)
           {               throw new OAException("refNum " +refNum, OAException.INFORMATION);
                       } */
              authCode = (String)refundsRow.getAttribute("Prepaymentauthcode");
              amountApplied = (Number)refundsRow.getAttribute("AmountApplied");    
              amountAppliedstr =  amountApplied.toString();
              orderNumber = (String)refundsRow.getAttribute("PaymentSystemOrderNumber");      
              
             if (customerNo!=null)  { 
             }
             else {throw new OAException("CustomerNo is null " + customerNo , OAException.ERROR); }
           
           String[] validationsMessage = isValidate(customerNo, customerName, refNum,authCode, amountAppliedstr, orderNumber);

           if (validationsMessage[0].equals("1")) {
             messageValue = messageValue + validationsMessage[1];
           }
               /*New Code by hamza*/
           if (validationsMessage[0].equals("1")){
              error_count++; 
           }
           else{
			    
             String getrefnum = refNum;
             String[]  refund= runTransaction(pageContext, webBean,orderNumber,amountAppliedstr,refNum,authCode,customerNo, receiptNo, origReceiptNo);
			 /*if (true)
			 {
				 throw new OAException (refund[0],OAException.ERROR);
				 
			 }*/
                     if (refund[0].equals("S")) //(!refund[0].equals("E") || refund[0]!="E" )
                         {
                         
						if (refundStatus.equals("")){
                          refundStatus =  "Success: Refund for Receipt "+ receiptNo+" was uploaded to EBizCharge.";
						  // EbizChUpldAMImpl am = (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
							am.initEbizchRefunds();                                               
											   }
                          else{
                          refundStatus =  refundStatus +" , " + receiptNo; 
                                                  }
                          
                           
                       }
                           else{
							   am.initEbizchRefunds();
                               throw new OAException("Response " + refund[0]+ ",  Error: "+ refund[1]+ " Receipt Number: "+receiptNo, OAException.ERROR);
                              
							  
                           }  
           }
       }
       }
         if (true){super.processRequest(pageContext, webBean);
         if (messageValue!="")
         {
			 am.initEbizchRefunds();
             throw new OAException("Error : Refund for Receipt "+ receiptNo+" was not uploaded to EBizCharge. Beacuse " + messageValue  , OAException.ERROR);
			 
         }
         else{
             throw new OAException(refundStatus, OAException.INFORMATION);
         }
                           } 
       }
       EbizChUpldAMImpl am = 
           (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
       am.initEbizchRefunds();
           super.processFormRequest(pageContext, webBean);
   }
     public String[] runTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSO,String inamt,String inrefnum,String authcode,String customerno,String receiptNo,String origReceiptNo){
                  String[] runTransDetails = new String[2]; 
                  CallableStatement stmtTransAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtTransAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_refunds_pkg.run_transaction(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                                                OADBTransaction.DEFAULT);
                                        
                                        stmtTransAddDetails.setString(1, inSO);
                                                                            stmtTransAddDetails.setString(2, inamt);
                                                                            stmtTransAddDetails.setString(3, inrefnum);
                                                                            stmtTransAddDetails.setString(4, authcode);
                                                                            stmtTransAddDetails.setString(5, customerno);
                                                                            stmtTransAddDetails.setString(6, receiptNo);
                                                                            stmtTransAddDetails.setString(7, origReceiptNo);
                                                                            stmtTransAddDetails.registerOutParameter(8, Types.VARCHAR);
                                        stmtTransAddDetails.registerOutParameter(9, Types.VARCHAR);
                                                                            
                                        stmtTransAddDetails.execute();
                                        
                                        runTransDetails[0] = stmtTransAddDetails.getString(8);
                                        runTransDetails[1] = stmtTransAddDetails.getString(9);
                                                                            
                                        stmtTransAddDetails.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Error While Capturing the Transaction Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }
                                
                                return runTransDetails;
      } 
     public String[] isValidate(String CustomerNo,String CustomerName,String RefNum,String authCode,String amountAppliedstr,String orderNumber) {
       String retMessage = "";
       String retValue = "null";
       String[] output = new String[2];
       output[0] = "0";
       if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
         retMessage = retMessage + "Customer No,";
       }

       if ("null".equals(String.valueOf(CustomerName)) || "".equals(String.valueOf(CustomerName))) {
         retMessage = retMessage + "Customer Name,";
       }

       if ("null".equals(String.valueOf(RefNum)) || "".equals(String.valueOf(RefNum))) {
         retMessage = retMessage + "Reference Number,";
       }

       if ("null".equals(String.valueOf(authCode)) || "".equals(String.valueOf(authCode))) {
         retMessage = retMessage + "Auth Code,";
       }
       /*if ("null".equals(String.valueOf(orderNumber)) || "".equals(String.valueOf(orderNumber))) {
         retMessage = retMessage + "Order Number,";
       }*/
       
       if (retMessage!="") {
         output[0] = "1";
         retValue = retMessage + "are not found against your selected Customer No" + " : " + CustomerNo + " . ";
         output[1] = retValue;
       } else if (retMessage=="") {

         output[0] = "0";
         output[1] = "Data is validated.";
       }
       return output;
     }

     
 }
