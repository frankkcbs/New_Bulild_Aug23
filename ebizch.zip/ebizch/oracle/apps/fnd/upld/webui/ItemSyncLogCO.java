 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;



import java.math.BigDecimal;

import java.sql.CallableStatement;
import java.sql.SQLException;

 import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;
 import oracle.jbo.domain.Date;
 import oracle.jbo.domain.Number;

 
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;
 import ebizch.oracle.apps.fnd.upld.server.OneItemSyncImpl;
 import ebizch.oracle.apps.fnd.upld.server.OneItemSync_logImpl;
 import ebizch.oracle.apps.fnd.upld.server.OneItemSync_logRowImpl;
import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

import java.sql.Types;

import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
 import oracle.jbo.RowSetIterator;

 /**
  * Controller for ...
  */
 public class ItemSyncLogCO extends OAControllerImpl
 {

   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initOneItemSync_log1();
   }

   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
	   
		String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
        
        if("SelectAll".equals(eventParam)) {
			EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
            OneItemSyncImpl itemVo = am.getOneItemSync1();
            RowSetIterator rowSetIterator = itemVo.createRowSetIterator("TestIter");
            rowSetIterator.reset();
            while (rowSetIterator.hasNext()){
                Row row = rowSetIterator.next();
                row.setAttribute("ViewAttr","Y");
            }
            rowSetIterator.closeRowSetIterator();
        }
		
        else if ("SelectNone".equals(eventParam)){
			EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
            OneItemSyncImpl itemVo = am.getOneItemSync1();
            int rowCount = itemVo.getRowCount();
            RowSetIterator rowSetIterator = itemVo.createRowSetIterator("TestIter"); 
            rowSetIterator.setRangeStart(0); 
            rowSetIterator.setRangeSize(rowCount);
            for (int i = 0; i < rowCount; i++) {
                Row row = rowSetIterator.getRowAtRangeIndex(i); 
                row.setAttribute("ViewAttr","N");
            }
            rowSetIterator.closeRowSetIterator();
        }
		
       if (pageContext.getParameter("itemSyncSaveBtn") != null) {
         int success_count = 0;
		 int error_count = 0;
		 String Nemo = "";
         String excCollectAdd = " ";
         //String excCollectUp = "Updated: ";
         Boolean itemStatus = false;
         Boolean itemTaxStatus = false;
           EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
           OneItemSync_logImpl itemVo = am.getOneItemSync_log1();
           OneItemSync_logRowImpl itemRowVo = null;

           Row rows[] = itemVo.getFilteredRows("ViewAttr", "Y");
           int rowsLength = rows.length;

           if (rowsLength > 0) {
               for (int i = 0; i < rowsLength; i++) {
                   itemRowVo = (OneItemSync_logRowImpl) rows[i];


                   Number itemId = (Number) itemRowVo.getAttribute("ItemId");
                   String itemIdStr = itemId.toString() ;
                   int itemIdInt = itemId.intValue();
                   
                   String itemDesc = (String) itemRowVo.getAttribute("ItemName");
                   String itemName = (String) itemRowVo.getAttribute("ItemName");
                   
                   Date itemCreationDate = (Date) itemRowVo.getAttribute("CreationDate");
                   
                   
                   Number itemQtyOnHand = (Number) itemRowVo.getAttribute("OnHandQty");
                   String itemQtyOnHandStr = itemQtyOnHand.toString();
                   BigDecimal itemQtyOnHandBD = new BigDecimal(itemQtyOnHandStr);
                   int itemQtyOnHandInt = itemQtyOnHand.intValue();
                   
                   String itemSku = (String) itemRowVo.getAttribute("ItemCode");
                   
                   String itemTaxable = (String) itemRowVo.getAttribute("TaxableFlag");
                   String checkTaxable = "Y";
                   if(itemTaxable == null ){
                       itemStatus = false;
                   }
                   else if(itemTaxable.equals(checkTaxable)){
                       itemTaxStatus = true;
                   }
                   else{
                       itemTaxStatus = false;
                   }
                   
                   String itemUnitOfMeasure = (String) itemRowVo.getAttribute("PrimaryUnitOfMeasure");
                   
                   //String itemUnitCost = (String) itemRowVo.getAttribute("");
                   Number itemUnitCost = (Number) itemRowVo.getAttribute("Cost");
                   String itemUnitCostStr = itemUnitCost.toString();
                   BigDecimal itemUnitCostBD = new BigDecimal(itemUnitCostStr);
                   int itemUnitCostInt = itemQtyOnHand.intValue();
                   
                   String itemTaxRate = null;//(String) itemRowVo.getAttribute("");
                   String itemUnitPrice = null;//(String) itemRowVo.getAttribute("");
                   
                   String itemUPC = null;
                   String itemType = (String) itemRowVo.getAttribute("ItemType");
                   String itemActive = (String) itemRowVo.getAttribute("InventoryItemStatusCode");
                   
                   Number OuIdNo = (Number) itemRowVo.getAttribute("InvOrgId");
                   String OuIdString = OuIdNo.toString();
                   
                   String checkActStatus = "Active"; 
                   if(itemActive.equals(checkActStatus)){
                       itemStatus = true;
                   }
                   else{
                       itemStatus = false;
                   }

                 
                   Nemo = Nemo + itemIdStr + " - " + itemDesc + " - " +itemName + " - " +itemQtyOnHandStr + " - " +itemSku + " - " +itemTaxable + " - " +itemUnitOfMeasure + " - " +itemCreationDate+ "-" + itemUnitCostStr + " - " + itemType + " - " + itemActive + " - ";
                   
                   String [] createitem=create_item(pageContext, webBean, itemIdStr,itemName,itemDesc,itemQtyOnHandStr
                                                                         ,itemSku,itemTaxStatus.toString(),itemUnitOfMeasure,itemCreationDate.toString(),itemUnitCostStr,itemType,
                                                                           itemStatus.toString(),OuIdString);
                                                   
                                                   if (createitem[0]!="E" || !createitem[0].equals("E"))
                                                   {
                                                   
                                                       excCollectAdd = excCollectAdd  + " Success: The Item "+ itemSku+" "+ " has Created/Updated in Ebiz Gateway.";
                                                        success_count++;
                                                        am.initOneItemSync_log1();
                                                   
                                                   }
                                                   else
                                                   {
                                                   
                                                       excCollectAdd = excCollectAdd +  " Error: The Item "+itemSku+" " +" has not Created/updated in Ebiz Gateway. ";
                                                       error_count++;
                                                       am.initOneItemSync_log1();
                                                   
                                                   }
                   
               }

	 if(success_count ==  1 ){
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(error_count == 1 ){
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(success_count > 1 && error_count < 1){
				 throw new OAException("Success: "+ success_count +" items has synced in EBizCharge.", OAException.INFORMATION);
			 }
			 
			 if(success_count < 1 && error_count > 1){
				 throw new OAException("Error: "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
			 }
			 
			 if(success_count > 1 && error_count > 1){
				 throw new OAException("Success: "+ success_count +" items has synced in EBizCharge but the "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
			 }
               
           }
       }
     super.processFormRequest(pageContext, webBean);
   }
   
     public String[] create_item(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_item_id,String p_itemName,String p_itemDescription,String P_itemQtyOnHandBD
                                  ,String P_itemSku,String P_itemTaxStatus,String P_itemUnitOfMeasure,String P_itemCreationDate,String P_itemUnitCostBD,String P_itemType,
                                  String P_itemStatus,String P_OuIdString)
                {
                         String[] sendInvDetails = new String[2]; 
                         CallableStatement senditemDetails;
                         try {
                               OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                               senditemDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_item(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14); end;",
                                                       OADBTransaction.DEFAULT);
                                               
                                               
                                                     
                                              senditemDetails.setString(1, p_item_id);
                                              senditemDetails.setString(2, p_itemName);
                                              senditemDetails.setString(3, p_itemDescription);
                                              senditemDetails.setString(4, P_itemQtyOnHandBD);
                                               senditemDetails.setString(5, P_itemSku);
                                                senditemDetails.setString(6, P_itemTaxStatus);
                                                senditemDetails.setString(7, P_itemUnitOfMeasure);
                                                 senditemDetails.setString(8, P_itemCreationDate);
                                                 senditemDetails.setString(9, P_itemUnitCostBD);
                                                  senditemDetails.setString(10, P_itemType);
                                                  senditemDetails.setString(11, P_itemStatus);
                                                  senditemDetails.setString(12, P_OuIdString);
                                               senditemDetails.registerOutParameter(13, Types.VARCHAR);
                                               senditemDetails.registerOutParameter(14, Types.VARCHAR);
                                                                                   
                                              senditemDetails.execute();
                                               
                                               sendInvDetails[0] = senditemDetails.getString(13);
                                               sendInvDetails[1] = senditemDetails.getString(14);
                                                                                   
                                               senditemDetails.close();   
                                               
                           } catch (SQLException e) {
                               throw new OAException("Error While creating the item into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                           }
                                       
                                       return sendInvDetails;
             }
 }
