 package ebizch.oracle.apps.fnd.upld.webui;



import java.sql.CallableStatement;
import java.sql.SQLException;

import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;

 import oracle.jbo.RowSetIterator;

 import ebizch.oracle.apps.fnd.upld.server.CustSyncVOImpl;
 import ebizch.oracle.apps.fnd.upld.server.CustSyncVORowImpl;
 
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

public class CustSyncCO extends OAControllerImpl {
     public static final String RCS_ID = "$Header$";
     public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

     public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
         super.processRequest(pageContext, webBean);

         EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
         am.initCustSyncVO1();    
         

     }

     public void processFormRequest(OAPageContext pageContext, OAWebBean webBean) {
         String firstAttr = "";
         String ScndAttr = "Update: ";
         String excCollect = " ";

         Number sNoLov;
         String sNoLovChar;
         int CustSiteNoInt;


		String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
       
        
        if("SelectAll".equals(eventParam)) {
			EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
            CustSyncVOImpl custVo = am.getCustSyncVO1();
            
			
            RowSetIterator rowSetIterator = custVo.createRowSetIterator("TestIter");
            rowSetIterator.reset();
            while (rowSetIterator.hasNext()){
                Row row = rowSetIterator.next();
                row.setAttribute("ViewAttr","Y");
            }
            rowSetIterator.closeRowSetIterator();
        }
        //If you want to set all the rows
        else if ("SelectNone".equals(eventParam)){
			EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
            CustSyncVOImpl custVo = am.getCustSyncVO1();
          
            int rowCount = custVo.getRowCount();
            RowSetIterator rowSetIterator = custVo.createRowSetIterator("TestIter"); 
            rowSetIterator.setRangeStart(0); 
            rowSetIterator.setRangeSize(rowCount);
            for (int i = 0; i < rowCount; i++) {
                Row row = rowSetIterator.getRowAtRangeIndex(i); 
                row.setAttribute("ViewAttr","N");
            }
            rowSetIterator.closeRowSetIterator();
        }
		 

         if (pageContext.getParameter("custSyncSaveBtn") != null) {
			 int success_count = 0;
			 int error_count = 0;
             EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
             CustSyncVOImpl custVo = am.getCustSyncVO1();
             CustSyncVORowImpl custRowVo = null;
             String excCollectAdd = " ";

             
             Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
             int rowsLength = rows.length;

             if (rowsLength > 0) {
                 for (int i = 0; i < rowsLength; i++) {
                     custRowVo = (CustSyncVORowImpl) rows[i];
    
                     Number CustNo = (Number) custRowVo.getAttribute("CustomerNo");
                     String CustNoString = CustNo.toString();
                     
                     Number OrgId = (Number) custRowVo.getAttribute("Orgid");
                     String OrgIdString = OrgId.toString();
                     
                     String CustAccNoString = (String) custRowVo.getAttribute("AccountNumber");
                     
                     if (custRowVo.getAttribute("ViewAttr1")==null)
                     {
                         CustomerInfo custInfo = new CustomerInfo(); //12March2020
                         String sNoLovIfNull = custInfo.getCustAddressDetailsifnull(pageContext, webBean,CustNo.intValue(),Integer.parseInt(OrgIdString)); //12March2020
                         CustSiteNoInt = Integer.parseInt(sNoLovIfNull);
                         sNoLovChar = sNoLovIfNull + " - ";
                     }
                     else{
                         sNoLov = (Number) custRowVo.getAttribute("ViewAttr1");
                         sNoLovChar = sNoLov.toString() + " - ";
                         CustSiteNoInt = sNoLov.intValue();
                     }
                    

                    
                     String CustName = (String) custRowVo.getAttribute("CustomerName");

                     String CustPhone = (String) custRowVo.getAttribute("Phone");
                     String CustEmail = (String) custRowVo.getAttribute("Email");
                     String CustUrl = (String) custRowVo.getAttribute("Url");
                     
                     Number OuIdNo = (Number) custRowVo.getAttribute("Orgid");
                     String OuIdString = OuIdNo.toString();
                            
                     String[] createcust=createCustomer(pageContext, webBean, CustAccNoString) ;
                     if (createcust[0]!="E" || !createcust[0].equals("E"))
                                                    {
                                                        excCollectAdd = excCollectAdd + " Success: "+CustName+" ("+CustAccNoString+") have synced to EBizCharge.";    
                                                                                                                                success_count++;
                                                                                                                                am.initCustSyncVO1();
                                                    }
                                                    else
                                                    {
                                                        excCollectAdd = excCollectAdd + " Error: "+CustName+" ("+CustAccNoString+") have not synced to EBizCharge.";
                                                                                                                         error_count++;
                                                                                                                          am.initCustSyncVO1();
                                                    }
                 }
             } else {
                 throw new OAException("No Rows Selected: ", OAException.ERROR);
             }
             
        	 
	 if(success_count ==  1 ){
				  am.initCustSyncVO1();
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(error_count == 1 ){
				  am.initCustSyncVO1();
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(success_count > 1 && error_count < 1){
				  am.initCustSyncVO1();
				 throw new OAException("Success: "+ success_count +" customers have synced to EBizCharge.", OAException.INFORMATION);
			 }
			 
			 if(success_count < 1 && error_count > 1){
				  am.initCustSyncVO1();
				 throw new OAException("Error: "+ error_count +" customers have not synced to EBizCharge.", OAException.ERROR);
			 }
			 
			 if(success_count > 1 && error_count > 1){
				  am.initCustSyncVO1();
				 throw new OAException("Success: "+ success_count +" customers have synced to EBizCharge but "+ error_count +" customers have not synced to EBizCharge", OAException.ERROR);
			 }
			
         }
	
         super.processFormRequest(pageContext, webBean);

     }
     public String[] createCustomer(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum){
                           String[] sendInvDetails = new String[2]; 
                           CallableStatement sendcustDetails;
                           try {
                                 OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                                 sendcustDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_customer(:1,:2,:3); end;",
                                                         OADBTransaction.DEFAULT);
                                                 
                                      
                                                 sendcustDetails.registerOutParameter(1, Types.VARCHAR);
                                                 sendcustDetails.registerOutParameter(2, Types.VARCHAR);
                                                 sendcustDetails.setString(3, custNum);
                                                                                     
                                                 sendcustDetails.execute();
                                                 
                                                 sendInvDetails[0] = sendcustDetails.getString(1);
                                                 sendInvDetails[1] = sendcustDetails.getString(2);
                                                                                     
                                                 sendcustDetails.close();   
                                                 
                             } catch (SQLException e) {
                                 throw new OAException("Error While creating the Customer into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                             }
                                         
                                         return sendInvDetails;
               } 
    
 }