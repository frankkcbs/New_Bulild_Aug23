 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;

 import ebizch.oracle.apps.fnd.upld.server.SalesRepVOImpl;
 import ebizch.oracle.apps.fnd.upld.server.SalesRepVORowImpl;
 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;

public class SalesRepSyncLogCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
      
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initSalesRepVO1Log();
   }


   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       if (pageContext.getParameter("SalesRepSyncSaveBtn") != null) {

           EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
           SalesRepVOImpl salesRepVo = am.getSalesRepVO1();
           SalesRepVORowImpl SalesRepRowVo = null;
           String excCollectAdd = " ";
           Boolean SaleRepStatus = false; 
              int success_count=0;
              int error_count=0;
           
           Row rows[] = salesRepVo.getFilteredRows("ViewAttr", "Y");
           int rowsLength = rows.length;

           if (rowsLength > 0) {
               for (int i = 0; i < rowsLength; i++) {
                   SalesRepRowVo = (SalesRepVORowImpl) rows[i];
       
                   Number SalesRepId = (Number) SalesRepRowVo.getAttribute("SalesrepId");
                   String SalesRepIdString = SalesRepId.toString();
                   
                   
                   String FirstNameString = (String) SalesRepRowVo.getAttribute("FirstName");
                  
                   
                   String LastNameString = (String) SalesRepRowVo.getAttribute("LastName");
                  
                   String CompanynameString = (String) SalesRepRowVo.getAttribute("Companyname");
                
                   
                   String WorkTelephoneString = (String) SalesRepRowVo.getAttribute("WorkTelephone");
                 
                   
                 //  String SalesrepNumberString = (String) SalesRepRowVo.getAttribute("SalesrepNumber");
          
                   
                   String EmailAddressString = (String) SalesRepRowVo.getAttribute("EmailAddress");
                  
                   
                   String Address1String = (String) SalesRepRowVo.getAttribute("Address1");
                
                   
                   String CityString = (String) SalesRepRowVo.getAttribute("City");
                  
                   
                   String PostalCodeString = (String) SalesRepRowVo.getAttribute("PostalCode");
                  
                   String StateString = (String) SalesRepRowVo.getAttribute("State");
                   
                   
                   String CountryString = (String) SalesRepRowVo.getAttribute("Country");
               
                   
                   String AccountNumberString = (String) SalesRepRowVo.getAttribute("AccountNumber");
                 
                   
                   String StatusString = (String) SalesRepRowVo.getAttribute("Status");
                   String checkActStatus = "Active"; 
                     if(StatusString.equals(checkActStatus)){
                         SaleRepStatus = true;
                     }
                     else{
                         SaleRepStatus = false;
                     }
               
                   
                   
                     String[] createSaleRep=createSaleRep(pageContext,  webBean ,SalesRepIdString,AccountNumberString,"",FirstNameString,
                                                                            LastNameString,CompanynameString,WorkTelephoneString ,WorkTelephoneString,"",EmailAddressString,
                                                                            "",Address1String, CityString,PostalCodeString,StateString,CountryString, "true",SaleRepStatus.toString()
                                                                             );
                                           if(createSaleRep[0]!="E" || !createSaleRep.equals("E"))
                                           {
                                               excCollectAdd = excCollectAdd + " Success: The SalesRep "+FirstNameString+" ("+SalesRepIdString+") has synced in Ebiz Gateway.";
                                                success_count++;
                                                 am.initSalesRepVO1Log();
                                           }
                                           else
                                           {
                                               excCollectAdd = excCollectAdd + " Error: The SalesRep "+FirstNameString+" ("+SalesRepIdString+") has not synced in Ebiz Gateway.";
                                               error_count++;
                                               am.initSalesRepVO1Log();
                                           }
                   
                 }
               } 
               else {
                     throw new OAException("No Rows Selected: ", OAException.ERROR);
               }
               
              
           throw new OAException(excCollectAdd, OAException.INFORMATION);
           }
     super.processFormRequest(pageContext, webBean);
   }
   
     public String[] createSaleRep(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_srp_id,String p_cust_num,String p_SalesRepType,String p_FirstName,
                                     String p_LastName,String p_CompanyName,String p_Phone ,String p_CellPhone,String p_Fax,String p_Email,
                                     String p_WebSite,String p_Address1, String p_City,String p_ZipCode,String p_State,String p_Country, String IsDefault,String IsInactive
                                      ){
                            String[] sendInvDetails = new String[2]; 
                            CallableStatement sendsalerepDetails;
                            try {
                                  OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                                  sendsalerepDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_salesRep(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19,:20); end;",
                                                          OADBTransaction.DEFAULT);
                                                  
                                                  
                                                        
                                                 sendsalerepDetails.setString(1, p_srp_id);
                                                 sendsalerepDetails.setString(2, p_cust_num);
                                                 sendsalerepDetails.setString(3, p_SalesRepType);
                                                 sendsalerepDetails.setString(4, p_FirstName);
                                                 sendsalerepDetails.setString(5, p_LastName);
                                                 sendsalerepDetails.setString(6, p_CompanyName);
                                                 sendsalerepDetails.setString(7, p_Phone);
                                                 sendsalerepDetails.setString(8, p_CellPhone);
                                                 sendsalerepDetails.setString(9, p_Fax);
                                                 sendsalerepDetails.setString(10, p_Email);
                                                 sendsalerepDetails.setString(11, p_WebSite);
                                                 sendsalerepDetails.setString(12, p_Address1);
                                                 sendsalerepDetails.setString(13, p_City);
                                                 sendsalerepDetails.setString(14, p_ZipCode);
                                                 sendsalerepDetails.setString(15, p_State);
                                                 sendsalerepDetails.setString(16, p_Country);
                                                 sendsalerepDetails.setString(17, IsDefault);
                                                 sendsalerepDetails.setString(18, IsInactive);
                                                 sendsalerepDetails.registerOutParameter(19, Types.VARCHAR);
                                                 sendsalerepDetails.registerOutParameter(20, Types.VARCHAR);
                                                                                      
                                                 sendsalerepDetails.execute();
                                                  
                                                  sendInvDetails[0] = sendsalerepDetails.getString(19);
                                                  sendInvDetails[1] = sendsalerepDetails.getString(20);
                                                                                      
                                                  sendsalerepDetails.close();   
                                                  
                              } catch (SQLException e) {
                                  throw new OAException("Error While creating the SalesRep into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                              }
                                          
                                          return sendInvDetails;
                }  

 }
