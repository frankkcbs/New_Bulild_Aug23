/*===========================================================================+
   |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
   |                         All rights reserved.                              |
   +===========================================================================+
   |  HISTORY                                                                  |
   +===========================================================================*/
package ebizch.oracle.apps.fnd.upld.webui;

import ebizch.oracle.apps.fnd.setup.webui.EbizChargeOrclTokenCall;

import java.math.BigDecimal;

import java.sql.CallableStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Types;

import java.util.ArrayList;
import java.util.List;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.jbo.Row;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;

import oracle.apps.fnd.framework.webui.OAWebBeanConstants;

import oracle.jbo.RowSetIterator;

import oracle.jdbc.OracleTypes;

import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

import ebizch.oracle.apps.fnd.upld.server.InvoicesSyncVOImpl;
import ebizch.oracle.apps.fnd.upld.server.InvoicesSyncVORowImpl;
import ebizch.oracle.apps.fnd.upld.server.SOSyncVOImpl;
import ebizch.oracle.apps.fnd.upld.server.SOSyncVORowImpl;
import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;
import ebizch.oracle.apps.fnd.upld.server.UpldCheckBoxVOImpl;
import ebizch.oracle.apps.fnd.upld.server.UpldCheckBoxVORowImpl;

import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;

/**
 * Controller for ...
 */
public class InvoicesSyncCO extends OAControllerImpl {
    public static final String RCS_ID = "$Header$";
    public static final boolean RCS_ID_RECORDED = 
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
    String insideCalls = "Call: ";

    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        EbizChUpldAMImpl am = 
            (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
        am.initInovicesSyncVO();
        if (!am.getUpldCheckBoxVO1().isPreparedForExecution())

        {
            am.getUpldCheckBoxVO1().executeQuery();
            am.getUpldCheckBoxVO1().first();
        }
    }

    public void processFormRequest(OAPageContext pageContext, 
                                   OAWebBean webBean) {


        String eventParam = 
            pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);

        if ("SelectAll".equals(eventParam)) {
            EbizChUpldAMImpl am = 
                (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
            InvoicesSyncVOImpl invVo = am.getInvoicesSyncVO1();
            RowSetIterator rowSetIterator = 
                invVo.createRowSetIterator("TestIter");
            rowSetIterator.reset();
            while (rowSetIterator.hasNext()) {
                Row row = rowSetIterator.next();
                row.setAttribute("ViewAttr", "Y");
            }
            rowSetIterator.closeRowSetIterator();
        }

        else if ("SelectNone".equals(eventParam)) {
            EbizChUpldAMImpl am = 
                (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
            InvoicesSyncVOImpl invVo = am.getInvoicesSyncVO1();
            int rowCount = invVo.getRowCount();
            RowSetIterator rowSetIterator = 
                invVo.createRowSetIterator("TestIter");
            rowSetIterator.setRangeStart(0);
            rowSetIterator.setRangeSize(rowCount);
            for (int i = 0; i < rowCount; i++) {
                Row row = rowSetIterator.getRowAtRangeIndex(i);
                row.setAttribute("ViewAttr", "N");
            }
            rowSetIterator.closeRowSetIterator();
        }

        if (pageContext.getParameter("InvoiceFilterBtn") != null) {
            EbizChUpldAMImpl am = 
                (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
            String v = 
                ((UpldCheckBoxVORowImpl)am.getUpldCheckBoxVO1().getCurrentRow()).getVal();
            if ("N".equals(v)) {

                String query = 
              "SELECT   hp.party_name customername, hca.cust_account_id, hca.account_number,\n" + 
              "         rct.creation_date, rct.org_id, hou.name as org_name, rct.trx_number invoice_number,\n" + 
              "         -- ARPS.AMOUNT_DUE_ORIGINAL BALANCE,\n" + 
              "         arps.amount_due_remaining balance,\n" + 
              "         DECODE (rctt.TYPE,\n" + 
              "                 'CB', 'Chargeback',\n" + 
              "                 'CM', 'Credit Memo',\n" + 
              "                 'DM', 'Debit Memo',\n" + 
              "                 'DEP', 'Deposit',\n" + 
              "                 'GUAR', 'Guarantee',\n" + 
              "                 'INV', 'Invoice',\n" + 
              "                 'PMT', 'Receipt',\n" + 
              "                 'Invoice'\n" + 
              "                ) invoice_class,\n" + 
              "         rctt.NAME invoice_type, rct.invoice_currency_code currency,\n" + 
              "         rct.trx_date inv_date, rctd.gl_date gl_date,\n" + 
              "         (SELECT NAME\n" + 
              "            FROM apps.ra_terms rat\n" + 
              "           WHERE rat.term_id = rct.term_id) terms, rct.ct_reference,\n" + 
              "         rct.purchase_order, rctl.sales_order, rct.bill_to_site_use_id,\n" + 
              "         NVL (rct.ship_to_site_use_id,\n" + 
              "              rct.bill_to_site_use_id\n" + 
              "             ) AS ship_to_site_use_id\n" + 
              "    FROM ra_customer_trx_all rct,\n" + 
              "         ra_customer_trx_lines_all rctl,\n" + 
              "         ra_cust_trx_line_gl_dist_all rctd,\n" + 
              "         hz_parties hp,\n" + 
              "         hz_cust_accounts_all hca,\n" + 
              "         ra_cust_trx_types_all rctt,\n" + 
              "         hr_operating_units hou,\n" + 
              "         ar_payment_schedules_all arps\n" + 
              "   WHERE rct.customer_trx_id = rctd.customer_trx_id\n" + 
              "     AND rct.customer_trx_id = rctl.customer_trx_id\n" + 
              "     AND rctl.customer_trx_line_id = rctd.customer_trx_line_id\n" + 
              "     AND rct.bill_to_customer_id = hca.cust_account_id\n" + 
              "     AND hp.party_id = hca.party_id\n" + 
              "     AND rct.cust_trx_type_id = rctt.cust_trx_type_id\n" + 
              "     AND rct.org_id = rctt.org_id\n" + 
              "     AND rct.org_id = hou.organization_id\n" + 
              "     AND arps.customer_trx_id(+) = rct.customer_trx_id\n" + 
              "   \n" + 
              "     AND rct.invoice_currency_code = 'USD'\n" + 
              "     AND arps.amount_due_remaining = 0\n" + 
              "     AND rctl.line_type = 'LINE'\n" + 
              "     AND rct.trx_date > sysdate -365\n" + 
              "         and not EXISTS    (\n" + 
              "      select e.ORACLE_NUMBER from EBIZCH_INTERNAL_IDS e \n" + 
              "      WHERE  e.internal_type = 'InvoiceSync'\n" + 
              "      AND E.ORACLE_NUMBER  = rct.trx_number\n" + 
              "      )   \n" + 
              "GROUP BY rct.trx_number,\n" + 
              "         arps.amount_due_remaining,\n" + 
              "         hp.party_name,\n" + 
              "         rctt.TYPE,\n" + 
              "         rct.invoice_currency_code,\n" + 
              "         rct.trx_date,\n" + 
              "         rctd.gl_date,\n" + 
              "         rct.term_id,\n" + 
              "         rctt.NAME,\n" + 
              "         hca.cust_account_id,\n" + 
              "         rct.ct_reference,\n" + 
              "         rct.purchase_order,\n" + 
              "         rctl.sales_order,\n" + 
              "         rct.bill_to_site_use_id,\n" + 
              "         rct.ship_to_site_use_id,\n" + 
              "         hca.account_number,\n" + 
              "         rct.creation_date,\n" + 
              "         rct.org_id,\n" + 
              "         hou.name\n" + 
              "order by \n" + 
              "     rct.trx_date desc";
                try {
                    EbizChUpldAMImpl oam = 
                        (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
                    InvoicesSyncVOImpl vo = 
                        (InvoicesSyncVOImpl)oam.findViewObject("InvoicesSyncVO1");
                        
                    vo.setFullSqlMode(vo.FULLSQL_MODE_AUGMENTATION);
                    vo.setQuery(query);
                    vo.executeQuery();
                    am.getUpldCheckBoxVO1().getCurrentRow().setAttribute("Val","Y");
                    OASubmitButtonBean NewSubmitButton= (OASubmitButtonBean)webBean.findChildRecursive("InvoiceFilterBtn");
                    NewSubmitButton.setText("Hide Invoices with $0 balance" );
                  //  arps.amount_due_remaining <> 0
                    
                } catch (Exception e) {
                    throw new OAException("Updating Query.  Exception: " + 
                                          e.getMessage(), OAException.ERROR);
                }

                //CheckBoxBean.setSelectedValue("N"); 
                //throw new OAException("1. V="+v, OAException.CONFIRMATION);
            } else {
            
               // am.initInovicesSyncVO();
                String query = 
                "SELECT   hp.party_name customername, hca.cust_account_id, hca.account_number,\n" +
                "         rct.creation_date, rct.org_id, hou.name as org_name, rct.trx_number invoice_number,\n" +
                "         -- ARPS.AMOUNT_DUE_ORIGINAL BALANCE,\n" +
                "         arps.amount_due_remaining balance,\n" +
                "         DECODE (rctt.TYPE,\n" +
                "                 'CB', 'Chargeback',\n" +
                "                 'CM', 'Credit Memo',\n" +
                "                 'DM', 'Debit Memo',\n" +
                "                 'DEP', 'Deposit',\n" +
                "                 'GUAR', 'Guarantee',\n" +
                "                 'INV', 'Invoice',\n" +
                "                 'PMT', 'Receipt',\n" +
                "                 'Invoice'\n" +
                "                ) invoice_class,\n" +
                "         rctt.NAME invoice_type, rct.invoice_currency_code currency,\n" +
                "         rct.trx_date inv_date, rctd.gl_date gl_date,\n" +
                "         (SELECT NAME\n" +
                "            FROM apps.ra_terms rat\n" +
                "           WHERE rat.term_id = rct.term_id) terms, rct.ct_reference,\n" +
                "         rct.purchase_order, rctl.sales_order, rct.bill_to_site_use_id,\n" +
                "         NVL (rct.ship_to_site_use_id,\n" +
                "              rct.bill_to_site_use_id\n" +
                "             ) AS ship_to_site_use_id\n" +
                "    FROM ra_customer_trx_all rct,\n" +
                "         ra_customer_trx_lines_all rctl,\n" +
                "         ra_cust_trx_line_gl_dist_all rctd,\n" +
                "         hz_parties hp,\n" +
                "         hz_cust_accounts_all hca,\n" +
                "         ra_cust_trx_types_all rctt,\n" +
                "         hr_operating_units hou,\n" +
                "         ar_payment_schedules_all arps\n" +
                "   WHERE rct.customer_trx_id = rctd.customer_trx_id\n" +
                "     AND rct.customer_trx_id = rctl.customer_trx_id\n" +
                "     AND rctl.customer_trx_line_id = rctd.customer_trx_line_id\n" +
                "     AND rct.bill_to_customer_id = hca.cust_account_id\n" +
                "     AND hp.party_id = hca.party_id\n" +
                "     AND rct.cust_trx_type_id = rctt.cust_trx_type_id\n" +
                "     AND rct.org_id = rctt.org_id\n" +
                "     AND rct.org_id = hou.organization_id\n" +
                "     AND arps.customer_trx_id(+) = rct.customer_trx_id\n" +
                "   \n" +
                "     AND rct.invoice_currency_code = 'USD'\n" +
                "     AND arps.amount_due_remaining <> 0\n" +
                "     AND rctl.line_type = 'LINE'\n" +
                "     AND rct.trx_date > sysdate -365\n" +
                "         and not EXISTS    (\n" +
                "      select e.ORACLE_NUMBER from EBIZCH_INTERNAL_IDS e \n" +
                "      WHERE  e.internal_type = 'InvoiceSync'\n" +
                "      AND E.ORACLE_NUMBER  = rct.trx_number\n" +
                "      )   \n" +
                "GROUP BY rct.trx_number,\n" +
                "         arps.amount_due_remaining,\n" +
                "         hp.party_name,\n" +
                "         rctt.TYPE,\n" +
                "         rct.invoice_currency_code,\n" +
                "         rct.trx_date,\n" +
                "         rctd.gl_date,\n" +
                "         rct.term_id,\n" +
                "         rctt.NAME,\n" +
                "         hca.cust_account_id,\n" +
                "         rct.ct_reference,\n" +
                "         rct.purchase_order,\n" +
                "         rctl.sales_order,\n" +
                "         rct.bill_to_site_use_id,\n" +
                "         rct.ship_to_site_use_id,\n" +
                "         hca.account_number,\n" +
                "         rct.creation_date,\n" +
                "         rct.org_id,\n" +
                "         hou.name\n" +
                "order by \n" +
                "     rct.trx_date desc";
                try {
                    EbizChUpldAMImpl oam = 
                        (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
                    InvoicesSyncVOImpl vo = 
                        (InvoicesSyncVOImpl)oam.findViewObject("InvoicesSyncVO1");
                        
                    vo.setFullSqlMode(vo.FULLSQL_MODE_AUGMENTATION);
                    vo.setQuery(query);
                    vo.executeQuery();
                    am.getUpldCheckBoxVO1().getCurrentRow().setAttribute("Val","Y");
                //    OASubmitButtonBean NewSubmitButton= (OASubmitButtonBean)webBean.findChildRecursive("InvoiceFilterBtn");
                   // NewSubmitButton.setText("Exclude zero $" );
                  //  arps.amount_due_remaining <> 0
                    
                } catch (Exception e) {
                    throw new OAException("Updating Query.  Exception: " + 
                                          e.getMessage(), OAException.ERROR);
                }
                am.getUpldCheckBoxVO1().getCurrentRow().setAttribute("Val", "N");
                OASubmitButtonBean NewSubmitButton= (OASubmitButtonBean)webBean.findChildRecursive("InvoiceFilterBtn");
                NewSubmitButton.setText("Show Invoices with $0 balance");
               // throw new OAException("2. V=" + v, OAException.CONFIRMATION);
            }

        }


        if (pageContext.getParameter("InvoicesSaveBtn") != null) {
            int success_count = 0;
            int error_count = 0;
            EbizChUpldAMImpl am = 
                (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
            InvoicesSyncVOImpl invVo = am.getInvoicesSyncVO1();
            InvoicesSyncVORowImpl invRowVo = null;
            String excCollectAdd = " ";
            String excCollectUp = " ";
            String messageValue = "";
            Row rows[] = invVo.getFilteredRows("ViewAttr", "Y");
            int rowsLength = rows.length;

            if (rowsLength > 0) {
                for (int i = 0; i < rowsLength; i++) {
                    invRowVo = (InvoicesSyncVORowImpl)rows[i];

                    Number custId = 
                        (Number)invRowVo.getAttribute("CustAccountId");
                    String custIdStr = custId.toString();

                    Number invOrgId = (Number)invRowVo.getAttribute("OrgId");
                    String invOrgIdStr = invOrgId.toString();

                    String CustAccNoString = 
                        (String)invRowVo.getAttribute("AccountNumber");

                    String invCustomerName = 
                        (String)invRowVo.getAttribute("Customername");

                    String invNumb = 
                        (String)invRowVo.getAttribute("InvoiceNumber");

                    Date invdate = (Date)invRowVo.getAttribute("InvDate");
                    String invdateStr = invdate.toString();

                    String invCurr = (String)invRowVo.getAttribute("Currency");

                    Number invAmtDue = 
                        (Number)invRowVo.getAttribute("Balance");
                    String invAmtDueStr = invAmtDue.toString();
                    BigDecimal invAmtDueBD = new BigDecimal(invAmtDueStr);
                    
                    String invSaleOrder = 
                        (String)invRowVo.getAttribute("SalesOrder");


                    Number invInvoiceTo = 
                        (Number)invRowVo.getAttribute("BillToSiteUseId");
                    int invInvoiceToInt = invInvoiceTo.intValue();
                    String Billto=String.valueOf(invInvoiceToInt);
                    
                    Number invShipTo = 
                        (Number)invRowVo.getAttribute("ShipToSiteUseId");
                    int invShipToInt = invShipTo.intValue();
                  String shipto=String.valueOf(invShipToInt);

                    String[] validationsMessage = isValidate(invOrgIdStr,custIdStr,invCustomerName,invNumb,invdateStr,invCurr,invAmtDueStr,invAmtDueStr,invdateStr,shipto,Billto);

                    if (validationsMessage[0].equals("1")) {
                        messageValue = messageValue + validationsMessage[1];
                    }
                    /*New Code by hamza*/
                    if (validationsMessage[0].equals("1")) {
                        error_count++;
                    } else {
                        
                        
                     
                        
                        String[] sendinv=sendInvoice(pageContext, webBean, CustAccNoString,invSaleOrder,invOrgIdStr,invNumb);
                           
                           if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                               {
                                   excCollectAdd =  excCollectAdd + " Success: Invoice " + invNumb + " have synced to EBizCharge.";
                                   success_count++;
                                    am.initInovicesSyncVO();
                                } 
                                else
                                {
                                    excCollectAdd = 
                                            excCollectAdd + " Error: Invoice " + 
                                            invNumb + 
                                            " have synced to EBizCharge.";
                                    error_count++;
                                    am.initInovicesSyncVO();
                                
                                }
                        
                    }
                    //throw new OAException("Invoices Syncing Status: " + itemIdStr, OAException.INFORMATION);
                }
                if (success_count == 1) {
                    am.initInovicesSyncVO();
                    throw new OAException(excCollectAdd, 
                                          OAException.INFORMATION);
                }

                if (error_count == 1) {
                    am.initInovicesSyncVO();
                    // throw new OAException(excCollectAdd, OAException.INFORMATION);
                    if (!messageValue.equals("") || 
                        !messageValue.equals(null)) {
                        throw new OAException(messageValue, OAException.ERROR);
                    } else {
                        throw new OAException(excCollectAdd, 
                                              OAException.ERROR);
                    }
                }

                if (success_count > 1 && error_count < 1) {
                    am.initInovicesSyncVO();
                    throw new OAException("Success: " + success_count + 
                                          " invoices have synced to EBizCharge.", 
                                          OAException.INFORMATION);
                }

                if (success_count < 1 && error_count > 1) {
                    am.initInovicesSyncVO();
                    // throw new OAException("Error "+ error_count +" invoices have not synced to EBizCharge.", OAException.ERROR);
                    if (!messageValue.equals("") || 
                        !messageValue.equals(null)) {
                        throw new OAException("Error: " + error_count + 
                                              " invoices have not synced to EBizCharge." + 
                                              "Because" + messageValue, 
                                              OAException.ERROR);
                    } else {
                        throw new OAException("Error: " + error_count + 
                                              " invoices have not synced to EBizCharge.", 
                                              OAException.ERROR);
                    }
                }

                if (success_count > 1 && error_count > 1) {
                    am.initInovicesSyncVO();
                    // throw new OAException("Success: "+ success_count +" invoices have synced to EBizCharge but "+ error_count +" invoices have not synced to EBizCharge.", OAException.ERROR);
                    if (!messageValue.equals("") || 
                        !messageValue.equals(null)) {
                        throw new OAException("Success: " + success_count + 
                                              " invoices have synced to EBizCharge but " + 
                                              error_count + 
                                              " invoices have not synced to EBizCharge. " + 
                                              "Because" + messageValue, 
                                              OAException.WARNING);
                    } else {
                        throw new OAException("Success: " + success_count + 
                                              " invoices have synced to EBizCharge but  " + 
                                              error_count + 
                                              " invoices have not synced to EBizCharge. ", 
                                              OAException.WARNING);
                    }
                }
                // throw new OAException(excCollectAdd, OAException.INFORMATION);
            }
        }
        super.processFormRequest(pageContext, webBean);
    }

    public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum){
                    String[] sendInvDetails = new String[2]; 
                    CallableStatement sendInvoiceDetails;
                    try {
                          OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                          sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.send_invoice(:1,:2,:3,:4,:5,:6); end;",
                                                  OADBTransaction.DEFAULT);
                                          
                                          
                                                
                                         sendInvoiceDetails.setString(1, custNum);
                                         sendInvoiceDetails.setString(2, inSO);
                                         sendInvoiceDetails.setString(3, orgId);
                                         sendInvoiceDetails.setString(4, invNum);
                                          sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                          sendInvoiceDetails.registerOutParameter(6, Types.VARCHAR);
                                                                              
                                         sendInvoiceDetails.execute();
                                          
                                          sendInvDetails[0] = sendInvoiceDetails.getString(5);
                                          sendInvDetails[1] = sendInvoiceDetails.getString(6);
                                                                              
                                          sendInvoiceDetails.close();   
                                          
                      } catch (SQLException e) {
                          throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                      }
                                  
                                  return sendInvDetails;
        }
  
    public String[] isValidate(String invOrgId,String customerId,String customerName,String invNumber,String invDate,String currency,String amtdue,String invamtdue,String invDueDate,String shipoUseID,String billtoUseid) {
        String retMessage = "";
        String retValue = "null";
        String[] output = new String[2];
        output[0] = "0";
        if ("null".equals(String.valueOf(invOrgId))) {
            retMessage = retMessage + "Org Id,";
        }

        if ("null".equals(String.valueOf(customerId))) {
            retMessage = retMessage + "Customer Id,";
        }

        if ("null".equals(String.valueOf(customerName)) || 
            String.valueOf(customerName) == null) {
            retMessage = retMessage + "Customer Name,";
        }

        if ("null".equals(String.valueOf(invNumber)) || 
            String.valueOf(invNumber) == null) {
            retMessage = retMessage + "Invoice Number,";
        }
        if ("null".equals(String.valueOf(invDate))) {
            retMessage = retMessage + "Invoice Date,";
        }
        if ("null".equals(String.valueOf(currency))) {
            retMessage = retMessage + "Currency,";
        }

        if ("null".equals(String.valueOf(invamtdue))) {
            retMessage = retMessage + "Invoice Amount,";
        }

        if ("null".equals(String.valueOf(invDueDate))) {
            retMessage = retMessage + "Invoice Due Date,";
        }

        if ("null".equals(String.valueOf(amtdue))) {
            retMessage = retMessage + "Invoice Amount due,";
        }

        if ("null".equals(String.valueOf(billtoUseid))) {
            retMessage = retMessage + "Bill to Site Id,";
        }
        if ("null".equals(String.valueOf(shipoUseID))) {
            retMessage = retMessage + "Ship to Site Id,";
        }
        if (retMessage != "") {
            output[0] = "1";
            retValue = 
                    retMessage + "are not found against your selected Invoice Number No" + 
                    " : " + invNumber;
            output[1] = retValue;
        } else if (retMessage == "") {

            output[0] = "0";
            output[1] = "Invoice data is validated.";
        }
        return output;
    }
}
