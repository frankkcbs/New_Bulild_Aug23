 /*===========================================================================+
    |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
    |                         All rights reserved.                              |
    +===========================================================================+
    |  HISTORY                                                                  |
    +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;


 import java.math.BigDecimal;



 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;
 import oracle.jbo.domain.Date;
 import oracle.jbo.domain.Number;
 import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
 import oracle.jbo.RowSetIterator;


 import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

 import ebizch.oracle.apps.fnd.upld.server.InvoicesSyncVO_LogImpl;
 import ebizch.oracle.apps.fnd.upld.server.InvoicesSyncVO_LogRowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;


/**
 * Controller for ...
 */
 public class InvoicesSyncLogCO extends OAControllerImpl {
     public static final String RCS_ID = "$Header$";
     public static final boolean RCS_ID_RECORDED = 
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
     String insideCalls = "Call: ";

     public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
         super.processRequest(pageContext, webBean);
         EbizChUpldAMImpl am = 
             (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
         am.initInovicesSyncVOLog();
     }

     public void processFormRequest(OAPageContext pageContext, 
                                    OAWebBean webBean) {


           String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
         
         if("SelectAll".equals(eventParam)) {
                         EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
             InvoicesSyncVO_LogImpl invVo = am.getInvoicesSyncVO_Log1();
             RowSetIterator rowSetIterator = invVo.createRowSetIterator("TestIter");
             rowSetIterator.reset();
             while (rowSetIterator.hasNext()){
                 Row row = rowSetIterator.next();
                 row.setAttribute("ViewAttr","Y");
             }
             rowSetIterator.closeRowSetIterator();
         }
                 
         else if ("SelectNone".equals(eventParam)){
                         EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
             InvoicesSyncVO_LogImpl invVo = am.getInvoicesSyncVO_Log1();
             int rowCount = invVo.getRowCount();
             RowSetIterator rowSetIterator = invVo.createRowSetIterator("TestIter"); 
             rowSetIterator.setRangeStart(0); 
             rowSetIterator.setRangeSize(rowCount);
             for (int i = 0; i < rowCount; i++) {
                 Row row = rowSetIterator.getRowAtRangeIndex(i); 
                 row.setAttribute("ViewAttr","N");
             }
             rowSetIterator.closeRowSetIterator();
         }
                                                                                    
                                                                    
         if (pageContext.getParameter("InvoicesSaveBtn") != null) {
                         int success_count = 0;
                          int error_count = 0;
             EbizChUpldAMImpl am = 
                 (EbizChUpldAMImpl)pageContext.getApplicationModule(webBean);
             InvoicesSyncVO_LogImpl invVo = am.getInvoicesSyncVO_Log1();
             InvoicesSyncVO_LogRowImpl invRowVo = null;
             
             String excCollectAdd = " ";
             String excCollectUp = " ";

             Row rows[] = invVo.getFilteredRows("ViewAttr", "Y");
             int rowsLength = rows.length;

             if (rowsLength > 0) {
                 for (int i = 0; i < rowsLength; i++) {
                     invRowVo = (InvoicesSyncVO_LogRowImpl)rows[i];
                     Number custId = 
                         (Number)invRowVo.getAttribute("CustAccountId");
                     String custIdStr = custId.toString();
                     //int itemIdInt = itemId.intValue();
                     //invInfoObj.setInvCustomerId(custIdStr);

                     Number invOrgId = (Number)invRowVo.getAttribute("OrgId");
                     String invOrgIdStr = invOrgId.toString();
                     
                     String invSaleOrder = (String) invRowVo.getAttribute("SalesOrder");

                     String CustAccNoString = 
                         (String)invRowVo.getAttribute("AccountNumber");              

                     String invCustomerName = 
                         (String)invRowVo.getAttribute("Customername");
                     String invNumb = 
                         (String)invRowVo.getAttribute("InvoiceNumber");
                    


                     Date invdate = (Date)invRowVo.getAttribute("InvDate");
                     String invdateStr = invdate.toString();

                    String invCurr = (String)invRowVo.getAttribute("Currency");
                    

                     Number invAmtDue = 
                         (Number)invRowVo.getAttribute("Balance");
                     String invAmtDueStr = invAmtDue.toString();
                     BigDecimal invAmtDueBD = new BigDecimal(invAmtDueStr);
                
                     Number invInvoiceTo = 
                         (Number)invRowVo.getAttribute("BillToSiteUseId");
                     int invInvoiceToInt = invInvoiceTo.intValue();

                     Number invShipTo = 
                         (Number)invRowVo.getAttribute("ShipToSiteUseId");
                     int invShipToInt = invShipTo.intValue();

                     String[] sendinv=sendInvoice(pageContext, webBean, CustAccNoString,invSaleOrder,invOrgIdStr,invNumb);
                                        
                                        if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                                            {
                                                excCollectAdd =  excCollectAdd + " Success: invoice " + invNumb + " have synced to EBizCharge.";
                                                success_count++;
                                                 am.initInovicesSyncVO();
                                             } 
                                             else
                                             {
                                                 excCollectAdd = 
                                                         excCollectAdd + " Error: invoice " + 
                                                         invNumb + 
                                                         " have synced to EBizCharge.";
                                                 error_count++;
                                                 am.initInovicesSyncVO();
                                             
                                             }
                    
                 }
                                  if(success_count ==  1 ){
                                  throw new OAException(excCollectAdd, OAException.INFORMATION);
                                  }
                                  
                                  if(error_count == 1 ){
                                  throw new OAException(excCollectAdd, OAException.INFORMATION);
                                  }
                                  
                                  if(success_count > 1 && error_count < 1){
                                          throw new OAException("Success: "+ success_count +" invoices have synced to EBizCharge.", OAException.INFORMATION);
                                  }
                                  
                                  if(success_count < 1 && error_count > 1){
                                          throw new OAException("Error "+ error_count +" invoices have not synced to EBizCharge.", OAException.ERROR);
                                  }
                                  
                                  if(success_count > 1 && error_count > 1){
                                          throw new OAException("Success: "+ success_count +" invoices have synced to EBizCharge but "+ error_count +" invoices have not synced to EBizCharge.", OAException.ERROR);
                                  } 
                // throw new OAException(excCollectAdd, OAException.INFORMATION);
             }
         }
         super.processFormRequest(pageContext, webBean);
     }

     public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum){
                     String[] sendInvDetails = new String[2]; 
                     CallableStatement sendInvoiceDetails;
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.send_invoice(:1,:2,:3,:4,:5,:6); end;",
                                                   OADBTransaction.DEFAULT);
                                           
                                           
                                                 
                                          sendInvoiceDetails.setString(1, custNum);
                                          sendInvoiceDetails.setString(2, inSO);
                                          sendInvoiceDetails.setString(3, orgId);
                                          sendInvoiceDetails.setString(4, invNum);
                                           sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                           sendInvoiceDetails.registerOutParameter(6, Types.VARCHAR);
                                                                               
                                          sendInvoiceDetails.execute();
                                           
                                           sendInvDetails[0] = sendInvoiceDetails.getString(5);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(6);
                                                                               
                                           sendInvoiceDetails.close();   
                                           
                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }
                                   
                                   return sendInvDetails;
         }
     
         
 }
