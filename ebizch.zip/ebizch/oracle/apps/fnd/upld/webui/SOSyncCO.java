 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.upld.webui;

import java.math.BigDecimal;

 import java.sql.CallableStatement;

 import java.sql.SQLException;
 import java.sql.Types;



 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;


 import ebizch.oracle.apps.fnd.upld.server.SOSyncVOImpl;
 import ebizch.oracle.apps.fnd.upld.server.SOSyncVORowImpl;
import ebizch.oracle.apps.fnd.upld.server.EbizChUpldAMImpl;

/**
 * Controller for ...
 */
 public class SOSyncCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
     String insideCalls = "Call: ";

   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       am.initSOSyncVO();
   }

  
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       if (pageContext.getParameter("custSOSaveBtn1") != null) {
		    int success_count = 0;
		 int error_count = 0;
       EbizChUpldAMImpl am = (EbizChUpldAMImpl) pageContext.getApplicationModule(webBean);
       SOSyncVOImpl soVo = am.getSOSyncVO1();
       SOSyncVORowImpl soRowVo = null;
       String excCollectAdd = " ";
       String excCollectUp = "Updated: ";
       String testing = "";
           String messageValue="";
     
       Row rows[] = soVo.getFilteredRows("ViewAttr", "Y");
       int rowsLength = rows.length;

       if (rowsLength > 0) {
           for (int i = 0; i < rowsLength; i++) {
               soRowVo = (SOSyncVORowImpl) rows[i];
               
               
               Number soCustId = (Number) soRowVo.getAttribute("CustomerId");
               String soCustIdStr = soCustId.toString() ;
               
               Number soOrgId = (Number) soRowVo.getAttribute("Orgid");
               String soOrgIdStr = soOrgId.toString();
               
               String soOUname = (String) soRowVo.getAttribute("Ouname");
               
              
               String soInvorg = (String) soRowVo.getAttribute("Invorg");
                             
               String CustNoString = (String) soRowVo.getAttribute("CustomerNumber");
               CustomerInfo custInfo = new CustomerInfo(); 
               
               Number soOrdNum = (Number) soRowVo.getAttribute("SalesOrderNumber");
               
             
               String soOrdNumStr = soOrdNum.toString() ;
               /*if(true){
                //throw new OAException("1 After SO INFO", OAException.ERROR);
                  throw new OAException("1 After SO soOrdNum "+soOrdNumStr, OAException.ERROR);
               }*/
               int soOrdNumInt = soOrdNum.intValue();
                              
               String soPoNum = (String) soRowVo.getAttribute("CustPoNumber");
                       
               String soCustomerName = (String) soRowVo.getAttribute("CustomerName");
               
               Number soTaxAmt = (Number) soRowVo.getAttribute("TotalTaxAmount");
               String soTaxAmtStr = soTaxAmt.toString();
               BigDecimal soTaxAmtBD = new BigDecimal(soTaxAmtStr);
               int soTaxAmtInt = soTaxAmt.intValue();
               
               
               
               Number soAmt = (Number) soRowVo.getAttribute("TotOrderAmt");
               String soAmtStr = soAmt.toString();
               BigDecimal soAmtBD = new BigDecimal(soAmtStr);
               int soAmtInt = soAmt.intValue();
               
          
               Number soAmtDue = (Number) soRowVo.getAttribute("Amountdue");
               String soAmtDueStr = soAmtDue.toString();
               BigDecimal soAmtDueBD = new BigDecimal(soAmtDueStr);
               int soAmtDueInt = soAmtDue.intValue();
               
               Date sodate = (Date) soRowVo.getAttribute("OrderedDate");
               String sodateStr = sodate.toString();
               
               Date soShipDate = (Date) soRowVo.getAttribute("OrderedDate");
               String soShipDateStr = soShipDate.toString();              

               String soShipVia = (String) soRowVo.getAttribute("ShipVia");
               
               String soCurr = (String) soRowVo.getAttribute("Currency");
               
               Number soInvoiceTo = (Number) soRowVo.getAttribute("InvoiceToOrgId");
               String soInvoiceToStr = soInvoiceTo.toString() ;
               int soInvoiceToInt = soInvoiceTo.intValue();
               
               Number soShipTo = (Number) soRowVo.getAttribute("ShipToOrgId");
               String soShipToStr = soShipTo.toString() ;
               int soShipToInt = soShipTo.intValue();

               String[] validationsMessage = isValidate(soOrgIdStr,soOUname,soInvorg,soCustIdStr,soTaxAmtStr,soAmtStr,soAmtDueStr
                                 ,sodateStr,soShipVia,soCurr,soShipToStr,soInvoiceToStr,soOrdNumStr) ;

               if (validationsMessage[0].equals("1")) {
                 messageValue = messageValue + validationsMessage[1];
               }
                   /*New Code by hamza*/
               if (validationsMessage[0].equals("1")){
                  error_count++; 
               }
               else{
                   String[] sendinv=sendSaleOrder(pageContext, webBean, CustNoString,soOrdNumStr,soInvorg);
                   
                   if ( !"E".equals(sendinv[0]) || sendinv[0]!="E")//sendinv[0]!="E" ||
                                                  {
                                                      excCollectAdd =  excCollectAdd + " Success: SaleOrder " + soOrdNumStr + " have synced to EBizCharge.";
                                                      success_count++;
                                                       am.initSOSyncVO();
                                                   } 
                                                   else
                                                   {
                                                       excCollectAdd = 
                                                               excCollectAdd + " Error: SaleOrder " + 
                                                               soOrdNumStr + 
                                                               " have not synced to EBizCharge.";
                                                       error_count++;
                                                       am.initSOSyncVO();
                                                   
                                                   }
                                                   
                                                   
               }
           }
		   	 if(success_count ==  1 ){
				 am.initSOSyncVO();
             throw new OAException(excCollectAdd, OAException.INFORMATION);
			 }
			 
			 if(error_count == 1 ){
				 am.initSOSyncVO();
				 throw new OAException(excCollectAdd, OAException.ERROR);
            
			 }
			 
			 if(success_count > 1 && error_count < 1){
				 am.initSOSyncVO();
				 throw new OAException("Success: "+ success_count +" sale order  has synced in EBizCharge.", OAException.INFORMATION);
			 }
			 
			 if(success_count < 1 && error_count > 1){
				 am.initSOSyncVO();
				 //throw new OAException("Error: "+ error_count +" sale order  has not synced in EBizCharge.", OAException.ERROR);
				 throw new OAException("Error: "+ error_count +" sale order  has not synced in EBizCharge." , OAException.ERROR);
				 
			 }
			 
			 if(success_count > 1 && error_count > 1){
				 am.initSOSyncVO();
				// throw new OAException("Success: "+ success_count +" sale order has synced in EBizCharge but the "+ error_count +" items has not synced in EBizCharge.", OAException.ERROR);
				throw new OAException("Success: "+ success_count +" sale order has synced in EBizCharge but the  "+ error_count +" items has not synced in EBizCharge.", OAException.WARNING);				
				
                         }
               
           
       }

              throw new OAException(excCollectAdd, OAException.INFORMATION);
       }
       
       
     super.processFormRequest(pageContext, webBean);
   }
     public String[] sendSaleOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId){
                     String[] sendInvDetails = new String[2]; 
                     CallableStatement sendInvoiceDetails;
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.send_saleorder(:1,:2,:3,:4,:5); end;",
                                                   OADBTransaction.DEFAULT);
                                           
                                           
                                                 
                                          sendInvoiceDetails.setString(1, custNum);
                                          sendInvoiceDetails.setString(2, inSO);
                                          sendInvoiceDetails.setString(3, orgId);
                                           sendInvoiceDetails.registerOutParameter(4, Types.VARCHAR);
                                           sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                                                               
                                          sendInvoiceDetails.execute();
                                           
                                           sendInvDetails[0] = sendInvoiceDetails.getString(4);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(5);
                                                                               
                                           sendInvoiceDetails.close();   
                                           
                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the saleorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }
                                   
                                   return sendInvDetails;
         }
  
     public String[] isValidate(String pSoorgId,String SoOuName,String SoInvorg,String SoCustomerId,String SoTotalTaxAmount,String SoAmount,String SoAmountDue
                                 ,String SoDate,String SoShipVia,String SoCurrency,String ShipToOrgId,String InvoiceToOrgId,String soNum) {
       String retMessage = "";
       String retValue = "null";
       String[] output = new String[2];
       output[0] = "0";
       if ("null".equals(String.valueOf(pSoorgId))) {
         retMessage = retMessage + "Org Id,";
       }

       if ("null".equals(String.valueOf(SoOuName))) {
         retMessage = retMessage + "Operating Unit Name,";
       }

       if ("null".equals(String.valueOf(SoInvorg)) || String.valueOf(SoInvorg) == null) {
         retMessage = retMessage + "Invoice to Org,";
       }

       if ("null".equals(String.valueOf(SoCustomerId)) || String.valueOf(SoCustomerId) == null) {
         retMessage = retMessage + "Customer Id,";
       }
       if ("null".equals(String.valueOf( SoTotalTaxAmount))) {
         retMessage = retMessage + "Tax Amount,";
       }
       if ("null".equals(String.valueOf(SoAmount))) {
         retMessage = retMessage + "Amount,";
       }

       if ("null".equals(String.valueOf(SoAmountDue))) {
         retMessage = retMessage + "Amount Due,";
       }
       
       if ("null".equals(String.valueOf(SoDate))) {
           retMessage = retMessage + "SO Date,";
         }  
         
       if ("null".equals(String.valueOf(SoShipVia))) {
         retMessage = retMessage + "Shipping Method,";
       }

       if ("null".equals(String.valueOf(SoCurrency))) {
         retMessage = retMessage + "Currency,";
       }
       
       if ("null".equals(ShipToOrgId)) {
         retMessage = retMessage + "Ship to org id,";
       }
       
       if ("null".equals( InvoiceToOrgId)) {
         retMessage = retMessage + "Invoice to Org Id,";
       }
       
       if (retMessage!="") {
         output[0] = "1";
         retValue = retMessage + " are not found against your selected Sales Order No" + " : " + soNum;
         output[1] = retValue;
       } else if (retMessage=="") {

         output[0] = "0";
         output[1] = "Sales Order data is validated.";
       }
       return output;
     }
          	 

 }
