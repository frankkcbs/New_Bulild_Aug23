package ebizch.oracle.apps.fnd.ach.webui;


import java.sql.CallableStatement;
import java.sql.SQLException;

import java.sql.Types;
import ebizch.oracle.apps.fnd.ach.server.EbizChAchAMImpl;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.server.common.OAApplicationModule;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.jbo.Row;
import ebizch.oracle.apps.fnd.ach.server.PayMethodACHMasterVOImpl;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import ebizch.oracle.apps.fnd.ach.server.PayMethodACHMasterVORowImpl;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;

public class PayMethodSendReqAllWalletAchCO extends OAControllerImpl
{
    String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName=""; 

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      super.processRequest(pageContext, webBean);
      
      Truncate(pageContext,webBean);
      String getEmailTempResp[] =new String[2];
      getEmailTempResp =  createEmailTemplate(pageContext, webBean);
      	   

      String getResp[] =new String[3];
      getResp =  getEmailTemplateFetch(pageContext,webBean);
      inEmailTemplate = getResp[0];
      inSubjectText = getResp[1];
      inFromMail = getResp[2];
      inFromName= getResp[3];
      
      
      EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
	  
	  
	   
      OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
      lovBean.setText(pageContext,inEmailTemplate);
	  
       OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
       TemplateIdFvInput.setValue(inEmailTemplate);
		  
	  OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
	  textBean.setText(inSubjectText);	
		
	  OAMessageTextInputBean textBeanEmailFromIn = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
      textBeanEmailFromIn.setText(inFromMail);
	  
	  OAFormValueBean inFromMailInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailSubjectFv");
      inFromMailInputSet1.setValue(pageContext,inSubjectText);
	  
	  OAFormValueBean inSubjectTextInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromFv");
      inSubjectTextInputSet1.setValue(pageContext,inFromMail);
                     
         String query ="SELECT hou.NAME AS org_name, hca.account_number, hp.party_name as CUSTOMER_NAME, TO_CHAR (hp.creation_date, 'DD-MON-YYYY') AS creation_date, NVL ((SELECT email_address FROM apps.hz_contact_points WHERE owner_table_name = 'HZ_PARTIES' AND status = 'A' AND contact_point_type = 'EMAIL' AND owner_table_id IN ( SELECT party_id FROM hz_cust_accounts WHERE cust_account_id = hca.cust_account_id) AND ROWNUM = 1), NVL ((SELECT email_address FROM apps.hz_contact_points WHERE contact_point_type = 'EMAIL' AND owner_table_name = 'HZ_PARTY_SITES' AND status = 'A' AND owner_table_id IN ( SELECT party_site_id FROM hz_cust_acct_sites_all WHERE cust_account_id = hca.cust_account_id) AND ROWNUM = 1), NVL ((SELECT email_address FROM apps.hz_contact_points WHERE owner_table_name = 'HZ_PARTIES' AND status = 'A' AND contact_point_type = 'EMAIL' AND owner_table_id IN ( SELECT party_id FROM apps.hz_cust_account_roles WHERE role_type = 'CONTACT' AND cust_account_id = hca.cust_account_id) AND ROWNUM = 1), NVL ((SELECT NVL (hcpemail.email_address, '') FROM apps.hz_contact_points hcpemail WHERE hcpemail.owner_table_id = hca.cust_account_id AND hcpemail.owner_table_name = 'HZ_PARTIES' AND hcpemail.contact_point_type = 'EMAIL' AND hcpemail.primary_flag = 'Y'), '' ) ) ) ) AS email, hca.cust_account_id cust_account_id, hcas.org_id AS orgid, hp.party_id FROM hz_parties hp, hz_party_sites hps, hz_cust_accounts_all hca, hz_cust_acct_sites_all hcas, hr_operating_units hou WHERE 1 = 1 AND hp.party_id = hca.party_id AND hca.cust_account_id = hcas.cust_account_id AND hps.party_site_id = hcas.party_site_id AND hp.party_type = 'ORGANIZATION' AND hp.status = 'A' AND hcas.org_id = hou.organization_id AND (SELECT hl.country FROM hz_cust_site_uses_all hcsu, hz_locations hl WHERE hcas.cust_acct_site_id = hcsu.cust_acct_site_id AND hps.location_id = hl.location_id AND hcsu.status = 'A' AND hcsu.site_use_code LIKE 'BILL_TO') = 'US' GROUP BY hca.cust_account_id, hp.party_name, hca.account_number, hp.creation_date, hou.NAME, hcas.org_id, hp.party_id ORDER BY hca.cust_account_id DESC";
                    try
                    {
                       EbizChAchAMImpl oam = (EbizChAchAMImpl)pageContext.getApplicationModule(webBean);
                       PayMethodACHMasterVOImpl vo1 = (PayMethodACHMasterVOImpl)oam.findViewObject("PayMethodACHMasterVO1");
                          vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                           vo1. setQuery(query);
                          vo1.executeQuery();
                     }
                     catch (Exception e)
                     {
                         throw new OAException("Updating Query.  Exception: " + e.getMessage(), OAException.ERROR);
                     } 
				
	String getMerchantData=getMerchantData(pageContext,webBean);
	
	if ("false".equals(getMerchantData))
	{
		OASubmitButtonBean sendReqBtn = (OASubmitButtonBean) webBean.findChildRecursive("sendReqBtn");
		sendReqBtn.setDisabled(true);
		throw new OAException("Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.", OAException.WARNING);
	}

  }

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    if(pageContext.isLovEvent())  
        {  
             String lovInputSourceId = pageContext.getLovInputSourceId();  
			  
             if("TemplateLovIn".equals(lovInputSourceId)) {  
                  
            
				  String  Str1 =  String.valueOf(pageContext.getParameter("TemplateLovIn")); 
				  String  Str2 =  String.valueOf(pageContext.getParameter("EmailFromIn"));
				  String  Str3 =  String.valueOf(pageContext.getParameter("EmailSubjectIn"));

                if (pageContext.getParameter("TemplateLovIn") != null || 
                    pageContext.getParameter("TemplateLovIn") != "") {
                    Str1 = pageContext.getParameter("TemplateLovIn");
                    OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
                    lovBean.setText(pageContext,Str1);
                   
                } else {
                    throw new OAException("TemplteName in Lov is null .", 
                                          OAException.ERROR);
                }
                if (pageContext.getParameter("EmailFromIn") != null || 
                    pageContext.getParameter("EmailFromIn") != "") {
                    Str2 = pageContext.getParameter("EmailFromIn");
                    OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
                       textBean.setText(Str2);
                } else {
                    throw new OAException("Email From in Lov is null .", 
                                          OAException.ERROR);
                }
                
                 if (pageContext.getParameter("EmailSubjectIn") != null || 
                     pageContext.getParameter("EmailSubjectIn") != "") {
                     Str3 = pageContext.getParameter("EmailSubjectIn");
                     OAMessageTextInputBean textBeanEmailFromIn = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
                      textBeanEmailFromIn.setText(Str3);  
                 } else {
                     throw new OAException("Subject From in Lov is null .", 
                                           OAException.ERROR);
                 } 


                  
             }  
        } 
		
    
      if (pageContext.getParameter("sendReqBtn") != null) {

          EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
          PayMethodACHMasterVOImpl custVo = am.getPayMethodACHMasterVO1();
          PayMethodACHMasterVORowImpl payMethodMasterVo = null;
          String excCollectAdd = " ";

          
          Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = rows.length;

          String inTemplateName="";
          String inSubject="";
          String inEmailNotes="";
          String inCustId="";
          String inFromMail="";
          String inEmailArr="";
          String outWebUrl = " ";
          String inCustName = "";
          String messageValue="";
          int error_count = 0;
		  String custIds="";
		  String SuccustIds="";
		  
	  int requestSentCount=0;
          
          if (pageContext.getParameter("EmailFromIn") != null) {
              inFromMail = pageContext.getParameter("EmailFromIn");
          }

        if (pageContext.getParameter("EmailSubjectIn") != null) {
            inSubject =   pageContext.getParameter("EmailSubjectIn");
          }

          
            if (pageContext.getParameter("TemplateLovIn")== null || 
                    pageContext.getParameter("TemplateLovIn") == "") {
                    OAFormValueBean TemplateIdFvInputNew = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
					TemplateIdFvInputNew.setText(pageContext,"");
                    
                }
				
           OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
           inTemplateName = TemplateIdFvInput.getText(pageContext);
          
		   OAFormValueBean EmailSubjectFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailSubjectFv");
           inSubject = EmailSubjectFvInput.getText(pageContext);
		  
		   OAFormValueBean EmailFromFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromFv");
           inFromMail = EmailFromFvInput.getText(pageContext);
		   

          if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  payMethodMasterVo = (PayMethodACHMasterVORowImpl) rows[i];
                  
                  inCustId = (String) payMethodMasterVo.getAttribute("AccountNumber");
                      inCustName = (String) payMethodMasterVo.getAttribute("CustomerName");
                  inEmailArr = (String) payMethodMasterVo.getAttribute("Email");
                  
                   String[] validationsMessage = isValidate(inFromMail,inSubject,inTemplateName,inCustId,inEmailArr);
                   if (validationsMessage[0].equals("1")) {
                     messageValue = messageValue + validationsMessage[1];
                     custIds =validationsMessage[2]+", "+custIds;
					
                   }
				   else
				   {
					  SuccustIds =validationsMessage[3]+", "+SuccustIds;  
				   }
                       /*New Code by hamza*/
                   if (validationsMessage[0].equals("1")){
                      error_count++; 
                   }
                   else{
                  outWebUrl = outWebUrl + setEbizWebForm(pageContext,webBean,inEmailArr,inTemplateName,inFromMail,inSubject,inEmailNotes,inCustId,inCustName);
                  requestSentCount++;
                   }
              }

              messageValue = getDistinctString(pageContext,webBean,messageValue);
              if(requestSentCount>0 && error_count>0){
                  
                  throw new OAException(requestSentCount+" request(s) sent successfully against your selected Customer No.(s) "+ SuccustIds.substring(0, SuccustIds.length() -2)  + " and " + error_count + " request(s) were not sent successfully because these fields '"+messageValue+"' were not found against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2)   , OAException.WARNING);          
              }
              else if(requestSentCount>0 && error_count==0)
              {
                  throw new OAException(requestSentCount+" request(s) sent successfully against the Customer No. "+ SuccustIds.substring(0, SuccustIds.length() -2), OAException.INFORMATION);
              }
              else if(requestSentCount<=0 && error_count>0)
              {
                  
                  throw new OAException(error_count + " request(s) were not sent because these fields '"+messageValue+"' were not found against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2) , OAException.ERROR);
              }
              else{
                  throw new OAException("Error sending request(s), check log.", OAException.ERROR);
              }

          }

	 throw new OAException("Please select customer to send the request.", OAException.WARNING);

      }
      super.processFormRequest(pageContext, webBean);
  }
  
    
      public String  setEbizWebForm(OAPageContext pageContext, OAWebBean webBean, String inEmailArr, String inTemplateName, String inFromMail, String inSubject, String inEmailNotes, String inCustId, String inCustName) {
          
        String errorMsgList = "";
        String webUrl = "";
        String userId = String.valueOf(pageContext.getUserId());
        String[] emailArray = tokenizerStr(inEmailArr);
            for(int i = 0; i<emailArray.length; i++) {
                int pendingReqId = getPendingReqId(pageContext, webBean, emailArray[i],inCustId);
                 if(pendingReqId == 0){
            
          
                          
                         String[]  webUrlOne = sendEbizWebFormURL(pageContext,webBean,emailArray[i],inFromMail ,inCustId,inEmailNotes,inTemplateName,inSubject);
                         String errorcode  = webUrlOne[0] ;
                         String errormsg  = webUrlOne[1] ;
                         String epaymentURL  = webUrlOne[2]  ;
                         webUrl = webUrl + epaymentURL +"  ";
                  
                   if("E".equals(errorcode)){
                       throw new OAException("Error while sending the request. Message: "+errormsg, OAException.ERROR);
                   }  


                 if(addPendingPayment(pageContext, webBean, inCustId , inCustName , emailArray[i] ,epaymentURL  ,inTemplateName  ,inSubject ,inEmailNotes , inFromMail  , emailArray[i] ,userId )){                         
                     }
                 }
                 else{
                         String[] pendingReqDetails = getPendingReqDetails(pageContext, webBean, pendingReqId);
                         String inUrlId = pendingReqDetails[0];
                         String inSentCountStr = pendingReqDetails[1];
                         String inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                         int inSentCountInt = Integer.parseInt(inSentCountStr);
			 inSentCountInt = inSentCountInt + 1;
                    String responseResend[] =resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId);
                    String rurl= responseResend[0];
                     webUrl = webUrl +  rurl;
                     
                     if(updatePendingReqCount(pageContext, webBean, pendingReqId, inSentCountInt) ) {
                        
                     }else{
                        throw new OAException("Update Pending Request: inPendingReqIdInt. "+pendingReqId+ " inSentCountInt:"+inSentCountInt, OAException.ERROR);
                     }
                 }
                
            }
            
            return webUrl;
      }
  
    public String[] sendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String inemailaddress , String inFromEmail, String CustomerId ,String EmailNotes,String intempName, String inSubject){
          
      
          String resp[] = new String[3] ;
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  Ebizch_wlt_Req_ACH_pkg.get_webformURL_byclass(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                      OADBTransaction.DEFAULT);
                  
                        callableStatement.setString(1,inemailaddress );
                        callableStatement.setString(2, inFromEmail);
                        callableStatement.setString(3, CustomerId);
                        callableStatement.setString(4, EmailNotes);
                        callableStatement.registerOutParameter(5, Types.VARCHAR);
                        callableStatement.registerOutParameter(6, Types.VARCHAR);
                        callableStatement.registerOutParameter(7, Types.VARCHAR);
						callableStatement.setString(8, intempName);
                        callableStatement.setString(9, inSubject);
                     
                        callableStatement.execute();
                     
                        String      errorcode = callableStatement.getString(5);
                        String      errormsg = callableStatement.getString(6);
                        String      epayURL = callableStatement.getString(7);

                              resp[0] = errorcode;
                              resp[1] = errormsg;
                              resp[2] = epayURL;
                          
                    

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }

  
    public String[] getEmailTemplate(OAPageContext pageContext, OAWebBean webBean){
          
      
          String resp[] = new String[3];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_EmailTemplates(:1,:2,:3,:4); end;",
                      OADBTransaction.DEFAULT);
                  
                          callableStatement.setString(1,"Securely Add a Payment Method");
                          callableStatement.registerOutParameter(2, Types.VARCHAR);
                          callableStatement.registerOutParameter(3, Types.VARCHAR);
                          callableStatement.registerOutParameter(4, Types.VARCHAR);
                     
                     callableStatement.execute();
                      
                        String      o_subject = callableStatement.getString(2);
                        String      errorcode = callableStatement.getString(3);
                        String      errormsg = callableStatement.getString(4);

                              resp[0] = o_subject;
                              resp[1] = errorcode;
                              resp[2] = errormsg;
                          
                     

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getEmailTemplate Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }
    
  

    public String[] getEmailTemplateFetch(OAPageContext pageContext, OAWebBean webBean){
          
      
          String resp[] = new String[6];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_EmailTemplatesFetch_gw(:1,:2,:3,:4,:5,:6); end;",
                      OADBTransaction.DEFAULT);
                          
                    callableStatement.registerOutParameter(1, Types.VARCHAR);
                    callableStatement.registerOutParameter(2, Types.VARCHAR);
                    callableStatement.registerOutParameter(3, Types.VARCHAR);
                    callableStatement.registerOutParameter(4, Types.VARCHAR);
                    callableStatement.registerOutParameter(5, Types.VARCHAR);
                    callableStatement.registerOutParameter(6, Types.VARCHAR); 
                     callableStatement.execute();
					 
                     String      o_temp = callableStatement.getString(1);
                     String      o_subject = callableStatement.getString(2);
                     String      o_fromemail = callableStatement.getString(3);
                     String      o_fromname = callableStatement.getString(4);
                     String      errorcode = callableStatement.getString(5);
                     String      errormsg = callableStatement.getString(6);
                     
                     resp[0] = o_temp;
                     resp[1] = o_subject;
                     resp[2] = o_fromemail;
                     resp[3] = o_fromname;
                     resp[4] = errorcode;
                     resp[5] = errormsg;
                          
                     

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }
    



  
      
      public String[] tokenizerStr(String inEmailArr){
          String  inputString = inEmailArr.replaceAll("\\s+", "");
          String[] arry = inputString.split(",");
          
          return arry;
      }
      
      public boolean isValidEmailAddress(String email) {
         boolean result = true;
         try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
         } catch (AddressException ex) {
            result = false;
         }
         return result;
      }
      
      public void checkEmailAddress(String inEmailArr){
          String[] emailArray = tokenizerStr(inEmailArr);
              
              for(int i = 0; i<emailArray.length; i++) {
                if(isValidEmailAddress(emailArray[i])){
                    
                }
                else{
                    
                    throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                }
              }
      }

    public Boolean addPendingPayment(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_customerno , String p_customername , String p_email , String p_outebizurl  , String p_intemplatename  , String p_insubject ,String p_inemailnotes , String p_infrommail  , String p_intomail , String p_created_by ){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.add_pending_pay_method_req(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;",
                         OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, p_customerno);
                             stmtaddTemplate.setString(2, p_customername);
                             stmtaddTemplate.setString(3, p_email);
                             stmtaddTemplate.setString(4, p_outebizurl);
                             stmtaddTemplate.setString(5, p_intemplatename);
                             stmtaddTemplate.setString(6, p_insubject);
                             stmtaddTemplate.setString(7, p_inemailnotes);
                             stmtaddTemplate.setString(8, p_infrommail);
                             stmtaddTemplate.setString(9, p_intomail);
                             stmtaddTemplate.setString(10, p_created_by);
                           
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Templates Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      }


    
    public int getPendingReqId(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inEmail, String inCustId){
          CallableStatement stmtGetPendingReqId;
          int pendingreqId;
          
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtGetPendingReqId = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_pmrid_from_email(:1,:2,:3); end;",
                         OADBTransaction.DEFAULT);
                     

                            stmtGetPendingReqId.setString(1, inEmail); 
                            stmtGetPendingReqId.setString(2, inCustId);
                            stmtGetPendingReqId.registerOutParameter(3, Types.VARCHAR);
                             
                             
                         stmtGetPendingReqId.execute();
                            
                            String pendingReqIdStr = stmtGetPendingReqId.getString(3);  
                            pendingreqId =  Integer.parseInt(pendingReqIdStr);

                         stmtGetPendingReqId.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Get Pending Request ID from db exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return pendingreqId;
      }
      
    public String[] getPendingReqDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,int inPendingReqId) {
        String errMsg="";
        String arrOutput[] = new String[2]; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_pmr_detail_from_pid(:1,:2,:3); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
               callableStatement.setInt(1, inPendingReqId); 
             callableStatement.registerOutParameter(2, Types.LONGVARCHAR);  
               callableStatement.registerOutParameter(3, Types.VARCHAR); 
           
           
             callableStatement.execute();  
           
             arrOutput[0] = callableStatement.getString(2);  
             arrOutput[1] = callableStatement.getString(3);  
             
             
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Pending Req Details: " + e.getMessage(), OAException.ERROR);
           }   
    return arrOutput;
    }   
    
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum){

          String resp[] = new String[3];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_resendEbizWebFormURL(:1,:2,:3,:4,:5); end;",
                      OADBTransaction.DEFAULT);
                  
                        callableStatement.setString(1, custNum);
                        callableStatement.setString(2, internalId);
                        callableStatement.registerOutParameter(3, Types.VARCHAR);
                        callableStatement.registerOutParameter(4, Types.VARCHAR);
                        callableStatement.registerOutParameter(5, Types.VARCHAR);
                     
                        callableStatement.execute();
                        String  rurl = callableStatement.getString(3);
                        String  errorcode = callableStatement.getString(4);
                        String  errormsg = callableStatement.getString(5);
                     resp[0] = rurl;
                     resp[1] = errorcode;
                     resp[2] = errormsg;
                          
                     

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          
          return resp;
      }
   
    public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
             CallableStatement stmtaddTemplate;
          String userId = String.valueOf(paramOAPageContext.getUserId());
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.update_pending_request_count(:1,:2,:3); end;",
                         OADBTransaction.DEFAULT);
						
						 stmtaddTemplate.setInt(1, pendingreqId);
                             stmtaddTemplate.setInt(2, count); 
                             stmtaddTemplate.setString(3, userId); 
                                                        
                         stmtaddTemplate.execute();
						 

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      } 
      

  
      
      
    public String[] isValidate(String inFromMail,String inSubject,String inTemplateName,String inCustId,String inEmailArr) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
	  
	   if (inTemplateName=="" || inTemplateName==null) {
        retMessage = retMessage + "Template Name,";
      }
	  
      if (inFromMail==null || inFromMail=="") {
        retMessage = retMessage + "From Email Address,";
      }

      if (inSubject==null || inSubject=="") {
        retMessage = retMessage + "Subject,";
      }

     

      if (inCustId==null || inCustId=="") {
        retMessage = retMessage + "Customer No,";
      }
      if (inEmailArr==null || inEmailArr=="" ) {
        retMessage = retMessage + "To Email";
      }
        if ("N/A".equals(inEmailArr)) {
          retMessage = retMessage + "To Email";
        }
      
      if (retMessage!="") {
        output[0] = "1";
	    retValue = retMessage ;
	   // custId=inCustId +"," +custId;
	   
        output[1] = retValue;
		output[2] = inCustId;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Request of Payment Method is validated.";
		output[3] = inCustId;
      }
      return output;
    }

    public String[] getDefaultEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
        String errMsg="";
        String arrOutput[] = new String[3]; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_pmr_pkg.get_gw_email_templates(:1,:2,:3); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             callableStatement.registerOutParameter(2, Types.VARCHAR);  
               callableStatement.registerOutParameter(3, Types.VARCHAR); 
           
           
             callableStatement.execute();  
           
             arrOutput[0] = callableStatement.getString(1);  
             arrOutput[1] = callableStatement.getString(2);  
               arrOutput[2] = callableStatement.getString(3);  
             
             
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
           }   
    return arrOutput;
    }
    
    public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.TRUNCATETABLE; end;",
                         OADBTransaction.DEFAULT);
                     
                           
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
            
      }
    
    
    public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput[] = new String[2]; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             callableStatement.registerOutParameter(2, Types.VARCHAR);  
            
           
             callableStatement.execute();  
           
             arrOutput[0] = callableStatement.getString(1);  
             arrOutput[1] = callableStatement.getString(2);  
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }
	
	  public String getMerchantData(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput=""; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wallet_common_pkg.get_merchant_transaction_ach(:1); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             
             callableStatement.execute();  
           
             arrOutput = callableStatement.getString(1);   
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get getMerchantData Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }
    
   public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   } 
    
}
