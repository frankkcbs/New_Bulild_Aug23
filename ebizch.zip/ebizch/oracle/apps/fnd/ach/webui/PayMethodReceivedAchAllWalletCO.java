/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package ebizch.oracle.apps.fnd.ach.webui;

import java.sql.CallableStatement;
import java.sql.SQLException;
import ebizch.oracle.apps.fnd.ach.server.EbizChAchAMImpl;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.jbo.Row;
import oracle.jbo.domain.Number;
import ebizch.oracle.apps.fnd.ach.server.PayMethodReceivedAchImpl;
import ebizch.oracle.apps.fnd.ach.server.PayMethodReceivedAchRowImpl;




import java.sql.Types;

/**
 * Controller for ...
 */
public class PayMethodReceivedAchAllWalletCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
      am.initPayMethodReceivedAch();
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
	      
    super.processFormRequest(pageContext, webBean);
  }
}
    