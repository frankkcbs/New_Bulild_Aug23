

/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package ebizch.oracle.apps.fnd.ach.webui;

import ebizch.oracle.apps.fnd.ach.server.EbizChAchAMImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.jbo.Row;
import oracle.jbo.domain.Number;
import ebizch.oracle.apps.fnd.ach.server.PayMethodPendingACHReqImpl;
import ebizch.oracle.apps.fnd.ach.server.PayMethodPendingACHReqRowImpl;




import java.sql.Types;

/**
 * Controller for ...
 */
public class PayMethodPendingReqAllWalletAchCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
      am.initPayMethodPendingACHReq();
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      if (pageContext.getParameter("ResendReqBtn") != null) {

          EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
          am.getPayMethodPendingReq1();
          PayMethodPendingACHReqImpl custVo = am.getPayMethodPendingACHReq1();
          PayMethodPendingACHReqRowImpl payMethodPendingVo = null;
          String excCollectAdd = " ";
          
          Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = rows.length;

          String inPendingReqId="";
          String inCustId="";
          String inCustName="";
          String inUrlId="";
          String inSentCount="";
          String outWebUrl="";
          String inUrlIdStr = "";
	      int requestSentCount=0;
          String messageValue="";
		  String custIds="";
		  String SuccustIds="";
		  
          int error_count = 0;
          if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  payMethodPendingVo = (PayMethodPendingACHReqRowImpl) rows[i];
                  
                  //inPendingReqId = (String) payMethodPendingVo.getAttribute("Pendingreqid");
                  
                  Number inPendingReqIdNumb = (Number) payMethodPendingVo.getAttribute("Pendingreqid");
                  String inPendingReqIdString = inPendingReqIdNumb.toString();
                  int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                  
                  inCustId = (String) payMethodPendingVo.getAttribute("Customerno");
                  inCustName = (String) payMethodPendingVo.getAttribute("Customername");
                  inUrlId = (String) payMethodPendingVo.getAttribute("Outebizurl");
                  inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                  
                  inSentCount = (String) payMethodPendingVo.getAttribute("Sentcount");
                  int inSentCountInt = Integer.parseInt(inSentCount);
                  inSentCountInt = inSentCountInt + 1;
                  
                   String[] validationsMessage = isValidateResend( inUrlIdStr, inSentCountInt, inPendingReqIdInt, inCustId);

                   if (validationsMessage[0].equals("1")) {
                     messageValue = messageValue + validationsMessage[1];
                   custIds =validationsMessage[2]+", "+custIds;
					
                   }
				   else
				   {
					  SuccustIds =validationsMessage[3]+", "+SuccustIds;  
				   }
                    
					   /*New Code by hamza*/
                   if (validationsMessage[0].equals("1")){
                      error_count++; 
                   }
                   else{
                   String responseResend[] = resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId);
                   String rurl = responseResend[0];
                   outWebUrl = outWebUrl +  rurl;
                       
                   
                  if(updatePendingReqCount(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                      requestSentCount++;
                  }else{
                      throw new OAException("Update Pending Request: inPendingReqIdInt. "+inPendingReqIdInt+ " inSentCountInt:"+inSentCountInt, OAException.ERROR);
                  }
                   }
                  
              }

			messageValue = getDistinctString(pageContext,webBean,messageValue);
            if(requestSentCount>0 && error_count>0){
                am.initPayMethodPendingACHReq();
                
            throw new OAException(requestSentCount+" request(s) resent successfully against your selected Customer No.(s) "+ SuccustIds.substring(0, SuccustIds.length() -2)  + " and " + error_count + " request(s) were not sent successfully because these fields '"+messageValue+"' were not found against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2)   , OAException.WARNING);          
			}
            else if(requestSentCount>0 && error_count==0)
            {
                am.initPayMethodPendingACHReq();
                
            throw new OAException(requestSentCount+" request(s) resent successfully against your selected Customer No.(s) "+ SuccustIds.substring(0, SuccustIds.length() -2), OAException.INFORMATION);
			}
            else if(requestSentCount<=0 && error_count>0)
            {  
                am.initPayMethodPendingACHReq();
                
            throw new OAException(error_count + " request(s) were not resent because these fields '"+messageValue+"' were not found against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2) , OAException.ERROR);
			}
            else{
              
                throw new OAException("Error sending request(s), check log.", OAException.ERROR);
            }
            
          }

		throw new OAException("Please select request to send it again.", OAException.WARNING);

      }
      
      if (pageContext.getParameter("RemovePendingReqBtn") != null) {
          
              EbizChAchAMImpl am = (EbizChAchAMImpl) pageContext.getApplicationModule(webBean);
              PayMethodPendingACHReqImpl custVo = am.getPayMethodPendingACHReq1();
              PayMethodPendingACHReqRowImpl payMethodPendingVo = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              String messageValue="";
			  int error_count = 0;
              int cardAddedCount = 0;
              String custIds="";
			  String SuccustIds="";
		      String payIntId="";
			  
			  
              if (rowsLength > 0) {
                  for (int i = 0; i < rowsLength; i++) {
                      payMethodPendingVo = (PayMethodPendingACHReqRowImpl) rows[i];
                      
                      //inPendingReqId = (String) payMethodPendingVo.getAttribute("Pendingreqid");
                      inCustId = (String) payMethodPendingVo.getAttribute("Customerno");
                      Number inPendingReqIdNumb = (Number) payMethodPendingVo.getAttribute("Pendingreqid");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      payIntId = (String) payMethodPendingVo.getAttribute("Outebizurl");
					  payIntId=payIntId.substring(payIntId.length() -36);
					  
					  
                     String[] validationsMessage = isValidateRemove( inPendingReqIdInt, inCustId);

                     if (validationsMessage[0].equals("1")) {
                       messageValue = messageValue + validationsMessage[1];
                       custIds =validationsMessage[2]+", "+custIds;
					
					}
					else
					{
					  SuccustIds =validationsMessage[3]+", "+SuccustIds;  
					}
						
                     if (validationsMessage[0].equals("1")){
                        error_count++; 
                     }
                     else{
						 
					String[] deleteEmail=delete_webform_email(pageContext, webBean,inCustId ,payIntId);
					 if(deleteEmail[0].equals("S")){	  
						// if(removePendingReq(pageContext, webBean, inPendingReqIdInt)) { 
							  cardAddedCount++;
						// }
                  }else{
					  error_count++;
                     
                  }

                     }
              
                 }

                
                   if(cardAddedCount>0 && error_count>0)
                   {
                       am.initPayMethodPendingACHReq();
                       throw new OAException(cardAddedCount+" request(s) deleted against your selected Customer No.(s) " +SuccustIds.substring(0, SuccustIds.length() -2) + " and " + error_count + "request(s) are not deleted against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2) , OAException.INFORMATION);          
                    }
                  else if(cardAddedCount>0 && error_count==0)
                  {
                      am.initPayMethodPendingACHReq();
                      throw new OAException(cardAddedCount+" request(s) deleted against your selected Customer No.(s) " +SuccustIds.substring(0, SuccustIds.length() -2), OAException.INFORMATION);          
                   }
                  else if(cardAddedCount<=0 && error_count>0)
                  {
                      am.initPayMethodPendingACHReq();
                      throw new OAException(error_count+" request(s) not deleted against your selected Customer No.(s) " + custIds.substring(0, custIds.length() -2) , OAException.INFORMATION);          
                   }
                    else{
                        throw new OAException("Request(s) not rdeleted.", OAException.ERROR);
                                     }
              }

		throw new OAException("Please select request(s) from the list.", OAException.WARNING);          

      }
      
    super.processFormRequest(pageContext, webBean);
  }
  
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum){

          String resp[]  = new String[3];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_resendEbizWebFormURL(:1,:2,:3,:4,:5); end;",
                      OADBTransaction.DEFAULT);
                  
                        callableStatement.setString(1, custNum);
                          callableStatement.setString(2, internalId);
                        callableStatement.registerOutParameter(3, Types.VARCHAR);
                        callableStatement.registerOutParameter(4, Types.VARCHAR);
                        callableStatement.registerOutParameter(5, Types.VARCHAR);
                     
                        callableStatement.execute();
                        String  rurl = callableStatement.getString(3);
                        String  errorcode = callableStatement.getString(4);
                        String  errormsg = callableStatement.getString(5);

                     resp[0] = rurl;
                     resp[1] = errorcode;
                     resp[2] = errormsg;
                          
                      

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          
          return resp;
      }
   
 

    public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
             CallableStatement stmtaddTemplate;
          String userId = String.valueOf(paramOAPageContext.getUserId());
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.update_pending_request_count(:1,:2,:3); end;",
                         OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setInt(1, pendingreqId);
                             stmtaddTemplate.setInt(2, count); 
                             stmtaddTemplate.setString(3, userId); 
                             
                             
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      }
      
    public Boolean removePendingReq(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId){
             CallableStatement stmtaddTemplate;
          String userId = String.valueOf(paramOAPageContext.getUserId());
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.remove_pending_request(:1,:2); end;",
                         OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setInt(1, pendingreqId);
                             stmtaddTemplate.setString(2, userId); 
                             
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Remove Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      }
    public String[] isValidateResend(String inUrlIdStr,int inSentCountInt,int inPendingReqIdInt,String inCustId) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
      if (inUrlIdStr==null || inUrlIdStr=="") {
        retMessage = retMessage + "URL,";
      }

      if (String.valueOf(inSentCountInt)==null || String.valueOf(inSentCountInt)=="") {
        retMessage = retMessage + "Sent Count,";
      }

      if (String.valueOf(inPendingReqIdInt)==null || String.valueOf(inPendingReqIdInt)=="") {
        retMessage = retMessage + "Pending Req Count,";
      }

      if (inCustId==null || inCustId=="") {
        retMessage = retMessage + "Customer No,";
      }
     
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage;
        output[1] = retValue;
		output[2] = inCustId;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Data is validated.";
		output[3] = inCustId;
      }
      return output;
    }
    public String[] isValidateRemove(int inPendingReqIdInt,String inCustId) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
    
      if (String.valueOf(inPendingReqIdInt)==null || String.valueOf(inPendingReqIdInt)=="") {
        retMessage = retMessage + "Pending Req Count,";
          
      }

      if (inCustId==null || inCustId=="") {
        retMessage = retMessage + "Customer No,";
      }
       
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage;
        output[1] = retValue;
		output[2] = inCustId;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Data is validated.";
		output[3] = inCustId;
      }
      return output;
    }   
   public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   } 	
       public String[] delete_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String CustNumVal ,String pay_int_id ){
             CallableStatement stmtaddTemplate;
			    String[] addDetails = new String[2]; 
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ach_pkg.delete_webform_email(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, CustNumVal);
                             stmtaddTemplate.setString(2, pay_int_id);
                             stmtaddTemplate.registerOutParameter(3, Types.VARCHAR);
                             stmtaddTemplate.registerOutParameter(4, Types.VARCHAR);
                             
                             
                         stmtaddTemplate.execute();
                           addDetails[0] = stmtaddTemplate.getString(3);
                           addDetails[1] = stmtaddTemplate.getString(4);
                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return addDetails;
      }	
}
