package ebizch.oracle.apps.fnd.ach.server;
 
 import oracle.apps.fnd.framework.server.OAViewRowImpl;
 import oracle.jbo.domain.Date;
 import oracle.jbo.domain.Number;
 import oracle.jbo.server.AttributeDefImpl;
 
 public class PayMethodReceivedAchRowImpl extends OAViewRowImpl {
   public static final int PENDINGREQID = 0;
   public static final int CUSTOMERNO = 1;  
   public static final int CUSTOMERNAME = 2;  
   public static final int EMAIL = 3;  
   public static final int EMAILSENTTIME = 4; 
   public static final int SENTCOUNT = 5;  
   public static final int OUTEBIZURL = 6; 
   public static final int INTEMPLATENAME = 7;   
   public static final int INSUBJECT = 8;   
   public static final int INEMAILNOTES = 9;   
   public static final int INFROMMAIL = 10;   
   public static final int INTOMAIL = 11;   
   public static final int CREATEDAT = 12;   
   public static final int CREATEDBY = 13;   
   public static final int LASTUPDATEDAT = 14;   
   public static final int LASTUPDATEDBY = 15;   
   public static final int REMOVEFLAG = 16;   
   public static final int LAST4 = 17; 
   public static final int VIEWATTR = 18;
   
   public Number getPendingreqid() {
     return (Number)getAttributeInternal(PENDINGREQID);
   }
   
   public void setPendingreqid(Number paramNumber) {
    setAttributeInternal(PENDINGREQID, paramNumber);
   }
   
   public String getCustomerno() {
     return (String)getAttributeInternal(CUSTOMERNO);
   }
   
   public void setCustomerno(String paramString) {
    setAttributeInternal(CUSTOMERNO, paramString);
   }
   
   public String getCustomername() {
    return (String)getAttributeInternal(CUSTOMERNAME);
   }
   
   public void setCustomername(String paramString) {
    setAttributeInternal(CUSTOMERNAME, paramString);
   }
   
   public String getEmail() {
     return (String)getAttributeInternal(EMAIL);
   }
   
   public void setEmail(String paramString) {
     setAttributeInternal(EMAIL, paramString);
   }
   
   public String getEmailsenttime() {
   return (String)getAttributeInternal(EMAILSENTTIME);
   }
   
   public void setEmailsenttime(String paramDate) {
     setAttributeInternal(EMAILSENTTIME, paramDate);
   }
   
   public String getSentcount() {
   return (String)getAttributeInternal(SENTCOUNT);
   }
   
   public void setSentcount(String paramString) {
     setAttributeInternal(SENTCOUNT, paramString);
   }
   
   public String getOutebizurl() {
     return (String)getAttributeInternal(OUTEBIZURL);
   }
   
   public void setOutebizurl(String paramString) {
     setAttributeInternal(OUTEBIZURL, paramString);
   }
   
   public String getIntemplatename() {
     return (String)getAttributeInternal(INTEMPLATENAME);
   }
   
   public void setIntemplatename(String paramString) {
     setAttributeInternal(INTEMPLATENAME, paramString);
   }
   
   public String getInsubject() {
     return (String)getAttributeInternal(INSUBJECT);
   }
   
   public void setInsubject(String paramString) {
     setAttributeInternal(INSUBJECT, paramString);
   }
   
   public String getInemailnotes() {
     return (String)getAttributeInternal(INEMAILNOTES);
   }
   
   public void setInemailnotes(String paramString) {
     setAttributeInternal(INEMAILNOTES, paramString);
   }
   
   public String getInfrommail() {
    return (String)getAttributeInternal(INFROMMAIL);
   }
   
   public void setInfrommail(String paramString) {
     setAttributeInternal(INFROMMAIL, paramString);
   }
   
   public String getIntomail() {
     return (String)getAttributeInternal(INTOMAIL);
   }
   
   public void setIntomail(String paramString) {
    setAttributeInternal(INTOMAIL, paramString);
   }
   
   public Date getCreatedAt() {
    return (Date)getAttributeInternal(CREATEDAT);
   }
   
   public void setCreatedAt(Date paramDate) {
     setAttributeInternal(CREATEDAT, paramDate);
   }
   
   public Number getCreatedBy() {
     return (Number)getAttributeInternal(CREATEDBY);
   }
   
   public void setCreatedBy(Number paramNumber) {
     setAttributeInternal(CREATEDBY, paramNumber);
   }
   
   public String getLastUpdatedAt() {
     return (String)getAttributeInternal(LASTUPDATEDAT);
   }
   
   public void setLastUpdatedAt(String paramDate) {
     setAttributeInternal(LASTUPDATEDAT, paramDate);
   }
   
   public Number getLastUpdatedBy() {
     return (Number)getAttributeInternal(LASTUPDATEDBY);
   }
   
   public void setLastUpdatedBy(Number paramNumber) {
     setAttributeInternal(LASTUPDATEDBY, paramNumber);
   }
   
   public String getRemoveFlag() {
     return (String)getAttributeInternal(REMOVEFLAG);
   }
   
   public void setRemoveFlag(String paramString) {
    setAttributeInternal(REMOVEFLAG, paramString);
   }
   
   protected Object getAttrInvokeAccessor(int paramInt, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
       case PENDINGREQID:
         return getPendingreqid();
       case CUSTOMERNO:
       return getCustomerno();
       case CUSTOMERNAME:
         return getCustomername();
       case EMAIL:
        return getEmail();
       case EMAILSENTTIME:
         return getEmailsenttime();
       case SENTCOUNT:
       return getSentcount();
       case OUTEBIZURL:
        return getOutebizurl();
       case INTEMPLATENAME:
      return getIntemplatename();
       case INSUBJECT:
       return getInsubject();
       case INEMAILNOTES:
        return getInemailnotes();
       case INFROMMAIL:
        return getInfrommail();
       case INTOMAIL:
        return getIntomail();
       case CREATEDAT:
       return getCreatedAt();
       case CREATEDBY:
       return getCreatedBy();
       case LASTUPDATEDAT:
        return getLastUpdatedAt();
       case LASTUPDATEDBY:
        return getLastUpdatedBy();
       case REMOVEFLAG:
       return getRemoveFlag();
	   case LAST4:
       return getLast4();
       case VIEWATTR:
      return getViewAttr();
     } 
    return super.getAttrInvokeAccessor(paramInt, paramAttributeDefImpl);
   }
   
   protected void setAttrInvokeAccessor(int paramInt, Object paramObject, AttributeDefImpl paramAttributeDefImpl) throws Exception {
     switch (paramInt) {
       case PENDINGREQID:
         setPendingreqid((Number)paramObject);
         return;
       case CUSTOMERNO:
        setCustomerno((String)paramObject);
         return;
       case CUSTOMERNAME:
       setCustomername((String)paramObject);
         return;
       case EMAIL:
       setEmail((String)paramObject);
         return;
       case EMAILSENTTIME:
        setEmailsenttime((String)paramObject);
         return;
       case SENTCOUNT:
        setSentcount((String)paramObject);
         return;
       case OUTEBIZURL:
        setOutebizurl((String)paramObject);
         return;
       case INTEMPLATENAME:
       setIntemplatename((String)paramObject);
         return;
       case INSUBJECT:
        setInsubject((String)paramObject);
         return;
       case INEMAILNOTES:
        setInemailnotes((String)paramObject);
         return;
       case INFROMMAIL:
        setInfrommail((String)paramObject);
         return;
       case INTOMAIL:
        setIntomail((String)paramObject);
         return;
       case CREATEDAT:
         setCreatedAt((Date)paramObject);
         return;
       case CREATEDBY:
        setCreatedBy((Number)paramObject);
         return;
       case LASTUPDATEDAT:
         setLastUpdatedAt((String)paramObject);
         return;
       case LASTUPDATEDBY:
        setLastUpdatedBy((Number)paramObject);
         return;
       case REMOVEFLAG:
        setRemoveFlag((String)paramObject);
         return;
		 case LAST4:
        setLast4((String)paramObject);
         return;
       case VIEWATTR:
         setViewAttr((String)paramObject);
         return;
     } 
     super.setAttrInvokeAccessor(paramInt, paramObject, paramAttributeDefImpl);
   }
   
   public String getViewAttr() {
     return (String)getAttributeInternal(VIEWATTR);
   }
   
   public void setViewAttr(String paramString) {
    setAttributeInternal(VIEWATTR, paramString);
   }
   
   public String getLast4() {
     return (String)getAttributeInternal(LAST4);
   }
   
   public void setLast4(String paramString) {
    setAttributeInternal(LAST4, paramString);
   }
 }

