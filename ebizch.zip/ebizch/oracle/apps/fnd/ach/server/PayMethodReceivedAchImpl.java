package ebizch.oracle.apps.fnd.ach.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class PayMethodReceivedAchImpl extends OAViewObjectImpl {
	
	 public PayMethodReceivedAchImpl() {
    }
	
}


