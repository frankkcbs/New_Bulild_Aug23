/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package ebizch.oracle.apps.fnd.rtsync.webui;

 import java.sql.CallableStatement;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
 import java.sql.SQLException;
import java.sql.Types;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustAchVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustAchVORowImpl;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import com.sun.java.util.collections.HashMap;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.OAViewObject;
 import oracle.apps.fnd.framework.webui.beans.nav.OALinkBean;
 import oracle.apps.fnd.framework.OARow;
import oracle.jbo.Row;
import java.io.Serializable;
/**
 * Controller for ...
 */
public class EbizchCcRegionCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

  /**
   * Layout and page setup logic for a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      EbizChRtsyncAMImpl am = 
        (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
	  String CustomerNo = (String)pageContext.getTransactionValue("IbyCustAccountNumber");
	
      //am.initEbizChRtCustCcVO();
	  
	  String[] ccLov = creditCardLov(pageContext, webBean, CustomerNo);
      if(!ccLov[0].equals("S")){
          throw new OAException("Credit Card List are not populated. Error Message: "+ccLov[1], OAException.ERROR);    
      }
	      OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
		  VO.setWhereClause("customer_no="+CustomerNo);
		  VO.executeQuery();
		  
		  OAViewObject VO1 = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
		  VO1.setWhereClause("customer_no="+CustomerNo);
		  VO1.executeQuery();
		  
		  String getResp[] =new String[2];
		  getResp = getMerchantData(pageContext, webBean, CustomerNo);
		  String vAchFlag = getResp[0];
		  String vCcFlag = getResp[1];							 
					
					  if("true".equals(vCcFlag) && "true".equals(vAchFlag))
						{
						
						}
						 else if ("false".equals(vCcFlag) && "true".equals(vAchFlag))
						 {
					    OASubmitButtonBean AddNewCardBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewCardBtn");
						AddNewCardBtn.setDisabled(true);
						
						OASubmitButtonBean RequestCreditCardBtn = (OASubmitButtonBean)webBean.findChildRecursive("RequestCreditCardBtn");
						RequestCreditCardBtn.setDisabled(true);
						
						
						throw new OAException("Credit Card transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.",OAException.WARNING);
							 
						 }
						  else if ("true".equals(vCcFlag) && "false".equals(vAchFlag))
						  {
					    OASubmitButtonBean AddNewAchBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewAchBtn");
						AddNewAchBtn.setDisabled(true);
						
						OASubmitButtonBean RequestAchBtn = (OASubmitButtonBean)webBean.findChildRecursive("RequestAchBtn");
						RequestAchBtn.setDisabled(true);
						
						
						throw new OAException("Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.",OAException.WARNING);
							   
						  }
						  else if ("false".equals(vCcFlag) && "false".equals(vAchFlag))
						  {
							OASubmitButtonBean AddNewCardBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewCardBtn");
							AddNewCardBtn.setDisabled(true);
							
							OASubmitButtonBean RequestCreditCardBtn = (OASubmitButtonBean)webBean.findChildRecursive("RequestCreditCardBtn");
							RequestCreditCardBtn.setDisabled(true); 
							
							OASubmitButtonBean AddNewAchBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewAchBtn");
							AddNewAchBtn.setDisabled(true);
													
							OASubmitButtonBean RequestAchBtn = (OASubmitButtonBean)webBean.findChildRecursive("RequestAchBtn");
							RequestAchBtn.setDisabled(true);
							
							throw new OAException("Credit Card & Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.",OAException.WARNING);
						  }
						 
						/*if("true".equals(vAchFlag))
						{
						
						}
						 else 
						 {
					    OASubmitButtonBean AddNewCardBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewCardBtn");
						AddNewCardBtn.setDisabled(true);
						
						OASubmitButtonBean AddNewAchBtn = (OASubmitButtonBean)webBean.findChildRecursive("AddNewAchBtn");
						AddNewAchBtn.setDisabled(true);
						
						
						throw new OAException("Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.",OAException.WARNING);
							 
						 }*/
  }

  /**
   * Procedure to handle form submissions for form elements in
   * a region.
   * @param pageContext the current OA page context
   * @param webBean the web bean corresponding to the region
   */
  public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean)
  {
	   String CustomerNo = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
          String getResp[] =new String[2];
		  String vaccountnum[] =new String[2];
		 EbizChRtsyncAMImpl am = 
        (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);  
	   String str1 = paramOAPageContext.getParameter("event"); 
 if(paramOAPageContext.getParameter("AddNewAchBtn") != null){// if("AddNewAchBtn".equals(str1)){
                   String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                   String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                   String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                   String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                   String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                   String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                   
                   String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                   String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                   String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                   
                   String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                   String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                   String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                   String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                   
                   String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   
                   HashMap localHashMap = new HashMap();
                       localHashMap.put("IbyPayerPartyId", str3);
                       localHashMap.put("IbyPaymentFunction", str8);
                       localHashMap.put("IbyCustAccountId", str4);
                       localHashMap.put("IbyCustAccountSiteId", str5);
                       localHashMap.put("IbyOrgId", str6);
                       localHashMap.put("IbyOrgType", str7);
                       localHashMap.put("HzPuiAddressEvent", "CREATE");
                       localHashMap.put("HzPuiAddressLocationId", "");
                       localHashMap.put("IbyReturnLink", str9);
                       localHashMap.put("IbyReturnlink", str9);
                       localHashMap.put("IbyReturnLinkLabel", str10);
                       //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                       localHashMap.put("IbyPayerId", str11);
                       localHashMap.put("IbyPartyName", str13);
                       localHashMap.put("IbyOrgName", str12);
                       localHashMap.put("IbyCustAcctNumber", str14);
                       localHashMap.put("CUST_NO", str14);
                       localHashMap.put("IbyCustAcctSiteName", str15);
                       localHashMap.put("IbyReadOnlyFlag", str16);
                       localHashMap.put("IbyInstrumentType", "CREDITCARD");
                   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreateACHPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
               
               }
			   
                           else if(paramOAPageContext.getParameter("RequestAchBtn") != null){
                  String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                  String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                  String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                  String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                  String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                  String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                  
                  String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                  String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                  String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                  
                  String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                  String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                  String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                  String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                  
                  String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                  String str17 = (String)paramOAPageContext.getTransactionValue("HzPuiSubPartyName");
                  HashMap localHashMap = new HashMap();
                      localHashMap.put("IbyPayerPartyId", str3);
                      localHashMap.put("IbyPaymentFunction", str8);
                      localHashMap.put("IbyCustAccountId", str4);
                      localHashMap.put("IbyCustAccountSiteId", str5);
                      localHashMap.put("IbyOrgId", str6);
                      localHashMap.put("IbyOrgType", str7);
                      localHashMap.put("HzPuiAddressEvent", "CREATE");
                      localHashMap.put("HzPuiAddressLocationId", "");
                      localHashMap.put("IbyReturnLink", str9);
                      localHashMap.put("IbyReturnlink", str9);
                      localHashMap.put("IbyReturnLinkLabel", str10);
                      //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                      localHashMap.put("IbyPayerId", str11);
                      localHashMap.put("IbyPartyName", str13);
                      localHashMap.put("IbyOrgName", str12);
                      localHashMap.put("IbyCustAcctNumber", str14);
                      localHashMap.put("IbyCustAcctSiteName", str15);
                      localHashMap.put("IbyReadOnlyFlag", str16);
                      localHashMap.put("IbyInstrumentType", "CREDITCARD");
                      localHashMap.put("HzPuiSubPartyName", str17);
					  
					getResp = getMerchantData(paramOAPageContext, paramOAWebBean, str14);
					String vAchFlag = getResp[0];
					String vCcFlag = getResp[1];							 
					
					if("true".equals(vAchFlag))
						{
						paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/pmr/webui/EbizChargeRequestPayMethodWalletACHPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
						}
						 else 
						 {
					    OASubmitButtonBean RequestPayBtnAch = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("RequestAchBtn");
						RequestPayBtnAch.setDisabled(true);
							 
						 }
							 
              }
			  
	  if(paramOAPageContext.getParameter("AddNewCardBtn") != null){//"AddNewCardBtn".equals(str1)
                   String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                   String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                   String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                   String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                   String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                   String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                   
                   String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                   String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                   String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                   
                   String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                   String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                   String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                   String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                   
                   String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   
                   HashMap localHashMap = new HashMap();
                       localHashMap.put("IbyPayerPartyId", str3);
                       localHashMap.put("IbyPaymentFunction", str8);
                       localHashMap.put("IbyCustAccountId", str4);
                       localHashMap.put("IbyCustAccountSiteId", str5);
                       localHashMap.put("IbyOrgId", str6);
					   localHashMap.put("ORG_ID", str6);
                       localHashMap.put("IbyOrgType", str7);
                       localHashMap.put("HzPuiAddressEvent", "CREATE");
                       localHashMap.put("HzPuiAddressLocationId", "");
                       localHashMap.put("IbyReturnLink", str9);
                       localHashMap.put("IbyReturnlink", str9);
                       localHashMap.put("IbyReturnLinkLabel", str10);
                       //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                       localHashMap.put("IbyPayerId", str11);
                       localHashMap.put("IbyPartyName", str13);
                       localHashMap.put("IbyOrgName", str12);
                       localHashMap.put("IbyCustAcctNumber", str14);
                       localHashMap.put("CUST_NO", str14);
                       localHashMap.put("IbyCustAcctSiteName", str15);
                       localHashMap.put("IbyReadOnlyFlag", str16);
                       localHashMap.put("IbyInstrumentType", "CREDITCARD");
                   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreditCardPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                //throw new OAException("Org ID ." + str6 , OAException.INFORMATION);
	 
               }
			   
                           else if(paramOAPageContext.getParameter("RequestCreditCardBtn") != null){//"RequestCreditCardBtn".equals(str1)
                  String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                  String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                  String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                  String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                  String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                  String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                  
                  String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                  String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                  String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                  
                  String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                  String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                  String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                  String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                  
                  String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   String str17 = (String)paramOAPageContext.getTransactionValue("HzPuiSubPartyName");
				 
				  
				   
				   
                  HashMap localHashMap = new HashMap();
                      localHashMap.put("IbyPayerPartyId", str3);
                      localHashMap.put("IbyPaymentFunction", str8);
                      localHashMap.put("IbyCustAccountId", str4);
                      localHashMap.put("IbyCustAccountSiteId", str5);
                      localHashMap.put("IbyOrgId", str6);
                      localHashMap.put("IbyOrgType", str7);
                      localHashMap.put("HzPuiAddressEvent", "CREATE");
                      localHashMap.put("HzPuiAddressLocationId", "");
                      localHashMap.put("IbyReturnLink", str9);
                      localHashMap.put("IbyReturnlink", str9);
                      localHashMap.put("IbyReturnLinkLabel", str10);
                      //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                      localHashMap.put("IbyPayerId", str11);
                      localHashMap.put("IbyPartyName", str13);
                      localHashMap.put("IbyOrgName", str12);
                      localHashMap.put("IbyCustAcctNumber", str14);
                      localHashMap.put("IbyCustAcctSiteName", str15);
                      localHashMap.put("IbyReadOnlyFlag", str16);
                      localHashMap.put("IbyInstrumentType", "CREDITCARD");
                                         localHashMap.put("HzPuiSubPartyName", str17);
				getResp = getMerchantData(paramOAPageContext, paramOAWebBean, str14);
                  String vAchFlag = getResp[0];
                  String vCcFlag = getResp[1];							 
						  if("true".equals(vCcFlag)){ 				 
                //paramOAPageContext.setForwardURL("OA.jsp?page=/oracle/apps/iby/creditcard/setup/webui/CreditCardCreatePG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                 paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/pmr/webui/EbizChargeRequestPayMethodWalletPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
						 }
						 else
						 {
							OASubmitButtonBean RequestCreditCardBtn = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("RequestCreditCardBtn");
						RequestCreditCardBtn.setDisabled(true); 
						 }
              }
			  if ("DeleteBtn".equals(paramOAPageContext.getParameter(OAWebBeanConstants.EVENT_PARAM))) {
		 String lineRefId = (String)paramOAPageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
		 
          OAException descMesg =  new OAException("Confirmation");
          OAException instrMesg = new OAException("Are you sure you want to delete this payment method?");

          OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "",  "");
                       dialogPage.setNoButtonItemName("AchDeleteNoButton");
                       dialogPage.setOkButtonItemName("AchDeleteYesButton");
                       dialogPage.setOkButtonToPost(true);
                       dialogPage.setNoButtonToPost(true);
                       dialogPage.setPostToCallingPage(true);
                       dialogPage.setOkButtonLabel("Yes");
                       dialogPage.setNoButtonLabel("No");

				EbizChRtCustAchVOImpl CcVo = am.getEbizChRtCustAchVO1();

              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
			   String AccountNumber="";
              EbizChRtCustAchVORowImpl CustCcRowVo = null;
              Row rows[] = CcVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;
			  String[] methodID =new String[rowsLength];
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                                  CustCcRowVo = (EbizChRtCustAchVORowImpl) rows[i];
                                  methodID[i] = (String) CustCcRowVo.getAttribute("MethodId");
								  AccountNumber = (String) CustCcRowVo.getAttribute("AchAccount");
							}
			  }
	  
          java.util.Hashtable formParams = new java.util.Hashtable(2);
		  String toCsvValue= toCSV(methodID);
                              formParams.put("lineRefId", toCsvValue);
							  formParams.put("customerID", AccountNumber);
							  
                              dialogPage.setFormParameters(formParams);
          paramOAPageContext.redirectToDialogPage(dialogPage);
                                  
          if (paramOAPageContext.getParameter("AchDeleteYesButton") != null) {
                       lineRefId = paramOAPageContext.getParameter("lineRefId");
                       String str="";
                      Serializable[] parameters = {lineRefId };
                   
                  }
		}
		else  if (paramOAPageContext.getParameter("AchDeleteYesButton") != null)
				{
			 
   		   	   String customerId = paramOAPageContext.getParameter("customerID"); 
			   String lineRefId = paramOAPageContext.getParameter("lineRefId"); 
			   String[] items = lineRefId.split("\\s*,\\s*");
			   int itemLength= items.length;
			 
			  		  
              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
              
              int rowsLength = items.length;
			
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                              
								
                                String methodID =items[i];
                                String AccountNumber = customerId;
                             
                                String[] ccDelCcInfo  = new String[2];
                                ccDelCcInfo =wallet_DelCreditCard(paramOAPageContext, paramOAWebBean, CustomerNo ,methodID);
                                String errorcode = ""; 
                                errorcode = ccDelCcInfo[0];
                               
                                String errormsg = ccDelCcInfo[1];
                                if (errorcode == "S" || errorcode.equals("S") ) {
                                
                                    excCollectAdd = excCollectAdd + " successfull:  "+ AccountNumber+" has been deleted from EBizCharge.";

                                    success_count++;
                                }
                                else {
                                    excCollectAdd = excCollectAdd + " Error: The  "+AccountNumber+" "+" have not been deleted from Ebiz Gateway. Error Code";
                                    error_count++;
                                   
                                }
                             
                            }
                            
                                                if(success_count == 1){
                                                    String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
                                                  //  am.initEbizChRtCustAchVO();
													OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CustomerNo);
														VO.executeQuery();
                                                        throw new OAException("Success: "+success_count +" account(s) has been successfully deleted.", OAException.INFORMATION);
                                                }
                                            
                                                                     
                                                     if(success_count > 1 && error_count < 1){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
														 OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CustomerNo);
														VO.executeQuery();
                                                         //am.initEbizChRtCustAchVO();
                                                             throw new OAException("Success: "+success_count +" account(s) have been successfully deleted.", OAException.INFORMATION);
                                                     }
                                                     
                                                     if(success_count < 1 && error_count > 1){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
                                                         am.initEbizChRtCustAchVO();
                                                             throw new OAException("Error: "+ error_count +" account(s) have not been deleted.", OAException.ERROR);
                                                     }
                                                     
                                                     if(success_count > 1 && error_count > 1){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
                                                       //  am.initEbizChRtCustAchVO();
													   OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CustomerNo);
														VO.executeQuery();
                                                             throw new OAException(success_count +" account(s) have been successfully deleted in EBizCharge but the "+ error_count +" deleted have not been deleted.", OAException.WARNING);
                                                     }     
                            
                            
                            }

          }

    
			 else if (paramOAPageContext.getParameter("AchDeleteNoButton") != null)
                   {
				//throw new OAException("No",OAException.ERROR);   

					}  
					
		 if (paramOAPageContext.getParameter("DelBtn") != null)// { 
			//if ("DelBtn".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
		{
	      String lineRefId = (String)paramOAPageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
		 
          OAException descMesg =  new OAException("Confirmation");
          OAException instrMesg = new OAException("Are you sure you want to delete this payment method(s)?");

          OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "",  "");
                       dialogPage.setNoButtonItemName("DeleteNoButton");
                       dialogPage.setOkButtonItemName("DeleteYesButton");
                       dialogPage.setOkButtonToPost(true);
                       dialogPage.setNoButtonToPost(true);
                       dialogPage.setPostToCallingPage(true);
                       dialogPage.setOkButtonLabel("Yes");
                       dialogPage.setNoButtonLabel("No");
			  
			  
              EbizChRtCustCcVOImpl CcVo = am.getEbizChRtCustCcVO1();
              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
			  String CcCardNumber="";
              EbizChRtCustCcVORowImpl CustCcRowVo = null;
              Row rows[] = CcVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;
			  String[] methodID =new String[rowsLength];
			  
			  if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                                  CustCcRowVo = (EbizChRtCustCcVORowImpl) rows[i];
                                  methodID[i] = (String) CustCcRowVo.getAttribute("MethodId");
								  CcCardNumber = (String) CustCcRowVo.getAttribute("CcCardNumber");
							}
			  }
			  
		  java.util.Hashtable formParams = new java.util.Hashtable(2);
		  String toCsvValue= toCSV(methodID);
                              formParams.put("lineRefId", toCsvValue);
							  formParams.put("customerID", CcCardNumber);
							  
                              dialogPage.setFormParameters(formParams);
          paramOAPageContext.redirectToDialogPage(dialogPage);
                                  
          if (paramOAPageContext.getParameter("DeleteYesButton") != null) {
                       lineRefId = paramOAPageContext.getParameter("lineRefId");
                       String str="";
                      Serializable[] parameters = {lineRefId };
                   
                  }
		}
			  else if(paramOAPageContext.getParameter("DeleteYesButton") != null)
			  {
				  
			   String customerId = paramOAPageContext.getParameter("customerID"); 
			   String lineRefId = paramOAPageContext.getParameter("lineRefId"); 
			   String[] items = lineRefId.split("\\s*,\\s*");
			   int itemLength= items.length;
			   
			   String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
              
              int rowsLength = items.length;
			  
			   
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                               
								
                               
							   
							     String methodID =items[i];
                                String AccountNumber = customerId;
                                
                               
                               
                               String[] ccDelCcInfo =  wallet_DelCreditCard(paramOAPageContext, paramOAWebBean, CustomerNo ,methodID);
                                String errorcode = ccDelCcInfo[0];
                                String errormsg = ccDelCcInfo[1];
                                if (errorcode == "S" || errorcode.equals("S") ) {
                                
                                    excCollectAdd = excCollectAdd + AccountNumber+" card(s) have been successfully deleted from EBizCharge.";
                                    success_count++;
                                }
                                else {
                                    excCollectAdd = excCollectAdd + " Error: The card(s) "+AccountNumber+" "+" have not been deleted from Ebiz Gateway. Error Code";
                                    error_count++;
                                   
                                }
                             
                            }
                            
                                                     
                                                     if(success_count > 0 && error_count < 1){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
														 if(!ccLov[0].equals("S")){
															throw new OAException("CreditCardLov not populated.", OAException.ERROR);    
														 }
														OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
														VO.setWhereClause("customer_no="+CustomerNo);
														VO.executeQuery();
                                                             throw new OAException("Success: "+ success_count +" card(s) have been successfully deleted.", OAException.INFORMATION);
                                                     }
                                                     
                                                     if(success_count < 1 && error_count > 0){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
                                                             
                                                             throw new OAException("Error: "+ error_count +" card(s) have not been deleted.", OAException.ERROR);
                                                     }
                                                     
                                                     if(success_count > 0 && error_count > 0){
                                                         String[] ccLov = creditCardLov(paramOAPageContext, paramOAWebBean, CustomerNo);
														 if(!ccLov[0].equals("S")){
															throw new OAException("CreditCardLov not populated.", OAException.ERROR);    
														 }
														OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
														VO.setWhereClause("customer_no="+CustomerNo);
														VO.executeQuery();
                                                             throw new OAException("Success: "+ success_count +" card(s) have been successfully deleted in EBizCharge but the "+ error_count +" have not been deleted.", OAException.WARNING);
                                                     }     
                            
                            
                            }

          }
			else if (paramOAPageContext.getParameter("DeleteNoButton") != null)
                   {
				  

					} 
      
      	
			
		
		String eventParam = paramOAPageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
		
		if ("DefaultLink".equals(eventParam))
		{
			
			
			//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			String rowReference =  paramOAPageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow currRow = (OARow)am.findRowByRef(rowReference);
			
			String MethodId = (String)currRow.getAttribute("MethodId");//CcCardType
			String CcCardType = (String)currRow.getAttribute("CcCardType");
			String CcCardNumber = (String)currRow.getAttribute("CcCardNumber");
			
			
			String[] defaultCc=defaultCc(paramOAPageContext, paramOAWebBean,CustomerNo,MethodId);
			String errorcode = defaultCc[0];
			String errormsg = defaultCc[1];
			if ("S".equals(errorcode))
			{
					OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
					VO.setWhereClause("customer_no="+CustomerNo);
					VO.executeQuery();
					
					OAViewObject VO1 = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
					VO1.setWhereClause("customer_no="+CustomerNo);
					VO1.executeQuery();
					 
				 throw new OAException("Payment Method ending with "+ CcCardNumber.substring(CcCardNumber.length()-4) + "(" + CcCardType + ") has been defaulted successfully.", OAException.INFORMATION);
			}
			else
			{
				throw new OAException("Payment Method ending with "+ CcCardNumber.substring(CcCardNumber.length()-4) + "(" + CcCardType + ") has not been defaulted successfully.", OAException.ERROR);
				
			}
			
			
		}
		
		if ("DefaultLinkAch".equals(eventParam))
		{
			
			
			//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			String rowReference =  paramOAPageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow currRow = (OARow)am.findRowByRef(rowReference);
			String MethodId = (String)currRow.getAttribute("MethodId");
			String AchAccount = (String)currRow.getAttribute("AchAccount");
			String AchAccountType = (String)currRow.getAttribute("AchAccountType");
		
			
			String[] defaultCc=defaultCc(paramOAPageContext, paramOAWebBean,CustomerNo,MethodId);
			String errorcode = defaultCc[0];
			String errormsg = defaultCc[1];
			if ("S".equals(errorcode))
			{
				OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
				VO.setWhereClause("customer_no="+CustomerNo);
				VO.executeQuery();
				
				OAViewObject VO1 = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
				VO1.setWhereClause("customer_no="+CustomerNo);
				VO1.executeQuery();
				
				//am.initEbizChRtCustCcVO();
				throw new OAException("Payment Method bank account ending with "+ AchAccount.substring(AchAccount.length()-4) + "(" + AchAccountType + ") has been defaulted successfully.", OAException.INFORMATION);
				
			}
			else
			{
				throw new OAException("Payment Method bank account ending with "+ AchAccount.substring(AchAccount.length()-4) + "(" + AchAccountType + ") has been defaulted successfully.", OAException.ERROR);
				
			}
			
			
		}
    super.processFormRequest(paramOAPageContext, paramOAWebBean);
  }
  public String[] getMerchantData(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {
           
       
           String resp[] = new String[3] ;
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_merchant_transaction_data(:1,:2,:3); end;",
                       OADBTransaction.DEFAULT);
                   
                         callableStatement.setString(1,CustomerNo );
                         callableStatement.registerOutParameter(2, Types.VARCHAR);
                         callableStatement.registerOutParameter(3, Types.VARCHAR);
                      
                         callableStatement.execute();
                      
                         String      achFlag = callableStatement.getString(2);
                         String      ccFlag = callableStatement.getString(3);

                               resp[0] = achFlag;
                               resp[1] = ccFlag;
                           
                     

                       callableStatement.close();   
                                      
                  } catch (SQLException e) {
                      throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
                  }
           
           return resp;
      
         }
		 
		  public String[] defaultCc(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo,String methodId)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_CreditCard_pkg.ebizch_default_cc(:1,:2,:3,:4); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
		  callableStatement.setString(2, methodId);
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
          callableStatement.registerOutParameter(4, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(3);    
          resp[1] = callableStatement.getString(4);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("defaultCc: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
public String[] creditCardLov(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
          callableStatement.registerOutParameter(2, Types.VARCHAR);  
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(2);    
          resp[1] = callableStatement.getString(3);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("creditCardLov: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
	  public static String toCSV(String[] array) { 
    String result = ""; 
    if (array.length > 0)
    { 
    StringBuilder sb = new StringBuilder(); 
    for (String s : array) { sb.append(s).append(","); 
    } result = sb.deleteCharAt(sb.length() - 1).toString(); 
    } 
    return result;
    }
	
	  public String[] wallet_DelCreditCard(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean,                                     
                                          String p_cust_no, 
                                          String p_method_id
                                          ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.delete_creditcard(:1,:2, :3, :4); end;", 
                                        OADBTransaction.DEFAULT);
        try {
            
            callableStatement.setString(1, p_cust_no);
            callableStatement.setString(2, p_method_id);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.registerOutParameter(4, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(3);
            resp[1] = callableStatement.getString(4);


            callableStatement.close();

            
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException(errMsg, OAException.INFORMATION);
        }
        return resp;

    } 
	
}
