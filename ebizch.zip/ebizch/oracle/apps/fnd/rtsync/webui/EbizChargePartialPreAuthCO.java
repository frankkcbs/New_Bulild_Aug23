package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EbizChargePartialPreAuthCO extends OAControllerImpl {

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
        String str = paramOAPageContext.getParameter("CUST_NO");
		String str4 = paramOAPageContext.getParameter("OR_NO");
		 String str3 = paramOAPageContext.getParameter("OH_ID");
		
		String str7 = duplicate_partial_preauth(paramOAPageContext, paramOAWebBean, str3);
                if (str7.equals("Y"))
                {		
        String[] arrayOfString = 
            creditCardLov(paramOAPageContext, paramOAWebBean, str);
        if (!arrayOfString[0].equals("S"))
            throw new OAException("CreditCardLov not populated.", (byte)0);
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCustCcVO1");
        oAViewObject.setWhereClause("customer_no=" + str);
        oAViewObject.executeQuery();
				}
            else{
                throw new OAException("Partial Pre-Auth is already done for this SalesOrder : " + 
                                      str4, OAException.INFORMATION);}
				}



    /*     */

    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
        float PartialAmount = 0;

      
	   // String  vPercentageAmount = paramOAPageContext.getParameter("Amount");
	    EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
	        (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
	   
        if (paramOAPageContext.getParameter("preAuthBtn1") != null) {
            String str1 = "";
            String str2 = "";
            String str3 = paramOAPageContext.getParameter("OH_ID");
            String str4 = paramOAPageContext.getParameter("OR_NO");
            String vPercentageAmount = paramOAPageContext.getParameter("Amount");
            String str5 = "";
            Integer OH_ID = Integer.parseInt(str3);
            String[] getSalesOrderAmt = 
                GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
            String vTotAmount = getSalesOrderAmt[0];
            String vTaxAmount = getSalesOrderAmt[1];
            float TotAmount = Float.parseFloat(vTotAmount);
            float vPercentage = Float.parseFloat(vPercentageAmount);
            if (vPercentage > TotAmount) {
                throw new OAException("Amount is greater then or equal to sales order amount.", 
                                      OAException.WARNING);
            }
            else{

            EbizChRtCustCcVOImpl ebizChRtCustCcVOImpl = 
                ebizChRtsyncAMImpl.getEbizChRtCustCcVO1();
            EbizChRtCustCcVORowImpl ebizChRtCustCcVORowImpl = null;
            Row[] arrayOfRow = 
                ebizChRtCustCcVOImpl.getFilteredRows("ViewAttr", "Y");
            int i = arrayOfRow.length;
		
            if (i > 0)
                for (byte b = 0; b < i; b++) {
                    ebizChRtCustCcVORowImpl = 
                            (EbizChRtCustCcVORowImpl)arrayOfRow[b];
                    str1 = (String)ebizChRtCustCcVORowImpl.getAttribute("MethodId");
                    if (ebizChRtCustCcVORowImpl.getAttribute("ViewAttr1") != 
                        null) {
                        str2 = 
                (String)ebizChRtCustCcVORowImpl.getAttribute("ViewAttr1");

                    } else {
                        str2 = "";

                    }

                }
            String str6 = duplicate_partial_preauth(paramOAPageContext, paramOAWebBean, str3);	
                if (str6.equals("Y"))
                {
            str5 = performPreAuth(paramOAPageContext, paramOAWebBean, str3, str1, str2, vPercentageAmount);
            if (str5 != null) {
                if (str5.equals("S"))
                    throw new OAException("Partial Pre-Auth is completed successfully for this SalesOrder : " + 
                                          str4, (byte)2);
                throw new OAException("SalesOrder is not Partial Pre-Authorized for this SalesOrder : " + 
                                      str4 + " preAuthResp:" + str5, OAException.INFORMATION);

            }
            throw new OAException("Partial Pre-Auth is completed successfully for this SalesOrder : " + 
                                  str4, OAException.INFORMATION);

        }
            else{
                throw new OAException("Partial Pre-Auth is already done for this SalesOrder : " + 
                                      str4, OAException.INFORMATION);}
				
                                
                                }
        
        }
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
        
    }

    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }

    public String performPreAuth(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, String paramString1, 
                                 String paramString2, String paramString3, String vPercentageAmount) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKG.CREATE_PARTIAL_PREAUTH(:1,:2,:3,:4,:5); end;", 
                                                        -1);
        try {
            callableStatement.setString(2, paramString1);
            callableStatement.setString(3, paramString2);
            callableStatement.setString(4, paramString3);
			callableStatement.setString(5, vPercentageAmount);
            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String str = callableStatement.getString(1);
            callableStatement.close();
            return str;

        } catch (SQLException sQLException) {
            throw new OAException("performPreAuth: " + 
                                  sQLException.getMessage(), (byte)2);

        }

    }



    public String duplicate_partial_preauth(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, String str3) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKG.duplicate_partial_preauth(:1,:2); end;", 
                                                        -1);
        try {
            callableStatement.setString(1, str3);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.execute();
            String str = callableStatement.getString(2);
            callableStatement.close();
            return str;

        } catch (SQLException sQLException) {
            throw new OAException("duplicate_partial_preauth: " + 
                                  sQLException.getMessage(), (byte)2);

        }

    }

    public String[] creditCardLov(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String paramString) {
        String[] arrayOfString = new String[2];
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;", 
                                                        -1);
        try {
            callableStatement.setString(1, paramString);
            callableStatement.registerOutParameter(2, 12);
            callableStatement.registerOutParameter(3, 12);
            callableStatement.execute();
            arrayOfString[0] = callableStatement.getString(2);
            arrayOfString[1] = callableStatement.getString(3);
            callableStatement.close();
            return arrayOfString;

        } catch (SQLException sQLException) {
            throw new OAException("creditCardLov: " + 
                                  sQLException.getMessage(), (byte)2);

        }

    }

}