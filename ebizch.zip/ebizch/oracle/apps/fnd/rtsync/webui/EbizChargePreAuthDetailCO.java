package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import com.sun.java.util.collections.HashMap;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EbizChargePreAuthDetailCO extends OAControllerImpl {

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
		
        String custNum = paramOAPageContext.getParameter("CUST_NO");
		String str4 = paramOAPageContext.getParameter("OR_NO");
		 String str3 = paramOAPageContext.getParameter("OH_ID");
		
		
        String[] arrayOfString = creditCardLov(paramOAPageContext, paramOAWebBean, custNum);
			
        if (!arrayOfString[0].equals("S"))
		{
			throw new OAException("CreditCardLov not populated.",OAException.ERROR);	
		}
            
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCcInfoVO1");
        oAViewObject.setWhereClause("customer_no=" + custNum);
        oAViewObject.executeQuery();
		
		String checkpay=checkPayment(paramOAPageContext, paramOAWebBean,str4);
		if("Y".equals(checkpay))
		{
			throw new OAException("You are not allowed to do the pre-auth because pre-payment is done against this sales order.",OAException.ERROR);
		}
		
		
		   }
    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {


	    EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
	        (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
	     String custNum = paramOAPageContext.getParameter("CUST_NO");
		 
			HashMap vhashMap = new HashMap(4);
			vhashMap.put("CustomerNumber", custNum);
			vhashMap.put("CUST_NO", paramOAPageContext.getParameter("CUST_NO"));
			vhashMap.put("OR_NO", paramOAPageContext.getParameter("OR_NO"));
			vhashMap.put("OH_ID", paramOAPageContext.getParameter("OH_ID"));
			  

	
	   if (paramOAPageContext.getParameter("goBtn1")!=null)
		{
	   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreditCardPG&retainAM=Y", null, (byte)0, null, vhashMap, true, "Y", (byte)99);  
		
		}
	 
	 String soCount=checkPreauth(paramOAPageContext,paramOAWebBean,paramOAPageContext.getParameter("OR_NO"));
	 
	 if (Integer.parseInt(soCount)>0)
	 {
		 throw new OAException("Pre-Auth is already done for this SalesOrder : " +paramOAPageContext.getParameter("OR_NO"),OAException.ERROR);
	 }
	  
        if (paramOAPageContext.getParameter("preAuthBtn1") != null) {
			
		
			
            String methodId = "";
            String viewAttrval = "";
			String preauthStatus = "";
			
            String headerId = paramOAPageContext.getParameter("OH_ID");
            String orderNum = paramOAPageContext.getParameter("OR_NO");
            String vPercentageAmount = paramOAPageContext.getParameter("Amount");
			Integer OH_ID = Integer.parseInt(headerId);
			
				String checkpay=checkPayment(paramOAPageContext, paramOAWebBean,orderNum);
		if("Y".equals(checkpay))
		{
			throw new OAException("You are not allowed to do the pre-auth because pre-payment is done against this sales order.",OAException.ERROR);
		}
		
            String[] getSalesOrderAmt = GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
            String vTotAmount = getSalesOrderAmt[0];
            String vTaxAmount = getSalesOrderAmt[1];
			
            float TotAmount = Float.parseFloat(vTotAmount);
            float vPercentage = Float.parseFloat(vPercentageAmount);
			
        

            EbizChRtCcInfoVOImpl EbizChRtCcInfoVOImpl =  ebizChRtsyncAMImpl.getEbizChRtCcInfoVO1();
            EbizChRtCcInfoVORowImpl EbizChRtCcInfoVORowImpl = null;
			
            Row[] row =  EbizChRtCcInfoVOImpl.getFilteredRows("ViewAttr", "Y");
            int rowsLength = row.length;
		     
			
            if (rowsLength > 0)
                for (int i = 0; i < rowsLength; i++) {
                    EbizChRtCcInfoVORowImpl =  (EbizChRtCcInfoVORowImpl)row[i];
					
                    methodId = (String)EbizChRtCcInfoVORowImpl.getAttribute("MethodId");
					
                    if (EbizChRtCcInfoVORowImpl.getAttribute("ViewAttr1") != null) 
					{
                        viewAttrval = (String)EbizChRtCcInfoVORowImpl.getAttribute("ViewAttr1");

                    } else {
                        viewAttrval = "";

                    }

                }
          
            preauthStatus = performPreAuth(paramOAPageContext, paramOAWebBean, headerId, methodId, viewAttrval, vPercentageAmount);
            if (preauthStatus != null) {
                if (preauthStatus.equals("S"))
				{
					ccclear( paramOAPageContext, paramOAWebBean);
				 throw new OAException("Pre-Auth is completed successfully for this SalesOrder : " + 
										orderNum, OAException.INFORMATION);	
					
				}
                  else
				  {
					 ccclear( paramOAPageContext, paramOAWebBean); 
					throw new OAException("Pre-Auth is not done for this SalesOrder : " + 
                                      orderNum + " preAuthResp:" + preauthStatus, OAException.INFORMATION);  
					  
				  }
                

            }
			
           
        
      //  }
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
        
								   }}

    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, 
								 Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }

    public String performPreAuth(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, String orderNum, 
                                 String methodId, String cvv, String vPercentageAmount) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.create_preauth_markup(:1,:2,:3,:4,:5); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(2, orderNum);
            callableStatement.setString(3, methodId);
            callableStatement.setString(4, cvv);
			callableStatement.setString(5, vPercentageAmount);
            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String str = callableStatement.getString(1);
            callableStatement.close();
            return str;

        } catch (SQLException sQLException) {
            throw new OAException("Exception in Method named performPreAuth. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }

    }


    public String[] creditCardLov(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String inCustNum)
		 {
        String[] arrayOfString = new String[2];
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, inCustNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();
            arrayOfString[0] = callableStatement.getString(2);
            arrayOfString[1] = callableStatement.getString(3);
            callableStatement.close();
            return arrayOfString;

        } catch (SQLException sQLException) {
            throw new OAException("Exception in Method named creditCardLov. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }

    }
	
	public String checkPreauth(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String soNum)
		 {
        String soCount = "";
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.ebizch_check_preauth(:1,:2); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, soNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.execute();
            soCount = callableStatement.getString(2);
            callableStatement.close();
            

        } catch (SQLException sQLException) {
            throw new OAException("Exception in method named checkPreauth. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }
			return soCount;
    }
	
	public void ccclear(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean)
	{
		 EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
		EbizChRtCcInfoVOImpl EbizChRtCcInfoVOImpl =  ebizChRtsyncAMImpl.getEbizChRtCcInfoVO1();
            EbizChRtCcInfoVORowImpl EbizChRtCcInfoVORowImpl = null;
			
            Row[] row =  EbizChRtCcInfoVOImpl.getFilteredRows("ViewAttr", "Y");
            int rowsLength = row.length;
			
		if (rowsLength > 0)
                for (int i = 0; i < rowsLength; i++) {
                    EbizChRtCcInfoVORowImpl =  (EbizChRtCcInfoVORowImpl)row[i];
					EbizChRtCcInfoVORowImpl.setAttribute("ViewAttr1",null);
                  

                }
		
	}
	
	public String checkPayment(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean,String inSO) {
    String check = "";
	 OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
			CallableStatement cs = 
            oADBTransactionImpl.createCallableStatement("BEGIN :1 := ebizch_wlt_cc_preauth_pkg.check_payment(:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
     try {
        cs.registerOutParameter(1, Types.VARCHAR);
        cs.setString(2, inSO);
		 cs.setString(3, "Pre-Auth");
        cs.execute();
        check = cs.getString(1);
        cs.close();
    } catch (SQLException sQLException) {
       throw new OAException("Exception found in method named checkPayment"+ sQLException.getMessage(),OAException.ERROR);
    }
    return check;
}

}
