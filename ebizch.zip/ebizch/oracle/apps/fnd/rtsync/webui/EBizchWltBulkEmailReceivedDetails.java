package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizchEmailReceivedVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizchEmailReceivedVORowImpl;
import java.math.BigDecimal;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import java.sql.CallableStatement;
import java.sql.SQLException;
import oracle.cabo.style.CSSStyle;
import java.sql.Types;
import oracle.jbo.domain.Number ;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.jbo.Row;


public class EBizchWltBulkEmailReceivedDetails extends OAControllerImpl
{
 
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	
	      EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
			am.initEbizchEmailReceivedVO();  
			 CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                //csNum.setProperty("width", "75px");
                csNum.setProperty("text-align", "right");
              OAMessageTextInputBean omstb1 =
                 (OAMessageTextInputBean)webBean.findChildRecursive("SoAmtTotal");
                omstb1.setInlineStyle(csNum);
				 OAMessageTextInputBean omstb11 =
                 (OAMessageTextInputBean)webBean.findChildRecursive("SoAmt");
				 omstb11.setInlineStyle(csNum);
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    
    super.processFormRequest(pageContext, webBean);
    
  }
}