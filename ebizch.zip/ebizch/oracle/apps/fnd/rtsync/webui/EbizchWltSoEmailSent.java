 package ebizch.oracle.apps.fnd.rtsync.webui;

 import java.math.BigDecimal;

 import java.sql.CallableStatement;
 import java.sql.SQLException;
 import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;


 import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;


 import javax.mail.internet.AddressException;
 import javax.mail.internet.InternetAddress;



 public class EbizchWltSoEmailSent extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
 


   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
         String inInvOrg = pageContext.getParameter("INV_ORG");
         String inCustNum = pageContext.getParameter("CUST_NO");
         String inCustDefaultEmail = getCustEmail (pageContext, webBean,  Integer.parseInt(inInvOrg), inCustNum);
         OAMessageTextInputBean lovBean1 =(OAMessageTextInputBean)webBean.findChildRecursive("EmaiToArrIn");
       lovBean1.setText(pageContext,inCustDefaultEmail);
               
   }


   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       String inFromMail="";
       String inEmailArr="";
       String strEvent= pageContext.getParameter(EVENT_PARAM) ;
       String messageValue="";
       int success_count = 0;
       int error_count = 0;
       
       if (pageContext.getParameter("emailBtn") != null) {
                   
                   if (pageContext.getParameter("EmailFromIn") != null) {
                           inFromMail = pageContext.getParameter("EmailFromIn");
                           checkEmailAddress(inFromMail);
           }
                   else{
                           throw new OAException("Enter the From Email Address.", OAException.ERROR);
                   }

           if (pageContext.getParameter("EmaiToArrIn") != null) {
               inEmailArr = pageContext.getParameter("EmaiToArrIn");
                           checkEmailAddress(inEmailArr);
           }
                   else{
                           throw new OAException("Enter the To Email Address.", OAException.ERROR);
                   }     
                   
           String inInvNum = pageContext.getParameter("INV_NO");
           String inInvOrg = pageContext.getParameter("INV_ORG");
           String inCustNum = pageContext.getParameter("CUST_NO");
           String soNum = pageContext.getParameter("SO_NUM");
           String amt = pageContext.getParameter("soamt");
           String custAccId = pageContext.getParameter("CUST_ACC_ID");
     
           
           String invOrgIdStr = inInvOrg;


           if (pageContext.getParameter("EmailFromIn") != null) {
               inFromMail = pageContext.getParameter("EmailFromIn");
           }

           if (pageContext.getParameter("EmaiToArrIn") != null) {
               inEmailArr = pageContext.getParameter("EmaiToArrIn");
           }

           String[] validationsMessage = isValidate(inCustNum,soNum,invOrgIdStr,inFromMail,inEmailArr,"SalesOrder Payment","WebFormEmail");

                                       if (validationsMessage[0].equals("1")) {
                                         messageValue = messageValue + validationsMessage[1];
                                       }
                                           /*New Code by hamza*/
                                       if (validationsMessage[0].equals("1")){
                                          error_count++;
                                       }
                                       else{
                                            String[] sendinv=sendSalesOrder(pageContext, webBean, inCustNum,soNum,invOrgIdStr,inEmailArr,inFromMail,"SalesOrder Payment","WebFormEmail",amt,custAccId);
                                         if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                                              {
                                                 success_count++;
                                                 throw new OAException("Success: "+ success_count +" request(s) sent successfully.SalesOrder Number :" +soNum, OAException.INFORMATION);
                                                 
                                             }
                                          else{
                                               
                                         error_count++;
                                         throw new OAException("Error: "+ error_count +" request(s) have not been sent successfully.SalesOrder Number :" +soNum, OAException.ERROR);
                                            }
                                       }
          
             
       
       }
     super.processFormRequest(pageContext, webBean);
     
   }

     
     public String[] tokenizerStr(String inEmailArr){
         String  inputString = inEmailArr.replaceAll("\\s+", "");
         String[] arry = inputString.split(",");
         
         return arry;
     }
     
     
     public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo) {
         String[] addDetails = new String[6];
         CallableStatement stmtGetCustAddDetails;
         try {
             OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
             stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetcustsiteadd(:1,:2,:3,:4,:5,:6,:7); end;",
                 OADBTransaction.DEFAULT);

             stmtGetCustAddDetails.registerOutParameter(2, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);

             stmtGetCustAddDetails.setInt(1, siteNo);


             stmtGetCustAddDetails.execute();

             addDetails[0] = stmtGetCustAddDetails.getString(2);
             addDetails[1] = stmtGetCustAddDetails.getString(3);
             addDetails[2] = stmtGetCustAddDetails.getString(4);
             addDetails[3] = stmtGetCustAddDetails.getString(5);
             addDetails[4] = stmtGetCustAddDetails.getString(6);
             addDetails[5] = stmtGetCustAddDetails.getString(7);

             stmtGetCustAddDetails.close();

         } catch (SQLException e) {
             throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
         }

         return addDetails;
     }

    
    public String getCustEmail (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inCustNum){
        String outCustEmail = ""; 
                    CallableStatement stmtGetCustAddDetails;
        try {
              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.get_cust_email(:1,:2,:3); end;",
                                      OADBTransaction.DEFAULT);
                              
                              
                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                            
                              stmtGetCustAddDetails.setInt(1, inOrgId);
                              stmtGetCustAddDetails.setString(2, inCustNum);
                                    
                              stmtGetCustAddDetails.execute();
                              
                              outCustEmail = stmtGetCustAddDetails.getString(3);
                                    
                              stmtGetCustAddDetails.close();   
                              
          } catch (SQLException e) {
              throw new OAException("Exception getting email:" + e.getMessage(), OAException.ERROR);
          }
                      
                      return outCustEmail;
    }

     public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_so_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_so_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                          OADBTransaction.DEFAULT);
                      
                              stmtaddTemplate.setString(1, p_cust_num);
                              stmtaddTemplate.setString(2, p_cust_name);
                              stmtaddTemplate.setString(3, p_so_num);
                              stmtaddTemplate.setString(4, p_inv_org_id);
                              stmtaddTemplate.setString(5, p_email_to);
                              stmtaddTemplate.setString(6, p_out_ebiz_url);
                              stmtaddTemplate.setString(7, p_in_from_mail);
                              stmtaddTemplate.setString(8, p_in_to_mail);
                              stmtaddTemplate.setString(9, p_created_by);
                              
                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }
                                 
              return true;
       }
           
           public void checkEmailAddress(String inEmailArr){
           String[] emailArray = tokenizerStr(inEmailArr);
               
               for(int i = 0; i<emailArray.length; i++) {
                 if(isValidEmailAddress(emailArray[i])){
                     
                 }
                 else{
                     
                     throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                 }
               }
       }
       
       public boolean isValidEmailAddress(String email) {
          boolean result = true;
          try {
             InternetAddress emailAddr = new InternetAddress(email);
             emailAddr.validate();
          } catch (AddressException ex) {
             result = false;
          }
          return result;
       }   
     public String[] isValidate(String CustomerNum,String orgId,String soNumb,String inFromMail,String inEmailArr,String inSubject,String inEmailArrNew) {
           String retMessage = "";
           String retValue = "null";
           String[] output = new String[2];
           output[0] = "0";
           if ("null".equals(String.valueOf(CustomerNum)) || "".equals(String.valueOf(CustomerNum))) {
             retMessage = retMessage + "Customer Id,";
           }

           if ("null".equals(String.valueOf(orgId)) || "".equals(String.valueOf(orgId))) {
             retMessage = retMessage + "Invoice Org Id,";
           }

           if ("null".equals(String.valueOf(soNumb)) || "".equals(String.valueOf(soNumb))) {
             retMessage = retMessage + "SO Number,";
           }

             if ("null".equals(String.valueOf(inFromMail)) || "".equals(String.valueOf(inFromMail)))  {
               retMessage = retMessage + "From Email,";
             }

             if ("null".equals(String.valueOf(inSubject)) || "".equals(String.valueOf(inSubject)))  {
               retMessage = retMessage + "Subject,";
             }
           //inEmailArrNew
            if ("null".equals(String.valueOf(inEmailArrNew)) || "".equals(String.valueOf(inEmailArrNew)))  {
              retMessage = retMessage + "To Email,";
            }
           if (retMessage!="") {
             output[0] = "1";
             retValue = retMessage + "are not found against your selected SalesOrder No" + " : " + soNumb+ " . ";
             output[1] = retValue;
           } else if (retMessage=="") {

             output[0] = "0";
             output[1] = "SalesOrder data is validated.";
           }
           return output;
         }
     public String[] sendSalesOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId, String inEmailArr,String inFromMail,String emSubject,String tempName,String Amount,String custaccid){
                     String[] sendInvDetails = new String[2];
                     CallableStatement sendInvoiceDetails;
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_salesorder(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                   OADBTransaction.DEFAULT);

                                                                                    sendInvoiceDetails.setString(1, custNum);
                                                                                    sendInvoiceDetails.setString(2, inSO);
                                                                                    sendInvoiceDetails.setString(3, orgId);
                                                                                    sendInvoiceDetails.setString(4, inEmailArr);
                                                                                    sendInvoiceDetails.setString(5, inFromMail);
                                                                                    sendInvoiceDetails.setString(6, emSubject);
                                                                                    sendInvoiceDetails.setString(7, tempName);
                                                                                    sendInvoiceDetails.setString(8, Amount);
                                                                                    sendInvoiceDetails.setString(9, custaccid);
                                                                                    sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                    sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                    sendInvoiceDetails.execute();

                                           sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                           sendInvoiceDetails.close();

                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the salesorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }

                                   return sendInvDetails;
         }      
 }
