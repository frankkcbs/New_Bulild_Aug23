package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.GwTemplatesLovVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.PartialRenderingVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import java.text.DecimalFormat;

import java.util.HashMap;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EbizCh_WLT_Email_Pre_Auth_Tbl_CO extends OAControllerImpl {
    String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName="";

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
		        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        ebizChRtsyncAMImpl.invokeMethod("initPartialRenderingVO");
        String inTemplateName="";
        String inSubject="";
        String inEmailNotes="";
        String inCustId="";
        String inFromMail="";
        String inEmailArr="";
        String outWebUrl = " ";
        String inCustName = "";
        String EmailToIn = "";
        String messageValue="";
		String inInvOrg="";
        int error_count = 0;
        int requestSentCount=0;
        String  CUST_NO = paramOAPageContext.getParameter("CUST_NO");
		
        String getCustname[] =new String[1];
        getCustname = getCustName(paramOAPageContext, paramOAWebBean,CUST_NO);
        String Custname = getCustname[0];
		
        String toEmail= getcustEmail(paramOAPageContext, paramOAWebBean,CUST_NO);
    

        Truncate(paramOAPageContext,paramOAWebBean);
        String getEmailTempResp[] =new String[2];
        getEmailTempResp =  createEmailTemplate(paramOAPageContext, paramOAWebBean);

        
        String soAmt=paramOAPageContext.getParameter("SO_AMOUNT");
        String soNum= paramOAPageContext.getParameter("SO_NUM");

        String getResp[] =new String[3];
        getResp =  get_EmailTempbyClassCode(paramOAPageContext,paramOAWebBean);
        
        inEmailTemplate = getResp[0];
        inSubjectText = getResp[1];
        inFromMail = getResp[2];
        inFromName= getResp[3];

        OAMessageLovInputBean lovBean =(OAMessageLovInputBean)paramOAWebBean.findChildRecursive("TemplateLovIn");
        lovBean.setText(paramOAPageContext,inEmailTemplate);
        
        OAMessageTextInputBean textBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("EmailSubjectIn");
        textBean.setText(inSubjectText);
            
        OAMessageTextInputBean textBeanSalesOrderNo = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SalesOrderNo");
        textBeanSalesOrderNo.setText(soNum);
            
        OAMessageTextInputBean textBeanSoAmount = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SoAmount");
        textBeanSoAmount.setText(soAmt);
            
        OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("EmailFromIn");
        EmailFromIntextBean.setText(inFromMail);
        
        OAMessageTextInputBean CustomerNoBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerNo");
        CustomerNoBean.setText(paramOAPageContext,CUST_NO);
        
        OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerName");
        CustomerNameBean.setText(paramOAPageContext,Custname);
        
            OAMessageTextInputBean EmailToInBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("EmailToIn");
        EmailToInBean.setText(paramOAPageContext,toEmail);
        

        String str = paramOAPageContext.getParameter("CUST_NO");
        String OrderNo = paramOAPageContext.getParameter("OR_NO");
       

        OAMessageTextInputBean textBeanSoNumber = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SoNumber");
        OAMessageTextInputBean textBeanCustomerNo = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerNo");
        OAMessageTextInputBean textBeanCustomerName = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerName");

        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCustCcVO1");
        oAViewObject.setWhereClause("customer_no=" + str);
        oAViewObject.executeQuery();

          
	  if (paramOAPageContext.getParameter("INV_ORG") != null) {
         inInvOrg =   paramOAPageContext.getParameter("INV_ORG");
      }
	  
     
        String str3 = paramOAPageContext.getParameter("OH_ID");
        Integer OH_ID = Integer.parseInt(str3);
        String[] getSalesOrderAmt = 
            GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
        String vTotAmount = getSalesOrderAmt[0];
        String vTaxAmount = getSalesOrderAmt[1];
        


        OAViewObject vo = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("PartialRenderingVO1");
        OARow row = (OARow)vo.getCurrentRow();
        Double a = 100.0 ;
        float TotAmount = Float.parseFloat(vTotAmount);
        float Percentage = Float.parseFloat("100.0");
      

        OAViewObject PartialRenderingVO = (OAViewObject)ebizChRtsyncAMImpl.findViewObject("PartialRenderingVO1");

                 if (PartialRenderingVO  != null)
                         {
                         PartialRenderingVO.reset();
                         }
               
                while ( PartialRenderingVO.hasNext())
                {

                PartialRenderingVORowImpl currow = (PartialRenderingVORowImpl)PartialRenderingVO.next();
                Double firstAttr = 100.0;//Double.parseDouble(currow.getAttribute("Percentage").toString());
                        currow.setAttribute("Percentage", firstAttr);
                        Double SecondAttr = Double.parseDouble(vTotAmount);
                       
                        
                       
                }


    }


    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
                                   
			String inTemplateName="";
			String inSubject="";
			String inEmailNotes="";
			String inFromMail="";
			String EmailToIn = "";
            String salesorderNum="";
            String Salesorderamt="";
            String inInvOrg="";
            String custAccId=""; 
            
            
            
			
        int error_count = 0;
            int success_count=0;
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
        
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        String  CUST_NO = paramOAPageContext.getParameter("CUST_NO");
  
            
        if (paramOAPageContext.isLovEvent())
         {
                     String lovInputSourceId = paramOAPageContext.getLovInputSourceId();
                     String lovEvent = paramOAPageContext.getParameter(EVENT_PARAM);
                     
             if("lovUpdate".equals(lovEvent)) { 
             
                     if("TemplateLovIn".equals(lovInputSourceId))
                     {
                           
               OAFormValueBean inSubjectFv = (OAFormValueBean)paramOAWebBean.findIndexedChildRecursive("inSubjectFv");
               
               String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(paramOAPageContext)) ;
                             
               OAFormValueBean fromEmailFv = (OAFormValueBean)paramOAWebBean.findIndexedChildRecursive("fromEmailFv");
           
               String infromEmailFv =  String.valueOf(fromEmailFv.getValue(paramOAPageContext));
                           
               OAMessageTextInputBean textBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("EmailSubjectIn");
               textBean.setText(inSubjectFv1); 
                                            
               OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("EmailFromIn");
               EmailFromIntextBean.setText(infromEmailFv);
                           
                           }
             }
                
        }      
        String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID    from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATETYPEID = 'WebFormEmail' ";
                         try
                         {
                  
                            GwTemplatesLovVOImpl vo1 = (GwTemplatesLovVOImpl)ebizChRtsyncAMImpl.findViewObject("GwTemplatesLovVO1");
                               vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                                vo1.setQuery(query);
                               vo1.executeQuery();
                          }
                          catch (Exception e)
                          {
                              throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                          }     
            

        if (paramOAPageContext.getParameter("Cancel") != null) {
            
        }
        
        if (paramOAPageContext.getParameter("EmailFromIn") != null) {
            inFromMail = paramOAPageContext.getParameter("EmailFromIn");
        }

        if (paramOAPageContext.getParameter("SoAmount") != null) {
            Salesorderamt = paramOAPageContext.getParameter("SoAmount");
        }
            
            if (paramOAPageContext.getParameter("SO_NUM") != null) {
            salesorderNum = paramOAPageContext.getParameter("SO_NUM");
        }
            
        if (paramOAPageContext.getParameter("EmailSubjectIn") != null) {
          inSubject =   paramOAPageContext.getParameter("EmailSubjectIn");
        }
        
        if (paramOAPageContext.getParameter("EmailToIn") != null) {
          EmailToIn =   paramOAPageContext.getParameter("EmailToIn");
        }
        
        if (paramOAPageContext.getParameter("EmailNotesIn") != null) {
          inEmailNotes =   paramOAPageContext.getParameter("EmailNotesIn");
        }
        if (paramOAPageContext.getParameter("CUST_ACC_ID") != null) {
        custAccId =   paramOAPageContext.getParameter("CUST_ACC_ID");
        }
                  
                  
	  if (paramOAPageContext.getParameter("INV_ORG") != null) {
         inInvOrg =   paramOAPageContext.getParameter("INV_ORG");
      }
	  
            
        if (paramOAPageContext.getParameter("Send") != null){
            OAFormValueBean TemplateIdFvInput = (OAFormValueBean)paramOAWebBean.findIndexedChildRecursive("TemplateIdFv");
            inTemplateName = String.valueOf(TemplateIdFvInput.getValue(paramOAPageContext));
                    

           String[] sendinv=sendSalesOrder(paramOAPageContext, paramOAWebBean, CUST_NO,salesorderNum,inInvOrg,EmailToIn,inFromMail,inSubject,inTemplateName,Salesorderamt,custAccId);
             
                     if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                  {
                    success_count++;
					ebizChRtsyncAMImpl.initPreAuthEmailSoSentVO();

                    throw new OAException("Pre-Authorization request has been sent successfully against sales order number " +salesorderNum +".", OAException.INFORMATION);
                                                       
                                                              
                   }
              else{
                                                 
                    error_count++;
					ebizChRtsyncAMImpl.initPreAuthEmailSoSentVO();
                    throw new OAException("Pre-Authorization request has not been sent successfully against sales order number " +salesorderNum +".", OAException.ERROR);
                   }                 
                                  
        }
        

    }
    
    public String getSoCount(OAPageContext pageContext, OAWebBean webBean,String soNum)
              {
          CallableStatement callableStatement;
                       String  email ="";
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.getSaleorderEmailCount(:1,:2); end;",
                      OADBTransaction.DEFAULT);
                  
                        callableStatement.setString(1, soNum);
                        callableStatement.registerOutParameter(2, Types.VARCHAR);
                        
                        callableStatement.execute();
                       
                          email = callableStatement.getString(2);

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getSoCount Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          
          return email;
      }
    public String[] isValidate(String TemplateLovIn,String EmailSubjectIn,String SalesOrderNo,String SoAmount,String EmailFromIn,String CustomerNo,String EmailToIn) {
    String retMessage = "";
    String retValue = "null";
    String[] output = new String[2];
    output[0] = "0";
    if ("null".equals(String.valueOf(TemplateLovIn)) || "".equals(String.valueOf(TemplateLovIn))) {
    retMessage = retMessage + "Template, ";
    }

    if ("null".equals(String.valueOf(EmailSubjectIn)) || "".equals(EmailSubjectIn)) {
    retMessage = retMessage + "Email Subject, ";
    }

    if ("null".equals(String.valueOf(SalesOrderNo)) || "".equals(String.valueOf(SalesOrderNo))) {
    retMessage = retMessage + "SalesOrder Number, ";
    }

    if ("null".equals(String.valueOf(SoAmount)) || "".equals(String.valueOf(SoAmount))) {
    retMessage = retMessage + "SalesOrder Amount, ";
    }
    if ("null".equals(String.valueOf(EmailFromIn)) || "".equals(EmailFromIn)) {
    retMessage = retMessage + "From Email, ";
    }
    if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
    retMessage = retMessage + "Customer Number, ";
    }

    if ("null".equals(String.valueOf(EmailToIn)) || "".equals(String.valueOf(EmailToIn))) {
    retMessage = retMessage + "To Email ";
    }
    if (retMessage!="") {
    output[0] = "1";
    retValue = retMessage + "are not found against your selected Salesorder No" + " : " + SalesOrderNo + " . ";
    output[1] = retValue;
    } else if (retMessage=="") {

    output[0] = "0";
    output[1] = "Salesorder data is validated.";
    }
    return output;
    }
    public void checkEmailAddress(String inEmailArr){
    String[] emailArray = tokenizerStr(inEmailArr);
    
    for(int i = 0; i<emailArray.length; i++) {
    if(isValidEmailAddress(emailArray[i])){
    
    }
    else{
    
    throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
    }
    }
    }
    
    
    public String[] tokenizerStr(String inEmailArr){
    String  inputString = inEmailArr.replaceAll("\\s+", "");
    String[] arry = inputString.split(",");
    
    return arry;
    }
    public boolean isValidEmailAddress(String email) {
    boolean result = true;
    try {
    InternetAddress emailAddr = new InternetAddress(email);
    emailAddr.validate();
    } catch (AddressException ex) {
    result = false;
    }
    return result;
    }

             public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean){


                   String resp[] = new String[6];
                   CallableStatement callableStatement;
                        try {
                               OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                               callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                               OADBTransaction.DEFAULT);

                             callableStatement.registerOutParameter(1, Types.VARCHAR);
                             callableStatement.registerOutParameter(2, Types.VARCHAR);
                             callableStatement.registerOutParameter(3, Types.VARCHAR);
                             callableStatement.registerOutParameter(4, Types.VARCHAR);
                             callableStatement.registerOutParameter(5, Types.VARCHAR);
                              callableStatement.registerOutParameter(6, Types.VARCHAR);
                              callableStatement.execute();
							  
                              String      o_temp = callableStatement.getString(1);
                              String      o_subject = callableStatement.getString(2);
                              String      o_fromemail = callableStatement.getString(3);
                              String      o_fromname = callableStatement.getString(4);
                              String      errorcode = callableStatement.getString(5);
                              String      errormsg = callableStatement.getString(6);

                              resp[0] = o_temp;
                              resp[1] = o_subject;
                              resp[2] = o_fromemail;
                              resp[3] = o_fromname;
                              resp[4] = errorcode;
                              resp[5] = errormsg;



                               callableStatement.close();

                          } catch (SQLException e) {
                              throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                          }

                   return resp;
               }
    
    public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput[] = new String[2];
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;",
                                                         OADBTransaction.DEFAULT);
           try {
             callableStatement.registerOutParameter(1, Types.VARCHAR);
             callableStatement.registerOutParameter(2, Types.VARCHAR);


             callableStatement.execute();

             arrOutput[0] = callableStatement.getString(1);
             arrOutput[1] = callableStatement.getString(2);

             callableStatement.close();                                         
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
           }
        return arrOutput;

    }
    public String[] sendSalesOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId, String inEmailArr,String inFromMail,String emSubject,String tempName,String Amount,String custaccid){
                  String[] sendInvDetails = new String[2];
                  CallableStatement sendInvoiceDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.send_salesorder_Email(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                OADBTransaction.DEFAULT);

                                                                                 sendInvoiceDetails.setString(1, custNum);
                                                                                 sendInvoiceDetails.setString(2, inSO);
                                                                                 sendInvoiceDetails.setString(3, orgId);
                                                                                 sendInvoiceDetails.setString(4, inEmailArr);
                                                                                 sendInvoiceDetails.setString(5, inFromMail);
                                                                                 sendInvoiceDetails.setString(6, emSubject);
                                                                                 sendInvoiceDetails.setString(7, tempName);
                                                                                 sendInvoiceDetails.setString(8, Amount);
                                                                                 sendInvoiceDetails.setString(9, custaccid);
                                                                                 sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                 sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                 sendInvoiceDetails.execute();

                                        sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                        sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                        sendInvoiceDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While Sending the salesorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return sendInvDetails;
      } 
    
    
         public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
                  CallableStatement stmtaddTemplate;
                       try {
                              OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.TRUNCATETABLE; end;",
                              OADBTransaction.DEFAULT);



                              stmtaddTemplate.execute();

                              stmtaddTemplate.close();

                         } catch (SQLException e) {
                             throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                         }


           }
    
    public String getcustEmail(OAPageContext pageContext, OAWebBean webBean,String custNum)
                    {
                CallableStatement callableStatement;
                             String  email ="";
                     try {
                            OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                            callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_cust_email(:1,:2); end;",
                            OADBTransaction.DEFAULT);
                        
                              callableStatement.setString(1, custNum);
                              callableStatement.registerOutParameter(2, Types.VARCHAR);
                              
                              callableStatement.execute();
                             
                                email = callableStatement.getString(2);

                            callableStatement.close();   
                                           
                       } catch (SQLException e) {
                           throw new OAException("Error in calling getcustEmail Exception: " + e.getMessage(), OAException.ERROR);
                       }
                
                
                return email;
            }


         public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){


               String resp[] = new String[6];
               CallableStatement callableStatement;
                    try {
                           OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                           callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                           OADBTransaction.DEFAULT);

                         callableStatement.setString(1, p_cust_num);
                         callableStatement.registerOutParameter(2, Types.VARCHAR);

                          callableStatement.execute();
                          String  p_cust_name = callableStatement.getString(2);
                          resp[0] = p_cust_name;
                          callableStatement.close();

                      } catch (SQLException e) {
                          throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                      }

               return resp;
           }


    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }


}
