package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EmailSoSentVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSoSentVORowImpl;
import java.math.BigDecimal;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import oracle.jbo.domain.Number ;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.jbo.Row;


public class EbizchWltSoEmailSentDetails extends OAControllerImpl
{
 
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	
	      EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
			am.initEmailSoSentVO();  
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    if (pageContext.getParameter("ResendReqBtn") != null) {

              EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
              EmailSoSentVOImpl custVo = am1.getEmailSoSentVO1();
              EmailSoSentVORowImpl EmailSoSentVO = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              int requestSentCount=0;
              String messageValue="";
             int error_count = 0;
			
              if (rowsLength > 0) {
                  for (int i = 0; i < rowsLength; i++) {
                      EmailSoSentVO = (EmailSoSentVORowImpl) rows[i];
                      
                      //inPendingReqId = (String) payMethodPendingVo.getAttribute("Pendingreqid");
                      
                      Number inPendingReqIdNumb = (Number) EmailSoSentVO.getAttribute("InvSentId");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      
                      inCustId = (String) EmailSoSentVO.getAttribute("CustNum");
                      inCustName = (String) EmailSoSentVO.getAttribute("CustName");
                      inUrlId = (String) EmailSoSentVO.getAttribute("OutEbizUrl");
                      inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                      
                      inSentCount = (String) EmailSoSentVO.getAttribute("Sentcount");
                      int inSentCountInt = Integer.parseInt(inSentCount);
                      inSentCountInt = inSentCountInt + 1;
                      String countString=String.valueOf(inSentCountInt) ;
                      
                  
                  
                       String responseResend[] = resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId,inPendingReqIdString,countString);
                       String rurl = responseResend[0];
                       outWebUrl = outWebUrl +  rurl;
                           
                       
                      if(updatePendingReqCount(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                          requestSentCount++;
                      }else{
                          throw new OAException("Update Pending Request not done in Database", OAException.ERROR);
                      }
                      
                  }

      if(requestSentCount>0 && error_count>0){
                    am1.initEmailSoSentVO();
                    throw new OAException(requestSentCount+" request(s) sent successfully. " + error_count + " request(s) not sent successfully " +" Beacuase " +messageValue, OAException.WARNING);          
                }
                else if(requestSentCount>0 && error_count==0)
                {
                    am1.initEmailSoSentVO();
                    throw new OAException(requestSentCount+" request(s) sent successfully." , OAException.INFORMATION);
                }
                else if(requestSentCount<=0 && error_count>0)
                {  
                    am1.initEmailSoSentVO();
                    throw new OAException(error_count + " request(s) not sent successfully " +" Beacuase " +messageValue, OAException.ERROR);
                }
                else{
                  
                    throw new OAException("Error sending request(s), check log.", OAException.ERROR);
                }
                
              }

                    throw new OAException("Please select request to send it again.", OAException.WARNING);
              
          }
      
    super.processFormRequest(pageContext, webBean);
    
  }
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                              callableStatement.setString(2, internalId);
                         callableStatement.setString(3, sentId);
                         callableStatement.setString(4, sentCount);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            callableStatement.registerOutParameter(6, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(5);
                            String  errormsg = callableStatement.getString(6);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
       
     

        public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                 CallableStatement stmtaddTemplate;
              String userId = String.valueOf(paramOAPageContext.getUserId());
                      try {
                             OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count_so(:1,:2,:3); end;",
                             OADBTransaction.DEFAULT);
                         
                                 stmtaddTemplate.setInt(1, pendingreqId);
                                 stmtaddTemplate.setInt(2, count); 
                                 stmtaddTemplate.setString(3, userId); 
                                 
                                 
                                 
                             stmtaddTemplate.execute();

                             stmtaddTemplate.close();   
                                            
                        } catch (SQLException e) {
                            throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                        }
                                    
                 return true;
          }
       
}
