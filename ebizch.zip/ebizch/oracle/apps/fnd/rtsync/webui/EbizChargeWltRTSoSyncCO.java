 package ebizch.oracle.apps.fnd.rtsync.webui;

 import java.sql.CallableStatement;
 import java.sql.SQLException;
 import java.sql.Types;


 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;


 public class EbizChargeWltRTSoSyncCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
      
       String excCollectAdd = "Newly Added: ";
       String excCollectUp = "Updated: ";
       
       String inSoNum = pageContext.getParameter("SO_NUM");
       String inSoOrg = pageContext.getParameter("SO_ORG");
       String inSoCustNum = pageContext.getParameter("SO_CUSTNUM");
       
       Boolean rtSoB = true;
       if (rtSoB)
       {
           /*String[] SODetails = getSODetails (pageContext, webBean, Integer.parseInt(inSoOrg), inSoNum) ;
           String soCustIdStr = SODetails[0];
           String soOrdNumStr = SODetails[4];
           String soPoNum = SODetails[5];
           String soCustomerName = SODetails[1]; 
           String soTaxAmtStr = SODetails[7];
           BigDecimal soTaxAmtBD = new BigDecimal(soTaxAmtStr);
           String soAmtStr = SODetails[8];
           BigDecimal soAmtBD = new BigDecimal(soAmtStr);
           String soAmtDueStr = SODetails[10];
           BigDecimal soAmtDueBD = new BigDecimal(soAmtDueStr);
           String sodateStr = SODetails[11];
           String soShipDateStr = SODetails[11];
           String soShipVia = SODetails[12]; 
           String soCurr = SODetails[9]; 
           String soInvoiceToStr = SODetails[3]; 
           int soInvoiceToInt = Integer.parseInt(soInvoiceToStr); 
           String soShipToStr = SODetails[2]; 
           int soShipToInt = Integer.parseInt(soShipToStr);
            */
			String listerr="";
            String[] solist=getSaleOrder(pageContext, webBean, inSoCustNum,inSoNum);
            String count=solist[0];
           // String err_code=solist[1];
            if(count.equals("0")  )
            { 
               String[] addsolist=addSaleOrder(pageContext, webBean, inSoOrg,inSoNum);
             
               if (addsolist[0]=="S" || addsolist[0].equals("S")) {
                   excCollectAdd = "Success: The order "+inSoNum+" was successfully synced to the EBizCharge Hub.";
               }
               else{
                   excCollectAdd = "Error: The order "+inSoNum+" was not successfully synced to the EBizCharge Hub.";
               }
            }
            else
            {
               
                String[] updsolist=updSaleOrder(pageContext, webBean, inSoOrg,inSoNum);
				listerr=updsolist[0];
                if (updsolist[0]=="S" || updsolist[0].equals("S")) {
                    excCollectAdd = "Success: The order "+inSoNum+" was successfully synced to the EBizCharge Hub.";
                }
                else{
                    excCollectAdd = "Error: The order "+inSoNum+" was not successfully synced to the EBizCharge Hub.";
                }
            }
           throw new OAException(excCollectAdd , OAException.INFORMATION);
           
       }
             else{
                 throw new OAException("You are not allowed to Perform this Operation", OAException.WARNING );
             }
       
   }

   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processFormRequest(pageContext, webBean);
   }

     public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo){
                        String[] addDetails = new String[6]; 
                                    CallableStatement stmtGetCustAddDetails;
                        try {
                              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  EBIZCH_COMMON_PKG.rt_get_cust_site_add(:1,:2,:3,:4,:5,:6,:7); end;",
                                                      OADBTransaction.DEFAULT);
                                              
                                              stmtGetCustAddDetails.registerOutParameter(2, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                                                    
                                              stmtGetCustAddDetails.setInt(1, siteNo);
                                                    
                                              //int inAcctSiteId = Integer.parseInt(outParamValue12);
                                              //stmtGetCustAddDetails.setString(2, addType);
                                                    
                                              stmtGetCustAddDetails.execute();
                                              
                                              addDetails[0] = stmtGetCustAddDetails.getString(2);
                                              addDetails[1] = stmtGetCustAddDetails.getString(3);
                                              addDetails[2] = stmtGetCustAddDetails.getString(4);
                                              addDetails[3] = stmtGetCustAddDetails.getString(5);
                                              addDetails[4] = stmtGetCustAddDetails.getString(6);
                                              addDetails[5] = stmtGetCustAddDetails.getString(7);
                                                    
                                              stmtGetCustAddDetails.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
                          }
                                      
                                      return addDetails;
            }
            
     
     public String[] getSODetails (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inSaleOrder){
         String[] SODetails = new String[14]; 
                     CallableStatement stmtGetCustAddDetails;
         try {
               OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                               stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  EBIZCH_COMMON_PKG.get_rt_so_details(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16); end;",
                                       OADBTransaction.DEFAULT);
                               
                               
                               stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(9, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(10, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(11, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(12, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(13, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(14, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(15, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(16, Types.VARCHAR);
                             
                               stmtGetCustAddDetails.setInt(1, inOrgId);
                               stmtGetCustAddDetails.setString(2, inSaleOrder);      
                               
                                     
                               stmtGetCustAddDetails.execute();
                               
                               SODetails[0] = stmtGetCustAddDetails.getString(3);
                               SODetails[1] = stmtGetCustAddDetails.getString(4);
                               SODetails[2] = stmtGetCustAddDetails.getString(5);
                               SODetails[3] = stmtGetCustAddDetails.getString(6);
                               SODetails[4] = stmtGetCustAddDetails.getString(7);
                               SODetails[5] = stmtGetCustAddDetails.getString(8);
                               SODetails[6] = stmtGetCustAddDetails.getString(9);
                               SODetails[7] = stmtGetCustAddDetails.getString(10);
                               SODetails[8] = stmtGetCustAddDetails.getString(11);
                               SODetails[9] = stmtGetCustAddDetails.getString(12);
                               SODetails[10] = stmtGetCustAddDetails.getString(13);
                               SODetails[11] = stmtGetCustAddDetails.getString(14);
                               SODetails[12] = stmtGetCustAddDetails.getString(15);
                               SODetails[13] = stmtGetCustAddDetails.getString(16);
                                     
                               stmtGetCustAddDetails.close();   
                               
           } catch (SQLException e) {
               throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
           }
                       
                       return SODetails;
     }
     public String[] addSaleOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inOrgId,String soNum){
                        String[] addDetails = new String[2]; 
                                    CallableStatement stmtGetCustAddDetails;
                        try {
                              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.add_saleorder(:1,:2,:3,:4); end;",
                                                      OADBTransaction.DEFAULT);
                                              
                                              
                                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                    
                                              stmtGetCustAddDetails.setString(1, inOrgId);
                                              stmtGetCustAddDetails.setString(2, soNum);     
                                              
                                                    
                                              stmtGetCustAddDetails.execute();
                                              
                                              
                                              addDetails[0] = stmtGetCustAddDetails.getString(3);
                                              addDetails[1] = stmtGetCustAddDetails.getString(4);
                                             
                                                    
                                              stmtGetCustAddDetails.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("Exception in Method addSaleOrder. Message :" + e.getMessage(), OAException.INFORMATION);
                          }
                                      
                                      return addDetails;
            }
            
     public String[] updSaleOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inOrgId,String soNum){
                        String[] addDetails = new String[2]; 
                                    CallableStatement stmtGetCustAddDetails;
                        try {
                              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.upd_saleorder(:1,:2,:3,:4); end;",
                                                      OADBTransaction.DEFAULT);
                                              
                                              
                                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                    
                                              stmtGetCustAddDetails.setString(1, inOrgId);
                                              stmtGetCustAddDetails.setString(2, soNum);     
                                              
                                                    
                                              stmtGetCustAddDetails.execute();
                                              
                                              
                                              addDetails[0] = stmtGetCustAddDetails.getString(3);
                                              addDetails[1] = stmtGetCustAddDetails.getString(4);
                                             
                                                    
                                              stmtGetCustAddDetails.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("Exception in Method updSaleOrder. Message :" + e.getMessage(), OAException.INFORMATION);
                          }
                                      
                                      return addDetails;
            }
     public String[] getSaleOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String soNum){
                        String[] addDetails = new String[3]; 
                                    CallableStatement stmtGetCustAddDetails;
                        try {
                              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.get_saleorder(:1,:2,:3,:4,:5); end;",
                                                      OADBTransaction.DEFAULT);
                                              
                                              
                                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                 stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);      
                                              stmtGetCustAddDetails.setString(1, custNum);
                                              stmtGetCustAddDetails.setString(2, soNum);     
                                              
                                                    
                                              stmtGetCustAddDetails.execute();
                                              
                                              
                                              addDetails[0] = stmtGetCustAddDetails.getString(3);
                                              addDetails[1] = stmtGetCustAddDetails.getString(4);
                                              addDetails[2] = stmtGetCustAddDetails.getString(5);
                                                    
                                              stmtGetCustAddDetails.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("Exception in Method getSaleOrder. Message :" + e.getMessage(), OAException.INFORMATION);
                          }
                                      
                                      return addDetails;
            }
 }
 
 
 
