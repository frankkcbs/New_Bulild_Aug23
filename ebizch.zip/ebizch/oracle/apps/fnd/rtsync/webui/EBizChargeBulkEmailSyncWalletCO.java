package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EBizChBulkEmailHeaderVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSentVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSentVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChEmailHeaderVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChEmailHeaderVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.GwTemplatesLovVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.SalesOrderVOImpl;

import ebizch.oracle.apps.fnd.rtsync.server.SalesOrderVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.SalesOrderVORowImpl;

import oracle.jbo.domain.Number;

import java.sql.CallableStatement;
import java.sql.SQLException;

import java.sql.Types;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
 import oracle.cabo.style.CSSStyle;
 
import oracle.jbo.Row;
import java.lang.Math;

public class EBizChargeBulkEmailSyncWalletCO extends OAControllerImpl
{
  
    String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName=""; 

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      super.processRequest(pageContext, webBean);
      String fromDate="";
	  String toDate="";
	   EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
	 // getclassCode[0];
	 ebizChRtsyncAMImpl.initEBizChBulkEmailHeaderVO();
      Truncate(pageContext,webBean);
     String getEmailTempResp[] =new String[2];
      getEmailTempResp =  createEmailTemplate(pageContext, webBean);
      
      String getResp[] =new String[3];
      getResp = get_EmailTempbyClassCodePreAuth(pageContext,webBean);
      inEmailTemplate = getResp[0];
      inSubjectText = getResp[1];
      inFromMail = getResp[2];
      inFromName= getResp[3];

      OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
      
      OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");      
	  
      OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");

        
		OAViewObject vo = (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EBizChBulkEmailHeaderVO1");
        OARow row = (OARow)vo.getCurrentRow();
		 
       OAViewObject EBizChBulkEmailHeaderVO = (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EBizChBulkEmailHeaderVO1");

                 if (EBizChBulkEmailHeaderVO  != null)
                         {
                         EBizChBulkEmailHeaderVO.reset();
                         }
               
                while ( EBizChBulkEmailHeaderVO.hasNext())
                {

            EBizChBulkEmailHeaderVORowImpl currow = (EBizChBulkEmailHeaderVORowImpl)EBizChBulkEmailHeaderVO.next();
            currow.setAttribute("Emailtype", "PA");
            currow.setAttribute("TemplateLovIn", inEmailTemplate);
            currow.setAttribute("EmailFromIn", inFromMail);
            currow.setAttribute("EmailSubjectIn", inSubjectText);
		
                        
                }
			OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");	
			TemplateIdFvInput.setValue(inEmailTemplate);
		  ebizChRtsyncAMImpl.getSalesOrderVO1().executeQuery();	

				CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                csNum.setProperty("text-align", "right");
                OAMessageStyledTextBean omstb1 =(OAMessageStyledTextBean)webBean.findChildRecursive("Amount");
				OAMessageTextInputBean omstb11 =(OAMessageTextInputBean)webBean.findChildRecursive("ProcessedAmount");
				
                omstb1.setInlineStyle(csNum);
				omstb11.setInlineStyle(csNum);
						  
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    
	   
      String inTemplateName="";
      String inSubject="";
      String inEmailNotes="";
      String inFromMail="";
      String EmailToIn = "";
	  String processedAmt="";
	  String salesorderNum="";
	  String Salesorderamt="";
	  String inInvOrg="";
	  String custAccId="";
      int error_count = 0;
	  int success_count=0;
          String CUST_NO = "";
      SalesOrderVORowImpl SalesOrderVO = null;
  	 EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			
	if ("Emailtype".equals(pageContext.getParameter(EVENT_PARAM))) 
		{
			String  Emailtype =   pageContext.getParameter("Emailtype");
			if ("PA".equals(Emailtype))
				{
					
					inEmailTemplate="";
				    inSubjectText="";
				    inFromMail="";
				    inFromName="";
					
				  String getResp1[] =new String[3];
				  getResp1 =  get_EmailTempbyClassCodePreAuth(pageContext,webBean);
				  inEmailTemplate = getResp1[0];
				  inSubjectText = getResp1[1];
				  inFromMail = getResp1[2];
				  inFromName= getResp1[3];
				  
				  
				  OAViewObject vo1 = (OAViewObject)am.findViewObject("EBizChBulkEmailHeaderVO1");
					OARow row = (OARow)vo1.getCurrentRow();
		
					OAViewObject EBizChBulkEmailHeaderVO = (OAViewObject)am.findViewObject("EBizChBulkEmailHeaderVO1");

                 if (EBizChBulkEmailHeaderVO  != null)
                         {
                         EBizChBulkEmailHeaderVO.reset();
                         }
               
                while ( EBizChBulkEmailHeaderVO.hasNext())
                {

						EBizChBulkEmailHeaderVORowImpl currow = (EBizChBulkEmailHeaderVORowImpl)EBizChBulkEmailHeaderVO.next();
						
                        currow.setAttribute("TemplateLovIn", inEmailTemplate);
						
						currow.setAttribute("EmailFromIn", inFromMail);
						
						
						currow.setAttribute("EmailSubjectIn", inSubjectText);
						
						
                        
                }
				  
			  String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID     from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATENAME = 'Email Pre-Auth for Sales Order'";
                     try
                     {
              
                        GwTemplatesLovVOImpl vo2 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                           vo2.setFullSqlMode(vo2.FULLSQL_MODE_AUGMENTATION);
                            vo2.setQuery(query);
                           vo2.executeQuery();
                      }
                      catch (Exception e)
                      {
                          throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                      }  
   
				}
			else
				{
			 
				String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID     from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATENAME = 'Email Pay for Sales Order'";
                     try
                     {
              
                        GwTemplatesLovVOImpl vo3 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                           vo3.setFullSqlMode(vo3.FULLSQL_MODE_AUGMENTATION);
                            vo3.setQuery(query);
                           vo3.executeQuery();
                      }
                      catch (Exception e)
                      {
                          throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                      } 
					  
				  String getResp[] =new String[3];
				  getResp =  get_EmailTempbyClassCode(pageContext,webBean);
				  inEmailTemplate = getResp[0];
				  inSubjectText = getResp[1];
				  inFromMail = getResp[2];
				  inFromName= getResp[3];
				  
				
				    OAViewObject vo2 = (OAViewObject)am.findViewObject("EBizChBulkEmailHeaderVO1");
					OARow row = (OARow)vo2.getCurrentRow();
		
					OAViewObject EBizChBulkEmailHeaderVO = (OAViewObject)am.findViewObject("EBizChBulkEmailHeaderVO1");

                 if (EBizChBulkEmailHeaderVO  != null)
                         {
                         EBizChBulkEmailHeaderVO.reset();
                         }
               
                while ( EBizChBulkEmailHeaderVO.hasNext())
                {

						EBizChBulkEmailHeaderVORowImpl currow = (EBizChBulkEmailHeaderVORowImpl)EBizChBulkEmailHeaderVO.next();
						
                        currow.setAttribute("TemplateLovIn", inEmailTemplate);
						
						currow.setAttribute("EmailFromIn", inFromMail);
						
						
						currow.setAttribute("EmailSubjectIn", inSubjectText);
						
						
                        
                }
									 
			   
				}
		}
		 if ("ProcessAmount".equals(pageContext.getParameter(EVENT_PARAM))) 
		{
			
			String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow currRow = (OARow)am.findRowByRef(rowReference);
			String attrValue = (String)currRow.getAttribute("ProcessedAmount");
			String attrValue2 = (String)currRow.getAttribute("Amount");
			if (Float.parseFloat(attrValue)>Float.parseFloat(attrValue2))
			{
				throw new OAException("Requested Amount should not be greater than salesorder amount.",OAException.ERROR);
			}
		}
      if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("TemplateLovIn".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
             
             String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("fromEmailFv");
           
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }
      

      if (pageContext.getParameter("Cancel") != null) {
          
      }
    
      
      
      
      if (pageContext.getParameter("EmailFromIn") != null) {
          inFromMail = pageContext.getParameter("EmailFromIn");
		  
      }

	  
      if (pageContext.getParameter("EmailSubjectIn") != null) {
        inSubject =   pageContext.getParameter("EmailSubjectIn");
      }
      	
     
      if (pageContext.getParameter("AccountNumber") != null) {
      CUST_NO =   pageContext.getParameter("AccountNumber");
      }	  
      if (pageContext.getParameter("BillCustAccountId") != null) {
      custAccId =   pageContext.getParameter("BillCustAccountId");
      }   
           
          
      if (pageContext.getParameter("CustomerName") != null) {
       String  CustomerName =   pageContext.getParameter("CustomerName");
       OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
       CustomerNameBean.setText(pageContext,CustomerName); 
     
      }
	  
	  
	

		String  Emailtype =   pageContext.getParameter("Emailtype");

		 if (pageContext.getParameter("Send") != null){
			 
               String inCustId="";
               String inEmailArr="";
               String inCustName = "";
               String SoNumbers="";          
                         

                     SalesOrderVOImpl custVo = am.getSalesOrderVO1();
		             SalesOrderVORowImpl BulkEmailAHeaderVo = null;

		             String excCollectAdd = " ";
		             Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
		             int rowsLength = rows.length;
					
					if (rowsLength > 0) {
                    for (int i = 0; i < rowsLength; i++) {
						SalesOrderVO = (SalesOrderVORowImpl)rows[i];
						String soNum = 
                                (String)SalesOrderVO.getAttribute("OrderNumber");
						String procAmt = 
                                (String)SalesOrderVO.getAttribute("ProcessedAmount");
						String  Soamount = (String)SalesOrderVO.getAttribute("Amount");
						if (Float.parseFloat(procAmt)>Float.parseFloat(Soamount))
							{
							 SoNumbers=soNum + "," +SoNumbers; 	
							}
					}
					}
					
					if (SoNumbers!="")
					{
						String str = SoNumbers.substring(0, SoNumbers.length() -1);
						
						throw new OAException("Requested Amount should not be greater than SalesOrder Amount. Please check against your selected SalesOrder(s) : " +str,OAException.ERROR);
						
					}
				
                if (rowsLength > 0) {
                    for (int i = 0; i < rowsLength; i++) {
						
                        SalesOrderVO = (SalesOrderVORowImpl)rows[i];
                        inCustId = 
                                (String)SalesOrderVO.getAttribute("AccountNumber");
                        inCustName = 
                                (String)SalesOrderVO.getAttribute("CustomerName");
                        EmailToIn = 
                                (String)SalesOrderVO.getAttribute("Email");
						processedAmt = 
                                (String)SalesOrderVO.getAttribute("ProcessedAmount");
						 
						 Number  custAccIdNum = (Number)SalesOrderVO.getAttribute("BillCustAccountId");
                                    custAccId = String.valueOf(custAccIdNum);	

						String  SalesorderamtNum = (String)SalesOrderVO.getAttribute("Amount");
                                    Salesorderamt =SalesorderamtNum;	
									
                        salesorderNum = 
                                (String)SalesOrderVO.getAttribute("OrderNumber");

                        if ("PA".equals(Emailtype))
                 {

                        OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
					    inTemplateName = String.valueOf(TemplateIdFvInput.getValue(pageContext));
              
		    String[] validationsMessage = isValidate(inTemplateName,inSubject,salesorderNum,inFromMail,inCustId,EmailToIn);
		   	String messageValue="";
		   
		   if (validationsMessage[0].equals("1")) {
			        messageValue = messageValue + validationsMessage[1];
			      }
				  
           if (validationsMessage[0].equals("1")){
			       throw new OAException (messageValue,OAException.ERROR);
			      }
			
          //    checkEmailAddress(inFromMail);  
		   //  checkEmailAddress(inEmailArr);

		   
		    String soCount =getSoCountPreauth(pageContext, webBean,salesorderNum);
		   
		   if (Integer.parseInt(soCount)>=1)
		   {
			 throw new OAException ("Email pay request has been already sent one time. Please resend from pending tab.",OAException.ERROR);  
			   
		   }
		   
		   if (Float.parseFloat(Salesorderamt)<=0)
		   {
			  throw new OAException ("Please Check the amount either it is 0 or less than 0.",OAException.ERROR);   
			   
		   }
		   
                                  
			String checkpay=checkPayment(pageContext, webBean,salesorderNum);
				if("Y".equals(checkpay))
				{
					throw new OAException("You are not allowed to do the pre-auth because pre-payment request is already sent against this sales order.",OAException.ERROR);
				}
           
		/*	if (true){
				
			 throw new OAException ("inCustId " +inCustId+  "EmailToIn" +EmailToIn+ "salesorderNum " + salesorderNum + "inFromMail" +inFromMail+
			 "inSubject" +inSubject+ "Salesorderamt" +Salesorderamt+ "custAccId" +custAccId,OAException.ERROR);   	
				
			}*/
		   String[] sendinv=sendSalesOrderPreauth(pageContext, webBean, inCustId,salesorderNum,inInvOrg,EmailToIn,inFromMail,inSubject,inTemplateName,/*Salesorderamt*/processedAmt,custAccId);
             
                     if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                  {
                    success_count++;
				//	am.initEmailSentVO();
					//EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
					//am1.getSalesOrderVO1().executeQuery();
                   // throw new OAException("Pre-Authorization request has been sent successfully against sales order number " +salesorderNum +".", OAException.INFORMATION);
                    // throw new OAException("Email pay request sent successfully for order number(s) " +salesorderNum +".", OAException.INFORMATION);                                  
                                                              
                   }
              else{
                                                 
                    error_count++;
					
			//		am.initEmailSentVO();
                    //throw new OAException("Email pay request has not been sent successfully for order number(s) " +salesorderNum +".", OAException.ERROR);
                   }   
			
		
                                            
                                            }
                                    else
                                       
                                       {
                                    
                                   
                                    
                                    String soCounts =getSoCount(pageContext, webBean,salesorderNum);
                                    
                                    if (Integer.parseInt(soCounts)>=1)
                                    {
                                        throw new OAException ("Email pay request has been already sent one time. Please resend it from pending tab.",OAException.ERROR);  
                                          
                                    }
                                    String checkpay=checkPrePayment(pageContext, webBean,salesorderNum);
										if("Y".equals(checkpay))
										{
											throw new OAException("You are not allowed to do the pre-payment because pre-auth request is already sent against this sales order.",OAException.ERROR);
										}
															/*   if (Float.parseFloat(Salesorderamt)<=0)
                                    {
                                         throw new OAException ("Please Check the amount either it is 0 or less than 0.",OAException.ERROR);   
                                          
                                    }
                                    */
                                   
                                    String[] sendinvs=sendSalesOrder(pageContext, webBean, inCustId,salesorderNum,inInvOrg,EmailToIn,inFromMail,inSubject,inTemplateName,/*Salesorderamt*/processedAmt,custAccId);
                                    
                                    if (sendinvs[0]!="E" || !sendinvs[0].equals("E"))
                                    {
                                    success_count++;
									//EbizChRtsyncAMImpl am2 = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
									// am2.getSalesOrderVO1().executeQuery();
                                                 //   am.initEmailSentVO();  
                                    //throw new OAException("Pre-payment request has been sent successfully against sales order number " +salesorderNum +".", OAException.INFORMATION);
									// throw new OAException("Email pay request sent successfully for order number(s) " +salesorderNum +".", OAException.INFORMATION);
                                                       //EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);                   
                                                                           
                                    }
                                    else{
                                                              
                                    error_count++;
                                    //throw new OAException("Email pay request has not been sent successfully for order number(s) " +salesorderNum +".", OAException.ERROR);
                                    }
                                               
                                    }
									
                                }
                  }	
		     EbizChRtsyncAMImpl am2 = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			if (success_count > 0 && error_count < 1) {
				custVo.clearCache();
				/*  Row rowss[] = custVo.getAllRowsInRange();  
				  for(Row row : rowss){  
					   row.setAttribute("ViewAttr","N");  
				  }*/ 
              
			  am2.getSalesOrderVO1().executeQuery();
              throw new OAException(success_count + " Email pay request(s) sent successfully.", OAException.INFORMATION); 
            } 
            if (success_count < 1 && error_count > 0) {
				custVo.clearCache();
				/*Row rowss[] = custVo.getAllRowsInRange();    
				  for(Row row : rowss){  
					   row.setAttribute("ViewAttr","N");  
				  }*/
              am2.getSalesOrderVO1().executeQuery();
             throw new OAException(error_count +" Email pay request(s) has not been sent successfully.", OAException.ERROR);
            } 
            if (success_count > 0 && error_count > 0) {
				  custVo.clearCache();
				  //Row rowss[] = custVo.getAllRowsInRange();    
				  //for(Row row : rowss){  
				//	   row.setAttribute("ViewAttr","N");  
				 // }
              am2.getSalesOrderVO1().executeQuery();
              throw new OAException(success_count + " Email pay request(s) sent successfully. but " + error_count + " email pay request(s) has not been sent successfully", OAException.WARNING);
            } 
		}
		
			
              
	  
      super.processFormRequest(pageContext, webBean);
  }
  
      public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_so_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_so_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                          OADBTransaction.DEFAULT);
                      
                              stmtaddTemplate.setString(1, p_cust_num);
                              stmtaddTemplate.setString(2, p_cust_name);
                              stmtaddTemplate.setString(3, p_so_num);
                              stmtaddTemplate.setString(4, p_inv_org_id);
                              stmtaddTemplate.setString(5, p_email_to);
                              stmtaddTemplate.setString(6, p_out_ebiz_url);
                              stmtaddTemplate.setString(7, p_in_from_mail);
                              stmtaddTemplate.setString(8, p_in_to_mail);
                              stmtaddTemplate.setString(9, p_created_by);
                              
                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }
                                 
              return true;
       }
	   
       public String[] sendSalesOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId, String inEmailArr,String inFromMail,String emSubject,String tempName,String Amount,String custaccid){
                     String[] sendInvDetails = new String[2];
                     CallableStatement sendInvoiceDetails;
					
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_salesorder(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                   OADBTransaction.DEFAULT);

                                                                                    sendInvoiceDetails.setString(1, custNum);
                                                                                    sendInvoiceDetails.setString(2, inSO);
                                                                                    sendInvoiceDetails.setString(3, orgId);
                                                                                    sendInvoiceDetails.setString(4, inEmailArr);
                                                                                    sendInvoiceDetails.setString(5, inFromMail);
                                                                                    sendInvoiceDetails.setString(6, emSubject);
                                                                                    sendInvoiceDetails.setString(7, tempName);
                                                                                    sendInvoiceDetails.setString(8, Amount);
                                                                                    sendInvoiceDetails.setString(9, custaccid);
                                                                                    sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                    sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                    sendInvoiceDetails.execute();

                                           sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                           sendInvoiceDetails.close();

                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the salesorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }

                                   return sendInvDetails;
         } 


    public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.TRUNCATETABLE; end;",
                         OADBTransaction.DEFAULT);
                     
                           
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
            
      }
      
    public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput[] = new String[2]; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             callableStatement.registerOutParameter(2, Types.VARCHAR);  
            
           
             callableStatement.execute();  
           
             arrOutput[0] = callableStatement.getString(1);  
             arrOutput[1] = callableStatement.getString(2);  
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }


        public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean ){
              
          
              String resp[] = new String[6];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                        					
                        callableStatement.registerOutParameter(1, Types.VARCHAR);
                        callableStatement.registerOutParameter(2, Types.VARCHAR);
                        callableStatement.registerOutParameter(3, Types.VARCHAR);
                        callableStatement.registerOutParameter(4, Types.VARCHAR);
                        callableStatement.registerOutParameter(5, Types.VARCHAR);
                         callableStatement.registerOutParameter(6, Types.VARCHAR); 
                         callableStatement.execute();
                        
						String      o_temp = callableStatement.getString(1);
                        String      o_subject = callableStatement.getString(2);
                        String      o_fromemail = callableStatement.getString(3);
                        String      o_fromname = callableStatement.getString(4);
                        String      errorcode = callableStatement.getString(5);
                        String      errormsg = callableStatement.getString(6);
                         
                         resp[0] = o_temp;
                         resp[1] = o_subject;
                         resp[2] = o_fromemail;
                         resp[3] = o_fromname;
                         resp[4] = errorcode;
                         resp[5] = errormsg;
                              
                         

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              return resp;
          }

    public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){
          
      
          String resp[] = new String[6];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                      OADBTransaction.DEFAULT);
                    callableStatement.setString(1, p_cust_num);
                    callableStatement.registerOutParameter(2, Types.VARCHAR);
                     callableStatement.execute();
                     String  p_cust_name = callableStatement.getString(2);
                     resp[0] = p_cust_name;  
                     callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                              callableStatement.setString(2, internalId);
                         callableStatement.setString(3, sentId);
                         callableStatement.setString(4, sentCount);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            callableStatement.registerOutParameter(6, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(5);
                            String  errormsg = callableStatement.getString(6);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
       
     

        public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                 CallableStatement stmtaddTemplate;
              String userId = String.valueOf(paramOAPageContext.getUserId());
                      try {
                             OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count_so(:1,:2,:3); end;",
                             OADBTransaction.DEFAULT);
                         
                                 stmtaddTemplate.setInt(1, pendingreqId);
                                 stmtaddTemplate.setInt(2, count); 
                                 stmtaddTemplate.setString(3, userId); 
                                 
                                 
                                 
                             stmtaddTemplate.execute();

                             stmtaddTemplate.close();   
                                            
                        } catch (SQLException e) {
                            throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                        }
                                    
                 return true;
          }
		      public String[] getTransactionPaid(OAPageContext pageContext, OAWebBean webBean,String custNum,String fromDate,String toDate){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_transaction_paid(:1,:2,:3,:4,:5); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.setString(2, fromDate);
                            callableStatement.setString(3, toDate);
                            callableStatement.registerOutParameter(4, Types.VARCHAR);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(4);
                            String  errormsg = callableStatement.getString(5);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getTransactionPaid Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
		  
		  
		  public String getcustEmail(OAPageContext pageContext, OAWebBean webBean,String custNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_cust_email(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getcustEmail Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
 public String[] isValidate(String TemplateLovIn,String EmailSubjectIn,String SalesOrderNo,String EmailFromIn,String CustomerNo,String EmailToIn) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(TemplateLovIn)) || "".equals(String.valueOf(TemplateLovIn))) {
        retMessage = retMessage + "Template, ";
      }

      if ("null".equals(String.valueOf(EmailSubjectIn)) || "".equals(EmailSubjectIn)) {
        retMessage = retMessage + "Email Subject, ";
      }

      if ("null".equals(String.valueOf(SalesOrderNo)) || "".equals(String.valueOf(SalesOrderNo))) {
        retMessage = retMessage + "SalesOrder Number, ";
      }

      if ("null".equals(String.valueOf(EmailFromIn)) || "".equals(EmailFromIn)) {
        retMessage = retMessage + "From Email, ";
      }
      if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
        retMessage = retMessage + "Customer Number, ";
      }

      if ("null".equals(String.valueOf(EmailToIn)) || "".equals(String.valueOf(EmailToIn))) {
        retMessage = retMessage + "To Email ";
      }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Salesorder No" + " : " + SalesOrderNo + " . ";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Salesorder data is validated.";
      }
      return output;
    }
		  public void checkEmailAddress(String inEmailArr){
          String[] emailArray = tokenizerStr(inEmailArr);
              
              for(int i = 0; i<emailArray.length; i++) {
                if(isValidEmailAddress(emailArray[i])){
                    
                }
                else{
                    
                    throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                }
              }
      }
      
      public boolean isValidEmailAddress(String email) {
         boolean result = true;
         try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
         } catch (AddressException ex) {
            result = false;
         }
         return result;
      }
	  
	      public String[] tokenizerStr(String inEmailArr){
        String  inputString = inEmailArr.replaceAll("\\s+", "");
        String[] arry = inputString.split(",");
        
        return arry;
    }
	public String getSoCount(OAPageContext pageContext, OAWebBean webBean,String soNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.getSaleorderEmailCount(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, soNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getSoCount Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
		  
	public String[] sendSalesOrderPreauth(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId, String inEmailArr,String inFromMail,String emSubject,String tempName,String Amount,String custaccid){
                  String[] sendInvDetails = new String[2];
                  CallableStatement sendInvoiceDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.send_salesorder_Email(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                OADBTransaction.DEFAULT);

                                                                                 sendInvoiceDetails.setString(1, custNum);
                                                                                 sendInvoiceDetails.setString(2, inSO);
                                                                                 sendInvoiceDetails.setString(3, orgId);
                                                                                 sendInvoiceDetails.setString(4, inEmailArr);
                                                                                 sendInvoiceDetails.setString(5, inFromMail);
                                                                                 sendInvoiceDetails.setString(6, emSubject);
                                                                                 sendInvoiceDetails.setString(7, tempName);
                                                                                 sendInvoiceDetails.setString(8, Amount);
                                                                                 sendInvoiceDetails.setString(9, custaccid);
                                                                                 sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                 sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                 sendInvoiceDetails.execute();

                                        sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                        sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                        sendInvoiceDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While Sending the salesorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return sendInvDetails;
      } 
	  
	   public String getSoCountPreauth(OAPageContext pageContext, OAWebBean webBean,String soNum)
              {
          CallableStatement callableStatement;
                       String  email ="";
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.getSaleorderEmailCount(:1,:2); end;",
                      OADBTransaction.DEFAULT);
                  
                        callableStatement.setString(1, soNum);
                        callableStatement.registerOutParameter(2, Types.VARCHAR);
                        
                        callableStatement.execute();
                       
                          email = callableStatement.getString(2);

                      callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getSoCount Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          
          return email;
      }
	  
	   public String[] get_EmailTempbyClassCodePreAuth(OAPageContext pageContext, OAWebBean webBean){


                   String resp[] = new String[6];
                   CallableStatement callableStatement;
                        try {
                               OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                               callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                               OADBTransaction.DEFAULT);

                             callableStatement.registerOutParameter(1, Types.VARCHAR);
                             callableStatement.registerOutParameter(2, Types.VARCHAR);
                             callableStatement.registerOutParameter(3, Types.VARCHAR);
                             callableStatement.registerOutParameter(4, Types.VARCHAR);
                             callableStatement.registerOutParameter(5, Types.VARCHAR);
                              callableStatement.registerOutParameter(6, Types.VARCHAR);
                              callableStatement.execute();
							  
                              String      o_temp = callableStatement.getString(1);
                              String      o_subject = callableStatement.getString(2);
                              String      o_fromemail = callableStatement.getString(3);
                              String      o_fromname = callableStatement.getString(4);
                              String      errorcode = callableStatement.getString(5);
                              String      errormsg = callableStatement.getString(6);

                              resp[0] = o_temp;
                              resp[1] = o_subject;
                              resp[2] = o_fromemail;
                              resp[3] = o_fromname;
                              resp[4] = errorcode;
                              resp[5] = errormsg;



                               callableStatement.close();

                          } catch (SQLException e) {
                              throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                          }

                   return resp;
               }
		   
    public String checkPrePayment(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean,String inSO) {
    String check = "";
	 OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
			CallableStatement cs = 
            oADBTransactionImpl.createCallableStatement("BEGIN :1 := ebizch_wlt_cc_preauth_pkg.check_payment(:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
     try {
        cs.registerOutParameter(1, Types.VARCHAR);
        cs.setString(2, inSO);
		 cs.setString(3, "Pre-Payment");
        cs.execute();
        check = cs.getString(1);
        cs.close();
    } catch (SQLException sQLException) {
       throw new OAException("Exception found in method named checkPrePayment"+ sQLException.getMessage(),OAException.ERROR);
    }
    return check;
}
public String checkPayment(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean,String inSO) {
    String check = "";
	 OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
			CallableStatement cs = 
            oADBTransactionImpl.createCallableStatement("BEGIN :1 := ebizch_wlt_cc_preauth_pkg.check_payment(:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
     try {
        cs.registerOutParameter(1, Types.VARCHAR);
        cs.setString(2, inSO);
		 cs.setString(3, "Pre-Auth");
        cs.execute();
        check = cs.getString(1);
        cs.close();
    } catch (SQLException sQLException) {
       throw new OAException("Exception found in method named checkPayment"+ sQLException.getMessage(),OAException.ERROR);
    }
    return check;
}

}
