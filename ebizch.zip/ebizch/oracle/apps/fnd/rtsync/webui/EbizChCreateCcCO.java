package ebizch.oracle.apps.fnd.rtsync.webui;


import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChWltCreditCardVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.OARow;
import oracle.jbo.Row;
import java.io.Serializable;
import oracle.apps.fnd.framework.OAViewObject;

public class EbizChCreateCcCO extends OAControllerImpl {
    String CUST_NUM = "";
    public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
        super.processRequest(pageContext, webBean);
        /* if (true)
	 {
		 String url=pageContext.getRequestUrlForRedirect();
		    String url1=         pageContext.getRequestUrl();
           String url2= pageContext.getRequestURI();
           String url3= pageContext.getCurrentUrlForRedirect();
           String url4= pageContext.getCurrentUrl();
		 throw new OAException ("pageContext.getRequestUrlForRedirect() -> " + url +" pageContext.getRequestUrl()-> " + url1
		                        +" pageContext.getRequestURI() -> "+pageContext.getRequestURI() +" pageContext.getCurrentUrlForRedirect() -> "+
								pageContext.getCurrentUrlForRedirect() +"  pageContext.getCurrentUrl()-> " + pageContext.getCurrentUrl(),OAException.ERROR);
		 
	 } */
    }



    public void processFormRequest(OAPageContext pageContext, OAWebBean webBean) {
        //super.processFormRequest(pageContext, webBean);
        // String CUST_NO = pageContext.getParameter("CUST_NO");
        EbizChRtsyncAMImpl am =
            (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);

        String CUST_NO = "";
        if (pageContext.isLovEvent()) {
            String lovInputSourceId = pageContext.getLovInputSourceId();
            if ("CustomerLov".equals(lovInputSourceId)) {
                OAMessageLovInputBean lovff = (OAMessageLovInputBean) webBean.findIndexedChildRecursive("CustomerLov");
                CUST_NO = (String) lovff.getValue(pageContext);
                CUST_NUM = CUST_NO;

                String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                if (!ccLov[0].equals("S")) {
                    throw new OAException("CreditCardLov not populated.", OAException.ERROR);
                }

                OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                VO.setWhereClause("customer_no=" + CUST_NUM);
                VO.executeQuery();

                // am.initEbizChRtCustCcVO();
                am.CreateRecordCreditCardVO();

                String[] getMerchantData = getMerchantData(pageContext, webBean);

                if ("false".equals(getMerchantData[0])) {
                    OASubmitButtonBean sendReqBtn = (OASubmitButtonBean) webBean.findChildRecursive("SendToGW");
                    sendReqBtn.setDisabled(true);
                    throw new OAException("Credit Card transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.", OAException.WARNING);
                }
            }
        }
        // } 
        CUST_NO = CUST_NUM;
        String inCurPartyID = pageContext.getParameter("PagePartyId");
        String inCurPartySiteID = pageContext.getParameter("PagePartySiteId");
        String inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
        String IbyCustAccountId = pageContext.getParameter("IbyCustAccountId");
        String str2 = pageContext.getParameter("IbyCustAccountSiteId");
        String str4 = pageContext.getParameter("IbyOrgId");
        String IbyReturnlink = pageContext.getParameter("IbyReturnlink");
        String Type = pageContext.getParameter("Type");




        if (pageContext.getParameter("SendToGW1") != null) {
            if ("BulkPreAuth".equals(Type)) {
                pageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChBulkPreAuthPG&retainAM=Y",
                    null,
                    OAWebBeanConstants.KEEP_MENU_CONTEXT,
                    null, null, false,
                    OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
                    OAWebBeanConstants.IGNORE_MESSAGES);
            } else {
                pageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/arinv/webui/EbizChargeARInvWoSo&retainAM=Y",
                    null,
                    OAWebBeanConstants.KEEP_MENU_CONTEXT,
                    null, null, false,
                    OAWebBeanConstants.ADD_BREAD_CRUMB_NO,
                    OAWebBeanConstants.IGNORE_MESSAGES);
            }

        }

        if ("CCNumber1".equals(pageContext.getParameter(EVENT_PARAM))) {
            OAViewObject vo =
                (OAViewObject) am.findViewObject("EbizChWltCreditCardVO1");
            OARow row = (OARow) vo.getCurrentRow();
            String CardNumber = String.valueOf(row.getAttribute("ccnumber"));

            String firstchar = CardNumber.substring(0, 1);

            if (firstchar.equals("4")) {
                row.setAttribute("cctype", "V");
            }
            if (firstchar.equals("5")) {
                row.setAttribute("cctype", "M");
            }
            if (firstchar.equals("3")) {
                row.setAttribute("cctype", "JCB");
            }
        }

        if (pageContext.getParameter("DelBtn") != null) // { 
        //if ("DelBtn".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM)))
        {
            String lineRefId = (String) pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);

            OAException descMesg = new OAException("Confirmation");
            OAException instrMesg = new OAException("Are you sure you want to delete this payment method(s)?");

            OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "", "");
            dialogPage.setNoButtonItemName("DeleteNoButton");
            dialogPage.setOkButtonItemName("DeleteYesButton");
            dialogPage.setOkButtonToPost(true);
            dialogPage.setNoButtonToPost(true);
            dialogPage.setPostToCallingPage(true);
            dialogPage.setOkButtonLabel("Yes");
            dialogPage.setNoButtonLabel("No");


            EbizChRtCustCcVOImpl CcVo = am.getEbizChRtCustCcVO1();
            String excCollectAdd = " ";
            int success_count = 0;
            int error_count = 0;
            String CcCardNumber = "";
            EbizChRtCustCcVORowImpl CustCcRowVo = null;
            Row rows[] = CcVo.getFilteredRows("ViewAttr", "Y");
            int rowsLength = rows.length;
            String[] methodID = new String[rowsLength];

            if (rowsLength > 0) {
                for (int i = 0; i < rowsLength; i++) {
                    CustCcRowVo = (EbizChRtCustCcVORowImpl) rows[i];
                    methodID[i] = (String) CustCcRowVo.getAttribute("MethodId");
                    CcCardNumber = (String) CustCcRowVo.getAttribute("CcCardNumber");
                }
            }

            java.util.Hashtable formParams = new java.util.Hashtable(2);
            String toCsvValue = toCSV(methodID);
            formParams.put("lineRefId", toCsvValue);
            formParams.put("customerID", CcCardNumber);

            dialogPage.setFormParameters(formParams);
            pageContext.redirectToDialogPage(dialogPage);

            if (pageContext.getParameter("DeleteYesButton") != null) {
                lineRefId = pageContext.getParameter("lineRefId");
                String str = "";
                Serializable[] parameters = {
                    lineRefId
                };

            }
        } else if (pageContext.getParameter("DeleteYesButton") != null) {

            String customerId = pageContext.getParameter("customerID");
            String lineRefId = pageContext.getParameter("lineRefId");
            String[] items = lineRefId.split("\\s*,\\s*");
            int itemLength = items.length;
            OAMessageLovInputBean lovff = (OAMessageLovInputBean) webBean.findIndexedChildRecursive("CustomerLov");
            CUST_NO = (String) lovff.getValue(pageContext);
            String excCollectAdd = " ";
            int success_count = 0;
            int error_count = 0;

            int rowsLength = items.length;


            if (rowsLength > 0) {
                for (int i = 0; i < rowsLength; i++) {




                    String methodID = items[i];
                    String AccountNumber = customerId;



                    String[] ccDelCcInfo = wallet_DelCreditCard(pageContext, webBean, CUST_NO, methodID);
                    String errorcode = ccDelCcInfo[0];
                    String errormsg = ccDelCcInfo[1];
                    if (errorcode == "S" || errorcode.equals("S")) {

                        excCollectAdd = excCollectAdd + AccountNumber + " card(s) have been successfully deleted.";
                        success_count++;
                    } else {
                        excCollectAdd = excCollectAdd + " Error: The card(s) " + AccountNumber + " " + " have not been successfully deleted.";
                        error_count++;

                    }

                }


                if (success_count > 0 && error_count < 1) {
                    String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                    if (!ccLov[0].equals("S")) {
                        throw new OAException("CreditCardLov not populated.", OAException.ERROR);
                    }
                    OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                    VO.setWhereClause("customer_no=" + CUST_NO);
                    VO.executeQuery();
                    throw new OAException("Success: " + success_count + " card(s) have been successfully deleted.", OAException.INFORMATION);
                }

                if (success_count < 1 && error_count > 0) {
                    String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);

                    throw new OAException("Error: " + error_count + " card(s) have not been successfully deleted.", OAException.ERROR);
                }

                if (success_count > 0 && error_count > 0) {
                    String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                    if (!ccLov[0].equals("S")) {
                        throw new OAException("CreditCardLov not populated.", OAException.ERROR);
                    }
                    OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                    VO.setWhereClause("customer_no=" + CUST_NO);
                    VO.executeQuery();
                    throw new OAException(success_count + " card(s) have been successfully deleted but the " + error_count + " card(s) have not been successfully deleted.", OAException.ERROR);
                }


            }

        } else if (pageContext.getParameter("DeleteNoButton") != null) {


        }


        String p_card_type = "";
        String p_cardcode = "";
        String p_avsStreet = "";
        String p_avsZip = "";
        String v_errorcode_ver = "";
        String v_batchref_ver = "";
        String v_CCResultCode = "";
        String v_AvsResultCode = "";
        String v_AvsResult = "";
        String v_cvvResult = "";
        String v_error_msg = "";
        String chk_ver_done = "0";
        String v_message = "";
        //  if (pageContext.getParameter("SendToGW") != null) { 
        if (pageContext.getParameter("SendToGW") != null) {
            String lineRefId = (String) pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
            EbizChWltCreditCardVORowImpl row = (EbizChWltCreditCardVORowImpl) am.getEbizChWltCreditCardVO1().getCurrentRow();
            row.getname();
            validator(pageContext, webBean, row.getname(), row.getccnumber(), String.valueOf(am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("month")), String.valueOf(am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("year")), row.getZipCode(), row.getBillingAddress(), row.getCity(), row.getState());

            String vexpDate =
                String.valueOf(am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("month") + "-" + am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("year"));

            p_card_type = row.getcctype();
            p_cardcode = row.getssCode();
            p_avsStreet = row.getBillingAddress();
            p_avsZip = row.getZipCode();

            String v_date = ConvertDate(pageContext, webBean, vexpDate);
            String[] merdata = getMerchantData(pageContext, webBean, CUST_NO);
			
            if (merdata[0].equals("true")) {
                String[] ccverInfo = wallet_CheckAVS(pageContext, webBean, row.getccnumber(), v_date, CUST_NO, p_card_type, p_cardcode, p_avsStreet, p_avsZip, row.getname());
                v_errorcode_ver = ccverInfo[0];
                v_batchref_ver = ccverInfo[1];
                v_CCResultCode = ccverInfo[2];
                v_AvsResultCode = ccverInfo[3];
                v_AvsResult = ccverInfo[4];
                v_cvvResult = ccverInfo[5];
                v_error_msg = ccverInfo[6];
            } else {
                v_errorcode_ver = "0";
                v_batchref_ver = null;
            }
            String[] merchantdata = getMerchantData(pageContext, webBean);

            if ("true".equals(merchantdata[1]) || "true".equals(merchantdata[2])) {
                if (!"YYY".equals(v_AvsResultCode) || !"M".equals(v_CCResultCode)) {

                    if (!"YYY".equals(v_AvsResultCode) && !"M".equals(v_CCResultCode)) {
                        v_message = "AVS Result : " + v_AvsResult + " CVV Result : " + v_cvvResult;

                    } else if (!"YYY".equals(v_AvsResultCode) && "M".equals(v_CCResultCode)) {
                        v_message = "AVS Result : " + v_AvsResult;


                    } else if (!"M".equals(v_CCResultCode) && "YYY".equals(v_AvsResultCode)) {
                        v_message = "CVV Result : " + v_cvvResult;


                    }

                    OAException descMesg = new OAException("Confirmation");
                    OAException instrMesg = new OAException(v_message);
                    OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "", "");
                    dialogPage.setNoButtonItemName("AddNoButton");
                    dialogPage.setOkButtonItemName("AddYesButton");
                    dialogPage.setOkButtonToPost(true);
                    dialogPage.setNoButtonToPost(true);
                    dialogPage.setPostToCallingPage(true);
                    dialogPage.setOkButtonLabel("Yes");
                    dialogPage.setNoButtonLabel("No");
                    java.util.Hashtable formParams = new java.util.Hashtable(3);
                    formParams.put("v_batchref_ver", v_batchref_ver);
                    formParams.put("v_errorcode_ver", v_errorcode_ver);
                    formParams.put("CustomerNum", CUST_NO);
                    dialogPage.setFormParameters(formParams);
                    pageContext.redirectToDialogPage(dialogPage);


                } else {
                
                    if (v_errorcode_ver.equals(chk_ver_done)) {


                        processCc(pageContext, webBean, CUST_NO, row.getname(), row.getBillingAddress(), row.getZipCode(), row.getssCode(), v_date, row.getccnumber(),
                            row.getcctype(), v_errorcode_ver, v_batchref_ver);

            } 
				}
			}/*1st Condition End of EnableAVS*/
            else if ("false".equals(merchantdata[1]) || "false".equals(merchantdata[2])) {

                if (v_errorcode_ver.equals(chk_ver_done)) {


                    processCc(pageContext, webBean, CUST_NO, row.getname(), row.getBillingAddress(), row.getZipCode(), row.getssCode(), v_date, row.getccnumber(),
                        row.getcctype(), v_errorcode_ver, v_batchref_ver);
				}
                    else {
                        clearField(pageContext, webBean);

                        throw new OAException(v_error_msg, OAException.ERROR);
                    }


                }
           // } /*2nd Condition End of EnableAVS*/
            else if ("false".equals(merchantdata[1]) || "true".equals(merchantdata[2])) {
                if (!"M".equals(v_CCResultCode)) {
                    setDialouge(pageContext, webBean,v_cvvResult, v_batchref_ver, v_errorcode_ver, CUST_NO);
                   
                } else {
                    if (v_errorcode_ver.equals(chk_ver_done)) {


                        processCc(pageContext, webBean, CUST_NO, row.getname(), row.getBillingAddress(), row.getZipCode(), row.getssCode(), v_date, row.getccnumber(),
                            row.getcctype(), v_errorcode_ver, v_batchref_ver);
					}else {
                            clearField(pageContext, webBean);

                            throw new OAException(v_error_msg, OAException.ERROR);
                        }


                    }
                }

           // }	/*3rd Condition End of EnableAVS*/ 
			else if ("true".equals(merchantdata[1]) || "false".equals(merchantdata[2])) {
                if (!"YYY".equals(v_AvsResultCode)) {

                    setDialouge(pageContext, webBean,v_AvsResult, v_batchref_ver, v_errorcode_ver, CUST_NO);

                } else {
                    if (v_errorcode_ver.equals(chk_ver_done)) {


                        processCc(pageContext, webBean, CUST_NO, row.getname(), row.getBillingAddress(), row.getZipCode(), row.getssCode(), v_date, row.getccnumber(),
                            row.getcctype(), v_errorcode_ver, v_batchref_ver);
					} else {
                            clearField(pageContext, webBean);

                            throw new OAException(v_error_msg, OAException.ERROR);
                        }


                    }
                }/*4th Condition End of EnableAVS*/ 
            }

        if (pageContext.getParameter("AddYesButton") != null) {

            v_errorcode_ver = pageContext.getParameter("v_errorcode_ver");
            v_batchref_ver = pageContext.getParameter("v_batchref_ver");
            CUST_NO = pageContext.getParameter("CustomerNum");
            if (v_errorcode_ver.equals(chk_ver_done)) {



                EbizChWltCreditCardVORowImpl row = (EbizChWltCreditCardVORowImpl) am.getEbizChWltCreditCardVO1().getCurrentRow();
                String vexpDate =
                    String.valueOf(am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("month") + "-" + am.getEbizChWltCreditCardVO1().getCurrentRow().getAttribute("year"));

                String v_date = ConvertDate(pageContext, webBean, vexpDate);

                String[] ccInfo =
                    wallet_add_CreditCard(pageContext, webBean,
                        CUST_NO, row.getname(), row.getBillingAddress(),
                        row.getZipCode(), row.getssCode(), v_date, row.getccnumber(),
                        row.getcctype(), v_errorcode_ver, v_batchref_ver);
                String errorcode = ccInfo[0];
                String errormsg = ccInfo[1];
                if ("E".equals(errorcode)) {
                    throw new OAException("Credit Card is not added. Error Message: " +
                        errormsg, OAException.ERROR);
                } else if ("S".equals(errorcode)) {
                    String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                    if (!ccLov[0].equals("S")) {

                        throw new OAException("CreditCardLov not populated.", OAException.ERROR);
                    }
                    OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                    VO.setWhereClause("customer_no=" + CUST_NO);
                    VO.executeQuery();
                    clearField(pageContext, webBean);
                    throw new OAException("Credit Card Successfully Created ", OAException.INFORMATION);
                } else {
                    clearField(pageContext, webBean);
                    throw new OAException("Error code is null.", OAException.ERROR);
                }

            } else {
                clearField(pageContext, webBean);
                
                throw new OAException(v_error_msg, OAException.ERROR);
            }


        }
        if (pageContext.getParameter("AddNoButton") != null) {
            v_batchref_ver = pageContext.getParameter("v_batchref_ver");
            CUST_NO = pageContext.getParameter("CustomerNum");
            void_transaction(pageContext, webBean, v_batchref_ver, CUST_NO);
        }

        String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
        if ("DefaultLink".equals(eventParam)) {


            String rowReference = pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
            OARow currRow = (OARow) am.findRowByRef(rowReference);

            String MethodId = (String) currRow.getAttribute("MethodId");
            String CcCardType = (String) currRow.getAttribute("CcCardType");
            String CcCardNumber = (String) currRow.getAttribute("CcCardNumber");

            String[] defaultCc = defaultCc(pageContext, webBean, CUST_NO, MethodId);
            String errorcode = defaultCc[0];
            String errormsg = defaultCc[1];
            if ("S".equals(errorcode)) {
                OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                VO.setWhereClause("customer_no=" + CUST_NUM);
                VO.executeQuery();

                throw new OAException("Payment Method ending with " + CcCardNumber.substring(CcCardNumber.length() - 4) + "(" + CcCardType + ") has been defaulted Successfully.", OAException.INFORMATION);
            } else {
                throw new OAException("Payment Method ending with " + CcCardNumber.substring(CcCardNumber.length() - 4) + "(" + CcCardType + ") has not been defaulted Successfully.", OAException.ERROR);

            }


        }
super.processFormRequest(pageContext, webBean);
         }
        

    public String ConvertDate(OAPageContext paramOAPageContext,
        OAWebBean paramOAWebBean, String vdate
    ) {

        String resp, v_conDate;

        try {
            OADBTransactionImpl txn =
                (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
            CallableStatement callableStatement =
                txn.createCallableStatement("begin ebizch_wlt_CreditCard_pkg.xx_convert_date_cc(:1,:2); end;",
                    OADBTransaction.DEFAULT);
            callableStatement.setString(1, vdate);
            callableStatement.registerOutParameter(2, Types.VARCHAR);




            callableStatement.execute();

            v_conDate = callableStatement.getString(2);
            resp = v_conDate;
            callableStatement.close();

            return resp;
        } catch (SQLException e) {
            throw new OAException("Convert Date: " + e.getMessage(), OAException.ERROR);
        }
    }
    public String[] wallet_DelCreditCard(OAPageContext paramOAPageContext,
        OAWebBean paramOAWebBean,
        String p_cust_no,
        String p_method_id
    ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn =
            (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.delete_creditcard(:1,:2, :3, :4); end;",
                OADBTransaction.DEFAULT);
        try {

            callableStatement.setString(1, p_cust_no);
            callableStatement.setString(2, p_method_id);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.registerOutParameter(4, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(3);
            resp[1] = callableStatement.getString(4);


            callableStatement.close();


        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException(errMsg, OAException.INFORMATION);
        }
        return resp;

    }




    public String[] wallet_add_CreditCard(OAPageContext paramOAPageContext,
        OAWebBean paramOAWebBean, String num,
        String p_AccountHolderName,
        String p_AvsStreet, String p_AvsZip,
        String p_CardCode,
        String p_CardExpiration,
        String p_CardNumber,
        String p_CardType,
        String p_Confirm,
        String v_batchref_ver
    ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn =
            (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.create_creditcard(:1,:2, :3, :4,:5,:6,:7,:8,:9,:10,:11,:12,:13); end;",
                OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, num);
            callableStatement.setString(2, p_AccountHolderName);
            callableStatement.setString(3, p_AvsStreet);
            callableStatement.setString(4, p_AvsZip);
            callableStatement.setString(5, p_CardCode);
            callableStatement.setString(6, p_CardExpiration);
            callableStatement.setString(7, p_CardNumber);
            callableStatement.setString(8, p_CardType);
            callableStatement.setString(9, p_Confirm);
            callableStatement.setString(10, v_batchref_ver);
            callableStatement.setString(11, String.valueOf(paramOAPageContext.getOrgId()));


            callableStatement.registerOutParameter(12, Types.VARCHAR);
            callableStatement.registerOutParameter(13, Types.VARCHAR);

            callableStatement.execute();

            resp[0] = callableStatement.getString(12);
            resp[1] = callableStatement.getString(13);

            callableStatement.close();

            return resp;
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException("Credit Card Create: " + errMsg, OAException.ERROR);
        }

    }

    public String[] wallet_CheckAVS(OAPageContext paramOAPageContext,
        OAWebBean paramOAWebBean,
        String p_CardNumber,
        String p_CardExpiration,
        String p_CUST_NO,
        String p_CardType,
        String p_CardCode,
        String p_AvsStreet,
        String p_AvsZip,
        String p_AccountHolderName
    ) {

        String[] resp = new String[7];
        OADBTransactionImpl txn =
            (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.cc_ver_resp_AVS(:1,:2, :3, :4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15); end;",
                OADBTransaction.DEFAULT);
        try {

            // callableStatement.setString(1, p_CUST_NO);
            callableStatement.setString(1, p_CardNumber);
            callableStatement.setString(2, p_CardExpiration);
            callableStatement.setString(3, p_CUST_NO);
            callableStatement.setString(4, p_CardType);
            callableStatement.setString(5, p_CardCode);
            callableStatement.setString(6, p_AvsStreet);
            callableStatement.setString(7, p_AvsZip);
            callableStatement.setString(8, p_AccountHolderName);
            callableStatement.registerOutParameter(9, Types.VARCHAR);
            callableStatement.registerOutParameter(10, Types.VARCHAR);
            callableStatement.registerOutParameter(11, Types.VARCHAR);
            callableStatement.registerOutParameter(12, Types.VARCHAR);
            callableStatement.registerOutParameter(13, Types.VARCHAR);
            callableStatement.registerOutParameter(14, Types.VARCHAR);
            callableStatement.registerOutParameter(15, Types.VARCHAR);
            callableStatement.execute();


            resp[0] = callableStatement.getString(9);
            resp[1] = callableStatement.getString(10);
            resp[2] = callableStatement.getString(11);
            resp[3] = callableStatement.getString(12);
            resp[4] = callableStatement.getString(13);
            resp[5] = callableStatement.getString(14);
            resp[6] = callableStatement.getString(15);

            callableStatement.close();

        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException("AVS Wallet: " + errMsg, OAException.ERROR);
        }
        return resp;

    }
    public String[] creditCardLov(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo) {

        String[] resp = new String[2];

        OADBTransactionImpl txn = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = txn.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;",
            OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, inCustNo);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);


            callableStatement.execute();

            resp[0] = callableStatement.getString(2);
            resp[1] = callableStatement.getString(3);
            callableStatement.close();
            return resp;
        } catch (SQLException e) {

            throw new OAException("creditCardLov: " + e.getMessage(), OAException.INFORMATION);
        }

    }
    public String[] getMerchantData(OAPageContext paramOAPageContext,
        OAWebBean paramOAWebBean,
        String p_cust_no
    ) {

        String[] resp = new String[1];
        OADBTransactionImpl txn =
            (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.get_merchant_transaction_data(:1,:2); end;",
                OADBTransaction.DEFAULT);
        try {

            callableStatement.setString(1, p_cust_no);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(2);


            callableStatement.close();


        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException(errMsg, OAException.INFORMATION);
        }
        return resp;

    }
    public void clearField(OAPageContext pageContext, OAWebBean webBean) {

        OAMessageLovInputBean countryBean = (OAMessageLovInputBean) webBean.findChildRecursive("Country");
        countryBean.setValue(pageContext, null);

        OAMessageTextInputBean accountHoldernameBean = (OAMessageTextInputBean) webBean.findChildRecursive("AccountHoldername");
        accountHoldernameBean.setValue(pageContext, null);

        OAMessageTextInputBean cardNumberBean = (OAMessageTextInputBean) webBean.findChildRecursive("CardNumber");
        cardNumberBean.setValue(pageContext, null);

        OAMessageTextInputBean securityCodeBean = (OAMessageTextInputBean) webBean.findChildRecursive("SecurityCode");
        securityCodeBean.setValue(pageContext, null);

        OAMessageDateFieldBean cardExpirationBean = (OAMessageDateFieldBean) webBean.findChildRecursive("CardExpiration");
        cardExpirationBean.setValue(pageContext, null);

        OAMessageChoiceBean Month = (OAMessageChoiceBean) webBean.findChildRecursive("Month");
        Month.setValue(pageContext, null);

        OAMessageChoiceBean Year = (OAMessageChoiceBean) webBean.findChildRecursive("Year");
        Year.setValue(pageContext, null);

        OAMessageLovInputBean cctype6 = (OAMessageLovInputBean) webBean.findChildRecursive("cctype6");
        cctype6.setValue(pageContext, null);

        OAMessageChoiceBean state = (OAMessageChoiceBean) webBean.findChildRecursive("State");
        state.setValue(pageContext, null);

        OAMessageTextInputBean cardBillingAddressBean = (OAMessageTextInputBean) webBean.findChildRecursive("CardBillingAddress");
        cardBillingAddressBean.setValue(pageContext, null);

        OAMessageTextInputBean cityBean = (OAMessageTextInputBean) webBean.findChildRecursive("city");
        cityBean.setValue(pageContext, null);

        OAMessageTextInputBean zipCodeBean = (OAMessageTextInputBean) webBean.findChildRecursive("ZipCode");
        zipCodeBean.setValue(pageContext, null);

        OAMessageChoiceBean cctype1Bean = (OAMessageChoiceBean) webBean.findChildRecursive("cctype1");
        cctype1Bean.setValue(pageContext, null);

        OAMessageLovInputBean customerBean = (OAMessageLovInputBean) webBean.findChildRecursive("CustomerLov");
        customerBean.setValue(pageContext, null);


    }
    public void validator(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String ccName, String ccNum, String ccmon, String ccYear, String zip, String add, String City, String state) {
        String v_return = "";

        if (ccNum == null || ccNum == "") {
            v_return = "Card Number, ";
        }
        if (ccName == null || ccName == "") {
            v_return = v_return + "Name on Card, ";
        }
        if ("null".equals(ccmon)) //(ccdate==null || ccdate=="")
        {
            v_return = v_return + "Expiration Month, ";
        }

        if ("null".equals(ccYear)) //(ccdate==null || ccdate=="")
        {
            v_return = v_return + "Expiration Year, ";
        }

        if (add == null || add == "") {
            v_return = v_return + "Card Billing Address, ";
        }
        if (City == null || City == "") {
            v_return = v_return + "Card Billing City, ";
        }

        if (state == null || state == "") {
            v_return = v_return + "Card Billing State, ";
        }
        if (zip == null || zip == "") {
            v_return = v_return + "Card Billing Zip Code, ";
        }


        if (v_return == "null" || v_return == "") {} else {
            clearField(paramOAPageContext, paramOAWebBean);
            StringBuffer sb = new StringBuffer(v_return);
            sb.deleteCharAt(sb.length() - 2);
            throw new OAException(sb + " are required field(s). Please fill in all required fields.", OAException.ERROR);


        }

    }
    public String[] defaultCc(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo, String methodId) {

        String[] resp = new String[2];

        OADBTransactionImpl txn = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = txn.createCallableStatement("begin  ebizch_wlt_CreditCard_pkg.ebizch_default_cc(:1,:2,:3,:4); end;",
            OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, inCustNo);
            callableStatement.setString(2, methodId);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.registerOutParameter(4, Types.VARCHAR);


            callableStatement.execute();

            resp[0] = callableStatement.getString(3);
            resp[1] = callableStatement.getString(4);
            callableStatement.close();
            return resp;
        } catch (SQLException e) {

            throw new OAException("defaultCc: " + e.getMessage(), OAException.INFORMATION);
        }

    }
    public static String toCSV(String[] array) {
        String result = "";
        if (array.length > 0) {
            StringBuilder sb = new StringBuilder();
            for (String s: array) {
                sb.append(s).append(",");
            }
            result = sb.deleteCharAt(sb.length() - 1).toString();
        }
        return result;
    }
    public String[] getMerchantData(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
        String errMsg = "";
        String arrOutput = "";
        String[] resp = new String[3];
        OADBTransactionImpl txn = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = txn.createCallableStatement("begin  ebizch_wallet_common_pkg.get_merchant_transaction_cc(:1,:2,:3); end;",
            OADBTransaction.DEFAULT);
        try {
            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(1);
            resp[1] = callableStatement.getString(2);
            resp[2] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            errMsg = e.getMessage();
            throw new OAException("Get getMerchantData Details: " + e.getMessage(), OAException.ERROR);
        }
        return resp;

    }

    public void void_transaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String v_batchref_ver, String custNum) {
        String errMsg = "";
        String arrOutput = "";
        OADBTransactionImpl txn = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = txn.createCallableStatement("begin  ebizch_wlt_creditcard_pkg.void_transaction(:1,:2); end;",
            OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, v_batchref_ver);
            callableStatement.setString(2, custNum);

            callableStatement.execute();


            callableStatement.close();
        } catch (SQLException e) {
            errMsg = e.getMessage();
            throw new OAException("Get void_transaction Details: " + e.getMessage(), OAException.ERROR);
        }


    }
    public void processCc(OAPageContext pageContext, OAWebBean webBean, String custNum, String name, String billingAdd, String zip, String ssCode, String date, String ccNum, String ccType, String errCode, String batchVer) {
        String errMsg="";
            String[] ccInfo = wallet_add_CreditCard(pageContext, webBean, custNum, name, billingAdd, zip, ssCode, date, ccNum,
                ccType, errCode, batchVer);
            String errorcode = ccInfo[0];
            String errormsg = ccInfo[1];
            if ("E".equals(errorcode)) {
                throw new OAException("Credit Card is not added. Error Message: " +
                    errormsg, OAException.ERROR);
            } else if ("S".equals(errorcode)) {
                String[] ccLov = creditCardLov(pageContext, webBean, custNum);
                if (!ccLov[0].equals("S")) {

                    throw new OAException("CreditCardLov not populated.", OAException.ERROR);
                }
                EbizChRtsyncAMImpl am =
                    (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
                OAViewObject VO = (OAViewObject) am.findViewObject("EbizChRtCustCcVO1");
                VO.setWhereClause("customer_no=" + custNum);
                VO.executeQuery();
                clearField(pageContext, webBean);
                throw new OAException("Credit Card Successfully Created ", OAException.INFORMATION);
            } else {
                clearField(pageContext, webBean);
                throw new OAException("Error code is null.", OAException.ERROR);
            }

    }


    public void setDialouge(OAPageContext pageContext, OAWebBean webBean,String v_cvvResult, String v_batchref_ver, String v_errorcode_ver, String CUST_NO) {
        String errMsg="";
        try {
            OAException descMesg = new OAException("Confirmation");
            OAException instrMesg = new OAException(v_cvvResult);
            OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "", "");
            dialogPage.setNoButtonItemName("AddNoButton");
            dialogPage.setOkButtonItemName("AddYesButton");
            dialogPage.setOkButtonToPost(true);
            dialogPage.setNoButtonToPost(true);
            dialogPage.setPostToCallingPage(true);
            dialogPage.setOkButtonLabel("Yes");
            dialogPage.setNoButtonLabel("No");
            java.util.Hashtable formParams = new java.util.Hashtable(3);
            formParams.put("v_batchref_ver", v_batchref_ver);
            formParams.put("v_errorcode_ver", v_errorcode_ver);
            formParams.put("CustomerNum", CUST_NO);
            dialogPage.setFormParameters(formParams);
            pageContext.redirectToDialogPage(dialogPage);

        } catch (Exception e) {
            errMsg = e.getMessage();
            throw new OAException("Get setDialouge Details: " + e.getMessage(), OAException.ERROR);
        }

    }

}