package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EmailSentVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSentVORowImpl;
import java.math.BigDecimal;
import oracle.cabo.style.CSSStyle;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import oracle.jbo.domain.Number ;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.jbo.Row;


public class EBizchWltBulkEmailSentDetails extends OAControllerImpl
{
 
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	
	      EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
			am.initEmailSentVO();  
			  
			 CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                //csNum.setProperty("width", "75px");
                csNum.setProperty("text-align", "right");
              OAMessageTextInputBean omstb1 =
                 (OAMessageTextInputBean)webBean.findChildRecursive("SoAmtTotal");
                omstb1.setInlineStyle(csNum);
				 OAMessageTextInputBean omstb11 =
                 (OAMessageTextInputBean)webBean.findChildRecursive("SoAmt");
				 omstb11.setInlineStyle(csNum);
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    if (pageContext.getParameter("ResendReqBtn") != null) {

              EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
              EmailSentVOImpl custVo = am1.getEmailSentVO1();
              EmailSentVORowImpl EmailSentVO = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
			  String payType="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              int requestSentCount=0;
              String messageValue="";
             int error_count = 0;
			
              if (rowsLength > 0) {
                  for (int i = 0; i < rowsLength; i++) {
                      EmailSentVO = (EmailSentVORowImpl) rows[i];
                      
                      //inPendingReqId = (String) payMethodPendingVo.getAttribute("Pendingreqid");
                      
                      Number inPendingReqIdNumb = (Number) EmailSentVO.getAttribute("InvSentId");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      
                      inCustId = (String) EmailSentVO.getAttribute("CustNum");
                      inCustName = (String) EmailSentVO.getAttribute("CustName");
                      inUrlId = (String) EmailSentVO.getAttribute("OutEbizUrl");
                      inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                      
                      inSentCount = (String) EmailSentVO.getAttribute("Sentcount");
                      int inSentCountInt = Integer.parseInt(inSentCount);
                      inSentCountInt = inSentCountInt + 1;
                      String countString=String.valueOf(inSentCountInt) ;
					  
					  
                      
					  payType = (String) EmailSentVO.getAttribute("payType");
                     
					 if(payType=="Pre-Auth")
					 {
					   String responseResend[] = resendEbizWebFormURLPreAuth(pageContext, webBean, inUrlIdStr,inCustId,inPendingReqIdString,countString);
                       String rurl = responseResend[0];
                       outWebUrl = outWebUrl +  rurl;
                           
                       
                      if(updatePendingReqCountPreAuth(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                          requestSentCount++;
                      }else{
                          throw new OAException("Update Pending Request not done in Database", OAException.ERROR);
                      }
					 }
					 else
					 {
                  
                       String responseResend[] = resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId,inPendingReqIdString,countString);
                       String rurl = responseResend[0];
                       outWebUrl = outWebUrl +  rurl;
                           
                       
                      if(updatePendingReqCount(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                          requestSentCount++;
                      }else{
                          throw new OAException("Update Pending Request not done in Database", OAException.ERROR);
                      }
				  }
                      
                  }

      if(requestSentCount>0 && error_count>0){
                    am1.initEmailSentVO();
                    throw new OAException(requestSentCount+" request(s) sent successfully. " + error_count + " request(s) not sent successfully " +" Beacuase " +messageValue, OAException.WARNING);          
                }
                else if(requestSentCount>0 && error_count==0)
                {
                    am1.initEmailSentVO();
                    throw new OAException(requestSentCount+" request(s) sent successfully." , OAException.INFORMATION);
                }
                else if(requestSentCount<=0 && error_count>0)
                {  
                    am1.initEmailSentVO();
                    throw new OAException(error_count + " request(s) not sent successfully " +" Beacuase " +messageValue, OAException.ERROR);
                }
                else{
                  
                    throw new OAException("Error sending request(s), check log.", OAException.ERROR);
                }
                
              }

                    throw new OAException("Please select request to send it again.", OAException.WARNING);
              
          }
      if (pageContext.getParameter("removeEmailBtn") != null) {

			  EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
              EmailSentVOImpl custVo = am1.getEmailSentVO1();
              EmailSentVORowImpl EmailSentVO = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
			  String payType="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              int requestSentCount=0;
              String messageValue="";
              int error_count = 0;
			  String invNums="";  
		      String SucinvNums="";
			  
			  
          if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  EmailSentVO = (EmailSentVORowImpl) rows[i];
                  
				  
				      Number inPendingReqIdNumb = (Number) EmailSentVO.getAttribute("InvSentId");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      
                      inCustId = (String) EmailSentVO.getAttribute("CustNum");
                      inCustName = (String) EmailSentVO.getAttribute("CustName");
                      inUrlId = (String) EmailSentVO.getAttribute("OutEbizUrl");
                      inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                      
                      inSentCount = (String) EmailSentVO.getAttribute("Sentcount");
                      int inSentCountInt = Integer.parseInt(inSentCount);
                      inSentCountInt = inSentCountInt + 1;
                      String countString=String.valueOf(inSentCountInt) ;
				  
					String SoNum=(String) EmailSentVO.getAttribute("SoNum");
                  
                  String[] validationsMessage = isValidate(SoNum,inSentCountInt ,inPendingReqIdInt);

                   if (validationsMessage[0].equals("1")) {
                     messageValue = messageValue + validationsMessage[1];
                     invNums =validationsMessage[2]+", "+invNums;
			      }
				  else
				   {
					  SucinvNums =validationsMessage[3]+", "+SucinvNums;  
				   }
                       
                   if (validationsMessage[0].equals("1")){
                      error_count++; 
                   }
                   else{
		 
                  String[] deleteEmail=delete_webform_email(pageContext, webBean,inCustId ,inUrlIdStr);
                   
                  if(deleteEmail[0].equals("S")) {
                      requestSentCount++;
                  }else{
					  error_count++;
                     
                  }
                   }
                  
                  
              }
			 messageValue = getDistinctString(pageContext,webBean,messageValue);
             if(requestSentCount>0 && error_count>0){
				 am1.initEmailSentVO();
                
             throw new OAException(requestSentCount+" request(s) deleted successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) +" and " + error_count + " request(s) were not deleted successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2)   , OAException.WARNING);                        
			 }
             else if(requestSentCount>0 && error_count==0)
             {
				  am1.initEmailSentVO();
                 throw new OAException(requestSentCount+" request(s) deleted successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) , OAException.INFORMATION);
             }
             else if(requestSentCount<=0 && error_count>0)
             {
				  am1.initEmailSentVO();
                 throw new OAException(error_count + " request(s) not deleted successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2), OAException.ERROR);
             }
             else{
				  am1.initEmailSentVO();
                 throw new OAException("Error deleting request(s), check log.", OAException.ERROR);
             }
             
          }
	   }
    super.processFormRequest(pageContext, webBean);
    
  }
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.setString(2, internalId);
							callableStatement.setString(3, sentId);
							callableStatement.setString(4, sentCount);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            callableStatement.registerOutParameter(6, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(5);
                            String  errormsg = callableStatement.getString(6);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
       
     

        public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                 CallableStatement stmtaddTemplate;
              String userId = String.valueOf(paramOAPageContext.getUserId());
                      try {
                             OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count_so(:1,:2,:3); end;",
                             OADBTransaction.DEFAULT);
                         
                                 stmtaddTemplate.setInt(1, pendingreqId);
                                 stmtaddTemplate.setInt(2, count); 
                                 stmtaddTemplate.setString(3, userId); 
                                 
                                 
                                 
                             stmtaddTemplate.execute();

                             stmtaddTemplate.close();   
                                            
                        } catch (SQLException e) {
                            throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                        }
                                    
                 return true;
          }
		  
		   public String[] resendEbizWebFormURLPreAuth(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.setString(2, internalId);
							callableStatement.setString(3, sentId);
							callableStatement.setString(4, sentCount);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            callableStatement.registerOutParameter(6, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(5);
                            String  errormsg = callableStatement.getString(6);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
       
     

        public Boolean updatePendingReqCountPreAuth(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                 CallableStatement stmtaddTemplate;
              String userId = String.valueOf(paramOAPageContext.getUserId());
                      try {
                             OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.update_request_count_so(:1,:2,:3); end;",
                             OADBTransaction.DEFAULT);
                         
                                 stmtaddTemplate.setInt(1, pendingreqId);
                                 stmtaddTemplate.setInt(2, count); 
                                 stmtaddTemplate.setString(3, userId); 
                                 
                                 
                                 
                             stmtaddTemplate.execute();

                             stmtaddTemplate.close();   
                                            
                        } catch (SQLException e) {
                            throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                        }
                                    
                 return true;
          }
       
   public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   }    
       public String[] delete_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String CustNumVal ,String pay_int_id ){
             CallableStatement stmtaddTemplate;
			    String[] addDetails = new String[2]; 
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_email_preauth_pkg.delete_webform_email(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, CustNumVal);
                             stmtaddTemplate.setString(2, pay_int_id);
                             stmtaddTemplate.registerOutParameter(3, Types.VARCHAR);
                             stmtaddTemplate.registerOutParameter(4, Types.VARCHAR);
                             
                             
                         stmtaddTemplate.execute();
                           addDetails[0] = stmtaddTemplate.getString(3);
                           addDetails[1] = stmtaddTemplate.getString(4);
                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return addDetails;
      }	
	  
	  public String[] isValidate(String invnum,int inSentCount  , int inPendingReqIdNumb) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
      if ("".equals(String.valueOf(inSentCount))) {
        retMessage = retMessage + "Sent Count,";
      }
   
      if ("".equals(String.valueOf(inPendingReqIdNumb)) || String.valueOf(inPendingReqIdNumb) == null) {
        retMessage = retMessage + "Pending Req Id,";
      }

      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invnum;
        output[1] = retValue;
		output[2] = invnum;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Data is validated.";
		output[3] = invnum;
      }
      return output;
    }
}
