package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSoSentVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmailSoSentVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.GwTemplatesLovVOImpl;
import oracle.jbo.domain.Number;

import java.sql.CallableStatement;
import java.sql.SQLException;

import java.sql.Types;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;


public class EbizChargeSoSyncWalletCO extends OAControllerImpl
{
  
    String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName=""; 

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      super.processRequest(pageContext, webBean);
      String fromDate="";
	  String toDate="";
	  
      String  CUST_NO = pageContext.getParameter("CUST_NO");
      String getCustname[] =new String[1];
      getCustname = getCustName(pageContext, webBean,CUST_NO);
      String Custname = getCustname[0];
      
      Truncate(pageContext,webBean);
      String getEmailTempResp[] =new String[2];
      getEmailTempResp =  createEmailTemplate(pageContext, webBean);
      
      String getResp[] =new String[3];
      getResp =  get_EmailTempbyClassCode(pageContext,webBean);
      inEmailTemplate = getResp[0];
      inSubjectText = getResp[1];
      inFromMail = getResp[2];
      inFromName= getResp[3];
      
	  String toEmail= getcustEmail(pageContext, webBean,CUST_NO);
	  
	  String soAmt=pageContext.getParameter("SO_AMOUNT");
	  String soNum= pageContext.getParameter("SO_NUM");
	  
	  String[] updateflag=getTransactionPaid(pageContext,webBean,CUST_NO,fromDate, toDate);
	  
      OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
      lovBean.setText(pageContext,inEmailTemplate);
      
      OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
      textBean.setText(inSubjectText);
	  
      OAMessageTextInputBean textBeanSalesOrderNo = (OAMessageTextInputBean)webBean.findChildRecursive("SalesOrderNo");
      textBeanSalesOrderNo.setText(soNum);
	  
      OAMessageTextInputBean textBeanSoAmount = (OAMessageTextInputBean)webBean.findChildRecursive("SoAmount");
      textBeanSoAmount.setText(soAmt);
	  
      OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
      EmailFromIntextBean.setText(inFromMail);
      
      OAMessageTextInputBean CustomerNoBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerNo");
      CustomerNoBean.setText(pageContext,CUST_NO);
      
      OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
      CustomerNameBean.setText(pageContext,Custname);
     
	  OAMessageTextInputBean EmailToInBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
      EmailToInBean.setText(pageContext,toEmail);
	  
	 OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
     TemplateIdFvInput.setValue(inEmailTemplate);
                        
      OAFormValueBean inSubjectFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
     inSubjectFvInput.setValue(inSubjectText);

	OAFormValueBean fromEmailFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("fromEmailFv");
     fromEmailFvInput.setValue(inFromMail);	 
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    
	   
      String inTemplateName="";
      String inSubject="";
      String inEmailNotes="";
      String inFromMail="";
      String EmailToIn = "";
	  String salesorderNum="";
	  String Salesorderamt="";
	  String inInvOrg="";
	  String custAccId="";
      int error_count = 0;
	  int success_count=0;
      String  CUST_NO = pageContext.getParameter("CUST_NO");
     
	 EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			
	  
      if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("TemplateLovIn".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
             //String inSubjectFv1 = inSubjectFv.getValue(pageContext).toString();
             String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("fromEmailFv");
             //String infromEmailFv = fromEmailFv.getValue(pageContext).toString(); 
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }
      
    String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID     from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATETYPEID = 'SalesOrderWebFormEmail'";
                     try
                     {
              
                        GwTemplatesLovVOImpl vo1 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                           vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                            vo1.setQuery(query);
                           vo1.executeQuery();
                      }
                      catch (Exception e)
                      {
                          throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                      }  
      
      if (pageContext.getParameter("Cancel") != null) {
          
      }
      
      if (pageContext.getParameter("EmailFromIn") != null) {
          inFromMail = pageContext.getParameter("EmailFromIn");
      }

      if (pageContext.getParameter("SoAmount") != null) {
          Salesorderamt = pageContext.getParameter("SoAmount");
      }
	  
	  if (pageContext.getParameter("SO_NUM") != null) {
          salesorderNum = pageContext.getParameter("SO_NUM");
      }
	  
      if (pageContext.getParameter("EmailSubjectIn") != null) {
        inSubject =   pageContext.getParameter("EmailSubjectIn");
      }
      
      if (pageContext.getParameter("EmailToIn") != null) {
        EmailToIn =   pageContext.getParameter("EmailToIn");
      }
      
      if (pageContext.getParameter("EmailNotesIn") != null) {
        inEmailNotes =   pageContext.getParameter("EmailNotesIn");
      }
     
	  if (pageContext.getParameter("INV_ORG") != null) {
         inInvOrg =   pageContext.getParameter("INV_ORG");
      }
	  
	   
	   if (pageContext.getParameter("CUST_ACC_ID") != null) {
         custAccId =   pageContext.getParameter("CUST_ACC_ID");
      }
	  
      if (pageContext.getParameter("CustomerName") != null) {
       String  CustomerName =   pageContext.getParameter("CustomerName");
       OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
       CustomerNameBean.setText(pageContext,CustomerName); 
     
      }

     // OASubmitButtonBean  Send =  (OASubmitButtonBean)webBean.findChildRecursive("Send");
      if (pageContext.getParameter("Send") != null){
          OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
          inTemplateName = String.valueOf(TemplateIdFvInput.getValue(pageContext));
		  
		   String[] validationsMessage = isValidate(inTemplateName,inSubject,salesorderNum,Salesorderamt,inFromMail,CUST_NO,EmailToIn);
		   	String messageValue="";
		   
		   if (validationsMessage[0].equals("1")) {
			        messageValue = messageValue + validationsMessage[1];
			      }
				  
           if (validationsMessage[0].equals("1")){
			       throw new OAException (messageValue,OAException.ERROR);
			      }
				
			 checkEmailAddress(inFromMail);  
		     checkEmailAddress(EmailToIn);
			 
 		  if (Float.parseFloat(Salesorderamt)>Float.parseFloat(pageContext.getParameter("SO_AMOUNT")))
		   {
			   throw new OAException ("Requested Amount should not be greater than SalesOrder Amount. Please Check!",OAException.ERROR);
               			   
		   }
		   
		   String soCount =getSoCount(pageContext, webBean,salesorderNum);
		   
		   if (Integer.parseInt(soCount)>=1)
		   {
			 throw new OAException ("Pre-payment request has been already sent one time. Please resend it below.",OAException.ERROR);  
			   
		   }
		   
		   if (Float.parseFloat(Salesorderamt)<=0)
		   {
			  throw new OAException ("Please Check the amount either it is 0 or less than 0.",OAException.ERROR);   
			   
		   }
		   
         String[] sendinv=sendSalesOrder(pageContext, webBean, CUST_NO,salesorderNum,inInvOrg,EmailToIn,inFromMail,inSubject,inTemplateName,Salesorderamt,custAccId);
           
		   if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                {
                  success_count++;
				     am.initEmailSoSentVO();  
                  throw new OAException("Pre-payment request has been sent successfully against sales order number " +salesorderNum +".", OAException.INFORMATION);
					//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);                   
				                            
                 }
            else{
                                               
                  error_count++;
                  throw new OAException("Pre-payment request has not been sent successfully against sales order number " +salesorderNum +".", OAException.ERROR);
                 }		   
         			
      }
      
   
      super.processFormRequest(pageContext, webBean);
  }
  
      public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_so_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_so_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                          OADBTransaction.DEFAULT);
                      
                              stmtaddTemplate.setString(1, p_cust_num);
                              stmtaddTemplate.setString(2, p_cust_name);
                              stmtaddTemplate.setString(3, p_so_num);
                              stmtaddTemplate.setString(4, p_inv_org_id);
                              stmtaddTemplate.setString(5, p_email_to);
                              stmtaddTemplate.setString(6, p_out_ebiz_url);
                              stmtaddTemplate.setString(7, p_in_from_mail);
                              stmtaddTemplate.setString(8, p_in_to_mail);
                              stmtaddTemplate.setString(9, p_created_by);
                              
                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }
                                 
              return true;
       }
	   
       public String[] sendSalesOrder(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId, String inEmailArr,String inFromMail,String emSubject,String tempName,String Amount,String custaccid){
                     String[] sendInvDetails = new String[2];
                     CallableStatement sendInvoiceDetails;
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_salesorder(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                   OADBTransaction.DEFAULT);

                                                                                    sendInvoiceDetails.setString(1, custNum);
                                                                                    sendInvoiceDetails.setString(2, inSO);
                                                                                    sendInvoiceDetails.setString(3, orgId);
                                                                                    sendInvoiceDetails.setString(4, inEmailArr);
                                                                                    sendInvoiceDetails.setString(5, inFromMail);
                                                                                    sendInvoiceDetails.setString(6, emSubject);
                                                                                    sendInvoiceDetails.setString(7, tempName);
                                                                                    sendInvoiceDetails.setString(8, Amount);
                                                                                    sendInvoiceDetails.setString(9, custaccid);
                                                                                    sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                    sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                    sendInvoiceDetails.execute();

                                           sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                           sendInvoiceDetails.close();

                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the salesorder into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }

                                   return sendInvDetails;
         } 


    public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.TRUNCATETABLE; end;",
                         OADBTransaction.DEFAULT);
                     
                           
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
            
      }
      
    public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput[] = new String[2]; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             callableStatement.registerOutParameter(2, Types.VARCHAR);  
            
           
             callableStatement.execute();  
           
             arrOutput[0] = callableStatement.getString(1);  
             arrOutput[1] = callableStatement.getString(2);  
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }


        public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean){
              
          
              String resp[] = new String[6];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                              
                        callableStatement.registerOutParameter(1, Types.VARCHAR);
                        callableStatement.registerOutParameter(2, Types.VARCHAR);
                        callableStatement.registerOutParameter(3, Types.VARCHAR);
                        callableStatement.registerOutParameter(4, Types.VARCHAR);
                        callableStatement.registerOutParameter(5, Types.VARCHAR);
                         callableStatement.registerOutParameter(6, Types.VARCHAR); 
                         callableStatement.execute();
                        
						String      o_temp = callableStatement.getString(1);
                        String      o_subject = callableStatement.getString(2);
                        String      o_fromemail = callableStatement.getString(3);
                        String      o_fromname = callableStatement.getString(4);
                        String      errorcode = callableStatement.getString(5);
                        String      errormsg = callableStatement.getString(6);
                         
                         resp[0] = o_temp;
                         resp[1] = o_subject;
                         resp[2] = o_fromemail;
                         resp[3] = o_fromname;
                         resp[4] = errorcode;
                         resp[5] = errormsg;
                              
                         

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              return resp;
          }

    public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){
          
      
          String resp[] = new String[6];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                      OADBTransaction.DEFAULT);
                    callableStatement.setString(1, p_cust_num);
                    callableStatement.registerOutParameter(2, Types.VARCHAR);
                     callableStatement.execute();
                     String  p_cust_name = callableStatement.getString(2);
                     resp[0] = p_cust_name;  
                     callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }
    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                              callableStatement.setString(2, internalId);
                         callableStatement.setString(3, sentId);
                         callableStatement.setString(4, sentCount);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            callableStatement.registerOutParameter(6, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(5);
                            String  errormsg = callableStatement.getString(6);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
       
     

        public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                 CallableStatement stmtaddTemplate;
              String userId = String.valueOf(paramOAPageContext.getUserId());
                      try {
                             OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count_so(:1,:2,:3); end;",
                             OADBTransaction.DEFAULT);
                         
                                 stmtaddTemplate.setInt(1, pendingreqId);
                                 stmtaddTemplate.setInt(2, count); 
                                 stmtaddTemplate.setString(3, userId); 
                                 
                                 
                                 
                             stmtaddTemplate.execute();

                             stmtaddTemplate.close();   
                                            
                        } catch (SQLException e) {
                            throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                        }
                                    
                 return true;
          }
		      public String[] getTransactionPaid(OAPageContext pageContext, OAWebBean webBean,String custNum,String fromDate,String toDate){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_transaction_paid(:1,:2,:3,:4,:5); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.setString(2, fromDate);
                            callableStatement.setString(3, toDate);
                            callableStatement.registerOutParameter(4, Types.VARCHAR);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(4);
                            String  errormsg = callableStatement.getString(5);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getTransactionPaid Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
		  
		  
		  public String getcustEmail(OAPageContext pageContext, OAWebBean webBean,String custNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_cust_email(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getcustEmail Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
		      public String[] isValidate(String TemplateLovIn,String EmailSubjectIn,String SalesOrderNo,String SoAmount,String EmailFromIn,String CustomerNo,String EmailToIn) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(TemplateLovIn)) || "".equals(String.valueOf(TemplateLovIn))) {
        retMessage = retMessage + "Template, ";
      }

      if ("null".equals(String.valueOf(EmailSubjectIn)) || "".equals(EmailSubjectIn)) {
        retMessage = retMessage + "Email Subject, ";
      }

      if ("null".equals(String.valueOf(SalesOrderNo)) || "".equals(String.valueOf(SalesOrderNo))) {
        retMessage = retMessage + "SalesOrder Number, ";
      }

      if ("null".equals(String.valueOf(SoAmount)) || "".equals(String.valueOf(SoAmount))) {
        retMessage = retMessage + "SalesOrder Amount, ";
      }
      if ("null".equals(String.valueOf(EmailFromIn)) || "".equals(EmailFromIn)) {
        retMessage = retMessage + "Email Send From, ";
      }
      if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
        retMessage = retMessage + "Customer Number, ";
      }

      if ("null".equals(String.valueOf(EmailToIn)) || "".equals(String.valueOf(EmailToIn))) {
        retMessage = retMessage + "Email Send To ";
      }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are required field(s). Please fill in all required fields. ";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Salesorder data is validated.";
      }
      return output;
    }
		  public void checkEmailAddress(String inEmailArr){
          String[] emailArray = tokenizerStr(inEmailArr);
              
              for(int i = 0; i<emailArray.length; i++) {
                if(isValidEmailAddress(emailArray[i])){
                    
                }
                else{
                    
                    throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                }
              }
      }
      
      public boolean isValidEmailAddress(String email) {
         boolean result = true;
         try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
         } catch (AddressException ex) {
            result = false;
         }
         return result;
      }
	  
	      public String[] tokenizerStr(String inEmailArr){
        String  inputString = inEmailArr.replaceAll("\\s+", "");
        String[] arry = inputString.split(",");
        
        return arry;
    }
	public String getSoCount(OAPageContext pageContext, OAWebBean webBean,String soNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.getSaleorderEmailCount(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, soNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getSoCount Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
}
