package ebizch.oracle.apps.fnd.rtsync.webui;

 import com.sun.java.util.collections.HashMap;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChWltCreditCardVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.OARow;
import oracle.jbo.Row;

public class EbizChWltCreateCcDetailCO extends OAControllerImpl
{
	String CUST_NUM="";
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	String CUST_NO="";
	if (pageContext.getParameter("CUST_NUM")!=null)
	{	
	 CUST_NO = pageContext.getParameter("CUST_NUM");	
	 CUST_NUM = pageContext.getParameter("CUST_NUM");
	}
	else
	{
	   CUST_NO = pageContext.getParameter("CUST_NO");	
	}
   
      EbizChRtsyncAMImpl am = 
          (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
    
          
      OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
	  VO.setWhereClause("customer_no="+CUST_NO);
	  VO.executeQuery();
	  
        am.CreateRecordCreditCardVO();    
       
	 //  String getCustname[] =new String[1];
     //  getCustname = getCustName(pageContext, webBean,CUST_NO);
       //String Custname = getCustname[0];
	 //  OAMessageTextInputBean AccountHoldernameBean = (OAMessageTextInputBean)webBean.findChildRecursive("AccountHoldername");
       //AccountHoldernameBean.setText(pageContext,Custname);
	   
	 
            
      }
	  

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    //super.processFormRequest(pageContext, webBean);
	String formlink="";
    // String CUST_NO = pageContext.getParameter("CUST_NO");
	String CUST_NO="";
	if (CUST_NUM!="")
	{
		
	 CUST_NO = CUST_NUM;
	 formlink="Yes";
	}
	else
	{
	   CUST_NO = pageContext.getParameter("CUST_NO");	
	}
     String inCurPartyID = pageContext.getParameter("PagePartyId");
     String inCurPartySiteID = pageContext.getParameter("PagePartySiteId");
     String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
     String IbyCustAccountId= pageContext.getParameter("IbyCustAccountId");
     String  str2 = pageContext.getParameter("IbyCustAccountSiteId");
     String  str4 = pageContext.getParameter("IbyOrgId");
     String IbyReturnlink = pageContext.getParameter("IbyReturnlink");
     HashMap localHashMap = new HashMap();
     
     localHashMap.put("IbyOrgId", str4);
     localHashMap.put("AcctId", IbyCustAccountId);
	 
      
      EbizChRtsyncAMImpl am = 
          (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
		  
		
      if (pageContext.getParameter("DelBtn") != null) { 
          {
              EbizChRtCustCcVOImpl CcVo = am.getEbizChRtCustCcVO1();
              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
              EbizChRtCustCcVORowImpl CustCcRowVo = null;
              Row rows[] = CcVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                                CustCcRowVo = (EbizChRtCustCcVORowImpl) rows[i];
                                String methodID = (String) CustCcRowVo.getAttribute("MethodId");
                                String Ccnumber = (String) CustCcRowVo.getAttribute("CcCardNumber");
								
                               // am.deleteRecord();
                                
                               
                               
                               String[] ccDelCcInfo =  wallet_DelCreditCard(pageContext, webBean, CUST_NO ,methodID);
                                String errorcode = ccDelCcInfo[0];
                                String errormsg = ccDelCcInfo[1];
                                if (errorcode == "S" || errorcode.equals("S") ) {
                                
                                    excCollectAdd = excCollectAdd + " Successfull: Card "+ Ccnumber+" has been deleted from EBizCharge.";
                                    success_count++;
                                }
                                else {
                                    excCollectAdd = excCollectAdd + " Error: The Card "+Ccnumber+" "+" has not been deleted from Ebiz Gateway. Error Code";
                                    error_count++;
                                   
                                }
                             
                            }
                            
                                                     
                                                     if(success_count > 0 && error_count < 1){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
														 if(!ccLov[0].equals("S")){
															throw new OAException("CreditCardLov not populated.", OAException.ERROR);    
														 }
														OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
														VO.setWhereClause("customer_no="+CUST_NO);
														VO.executeQuery();
                                                             throw new OAException("Success: "+ success_count +" Cards has been deleted.", OAException.INFORMATION);
                                                     }
                                                     
                                                     if(success_count < 1 && error_count > 0){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                                                             
                                                             throw new OAException("Error: "+ error_count +" Cards has not been deleted.", OAException.ERROR);
                                                     }
                                                     
                                                     if(success_count > 0 && error_count > 0){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
														 if(!ccLov[0].equals("S")){
															throw new OAException("CreditCardLov not populated.", OAException.ERROR);    
														 }
														OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustCcVO1");
														VO.setWhereClause("customer_no="+CUST_NO);
														VO.executeQuery();
                                                             throw new OAException("Success: "+ success_count +" Cards has been deleted in EBizCharge but the "+ error_count +" deleted has not been deleted.", OAException.ERROR);
                                                     }     
                            
                            
                            }

          }

      
      

      }      
  

		String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);

		if ("DefaultLink".equals(eventParam))
		{
			
			
			//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow currRow = (OARow)am.findRowByRef(rowReference);
			String MethodId = (String)currRow.getAttribute("MethodId");
			
			String[] defaultCc=defaultCc(pageContext, webBean,CUST_NO,MethodId);
			String errorcode = defaultCc[0];
			String errormsg = defaultCc[1];
			if ("S".equals(errorcode))
			{
				 throw new OAException("Payment Method : "+ MethodId +" has been defaulted Successfully.", OAException.INFORMATION);
			}
			else
			{
				throw new OAException("Payment Method : "+ MethodId +" has not been defaulted Successfully.", OAException.ERROR);
				
			}
			
			
		}
		super.processFormRequest(pageContext, webBean);
  }
    public String ConvertDate(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean, String vdate
                                          ) {

        String resp , v_conDate; 
       
        try {
			 OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin ebizch_wlt_CreditCard_pkg.xx_convert_date_cc(:1,:2); end;", 
                                        OADBTransaction.DEFAULT);
            callableStatement.setString(1, vdate);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            

            
            
            callableStatement.execute();
			
			v_conDate = callableStatement.getString(2);
			resp = v_conDate;
            callableStatement.close();

            return resp;
        } catch (SQLException e) {
            throw new OAException("Convert Date: " + e.getMessage(), OAException.ERROR);
        }
    }
    public String[] wallet_DelCreditCard(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean,                                     
                                          String p_cust_no, 
                                          String p_method_id
                                          ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.delete_creditcard(:1,:2, :3, :4); end;", 
                                        OADBTransaction.DEFAULT);
        try {
            
            callableStatement.setString(1, p_cust_no);
            callableStatement.setString(2, p_method_id);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.registerOutParameter(4, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(3);
            resp[1] = callableStatement.getString(4);


            callableStatement.close();

            
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException(errMsg, OAException.INFORMATION);
        }
        return resp;

    } 
     
    

    public void clearField(OAPageContext pageContext, OAWebBean webBean){

        OAMessageLovInputBean countryBean =(OAMessageLovInputBean)webBean.findChildRecursive("Country");
        countryBean.setValue(pageContext,null);
        
        OAMessageTextInputBean accountHoldernameBean = (OAMessageTextInputBean)webBean.findChildRecursive("AccountHoldername");
        accountHoldernameBean.setValue(pageContext,null);
        
        OAMessageTextInputBean cardNumberBean = (OAMessageTextInputBean)webBean.findChildRecursive("CardNumber");
        cardNumberBean.setValue(pageContext,null);
        
        OAMessageTextInputBean securityCodeBean = (OAMessageTextInputBean)webBean.findChildRecursive("SecurityCode");
        securityCodeBean.setValue(pageContext,null);
        
        OAMessageDateFieldBean  cardExpirationBean = (OAMessageDateFieldBean )webBean.findChildRecursive("CardExpiration");
        cardExpirationBean.setValue(pageContext,null);
        
        OAMessageLovInputBean cctype6 =(OAMessageLovInputBean)webBean.findChildRecursive("cctype6");
        cctype6.setValue(pageContext,null);
        
         OAMessageChoiceBean state = (OAMessageChoiceBean)webBean.findChildRecursive("State");
         state.setValue(pageContext,null);
        
        OAMessageTextInputBean cardBillingAddressBean = (OAMessageTextInputBean)webBean.findChildRecursive("CardBillingAddress");
        cardBillingAddressBean.setValue(pageContext,null);
        
        OAMessageTextInputBean cityBean = (OAMessageTextInputBean)webBean.findChildRecursive("city");
        cityBean.setValue(pageContext,null);
        
        OAMessageTextInputBean zipCodeBean = (OAMessageTextInputBean)webBean.findChildRecursive("ZipCode");
        zipCodeBean.setValue(pageContext,null);
        
        OAMessageChoiceBean cctype1Bean = (OAMessageChoiceBean)webBean.findChildRecursive("cctype1");
        cctype1Bean.setValue(pageContext,null);
    
        
    }
	
	    public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){


           String resp[] = new String[6];
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                       OADBTransaction.DEFAULT);

                     callableStatement.setString(1, p_cust_num);
                     callableStatement.registerOutParameter(2, Types.VARCHAR);

                      callableStatement.execute();
                      String  p_cust_name = callableStatement.getString(2);
                      resp[0] = p_cust_name;
                      callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                  }

           return resp;
       }
    public String[] defaultCc(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo,String methodId)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_CreditCard_pkg.ebizch_default_cc(:1,:2,:3,:4); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
		  callableStatement.setString(2, methodId);
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
          callableStatement.registerOutParameter(4, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(3);    
          resp[1] = callableStatement.getString(4);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("defaultCc: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
	 public String[] creditCardLov(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
          callableStatement.registerOutParameter(2, Types.VARCHAR);  
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(2);    
          resp[1] = callableStatement.getString(3);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("creditCardLov: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
}
