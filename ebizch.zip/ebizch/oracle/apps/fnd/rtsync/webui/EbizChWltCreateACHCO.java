package ebizch.oracle.apps.fnd.rtsync.webui;

 import com.sun.java.util.collections.HashMap;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustAchVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustAchVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChWltAchVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChWltCreditCardVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADialogPage;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageChoiceBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageDateFieldBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.OARow;
import oracle.jbo.Row;
import java.io.Serializable;
import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;

public class EbizChWltCreateACHCO extends OAControllerImpl
{
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
     String CUST_NO = pageContext.getParameter("CUST_NO");
      EbizChRtsyncAMImpl am = 
          (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
    
      String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
      if(!ccLov[0].equals("S")){
          throw new OAException("CreditCardLov not populated.", OAException.ERROR);    
      }
        //  am.initEbizChRtCustCcVO();
       //   am.initEbizChRtCustAchVO();
	   
		  OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
		  VO.setWhereClause("customer_no="+CUST_NO);
	      VO.executeQuery();
        //  am.CreateRecordCreditCardVO();    
          am.CreateRecordAchVO();
		  
	 String getMerchantData=getMerchantData(pageContext,webBean);
	
	if ("false".equals(getMerchantData))
	{
		OASubmitButtonBean sendReqBtn = (OASubmitButtonBean) webBean.findChildRecursive("Create");
		sendReqBtn.setDisabled(true);
		throw new OAException("Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.", OAException.WARNING);
	}
      }
	
  

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    //super.processFormRequest(pageContext, webBean);
     String CUST_NO = pageContext.getParameter("CUST_NO");
     String inCurPartyID = pageContext.getParameter("PagePartyId");
     String inCurPartySiteID = pageContext.getParameter("PagePartySiteId");
     String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
     String IbyCustAccountId= pageContext.getParameter("IbyCustAccountId");
     String  str2 = pageContext.getParameter("IbyCustAccountSiteId");
     String  str4 = pageContext.getParameter("IbyOrgId");
     String IbyReturnlink = pageContext.getParameter("IbyReturnlink");
      
       HashMap localHashMap = new HashMap();
     
     localHashMap.put("IbyOrgId", str4);
     localHashMap.put("AcctId", IbyCustAccountId);
      
      EbizChRtsyncAMImpl am = 
          (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
          
    if (pageContext.getParameter("Cancel") != null) {    
    pageContext.setForwardURL(IbyReturnlink+"&retainAM=Y",
                                                  null, 
                                                  OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                                  null, localHashMap, true, "Y", (byte)99);

      } 
      
      //if (pageContext.getParameter("DelBtn") != null) { 
        if ("DelBtn".equals(pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM))) {
		 String lineRefId = (String)pageContext.getParameter(OAWebBeanConstants.EVENT_SOURCE_ROW_REFERENCE);
		 
          OAException descMesg =  new OAException("Confirmation");
          OAException instrMesg = new OAException("Are you sure you want to delete this payment method?");

          OADialogPage dialogPage = new OADialogPage(OAException.WARNING, descMesg, instrMesg, "",  "");
                       dialogPage.setNoButtonItemName("DeleteNoButton");
                       dialogPage.setOkButtonItemName("DeleteYesButton");
                       dialogPage.setOkButtonToPost(true);
                       dialogPage.setNoButtonToPost(true);
                       dialogPage.setPostToCallingPage(true);
                       dialogPage.setOkButtonLabel("Yes");
                       dialogPage.setNoButtonLabel("No");

				EbizChRtCustAchVOImpl CcVo = am.getEbizChRtCustAchVO1();

              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
			   String AccountNumber="";
              EbizChRtCustAchVORowImpl CustCcRowVo = null;
              Row rows[] = CcVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;
			  String[] methodID =new String[rowsLength];
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                                CustCcRowVo = (EbizChRtCustAchVORowImpl) rows[i];
                                 methodID[i] = (String) CustCcRowVo.getAttribute("MethodId");
								  AccountNumber = (String) CustCcRowVo.getAttribute("AchAccount");
							}
			  }
	  
          java.util.Hashtable formParams = new java.util.Hashtable(2);
		  String toCsvValue= toCSV(methodID);
                              formParams.put("lineRefId", toCsvValue);
							  formParams.put("customerID", AccountNumber);
							  
                              dialogPage.setFormParameters(formParams);
          pageContext.redirectToDialogPage(dialogPage);
                                  
          if (pageContext.getParameter("DeleteYesButton") != null) {
                       lineRefId = pageContext.getParameter("lineRefId");
                       String str="";
                      Serializable[] parameters = {lineRefId };
                   
                  }
		}
		else  if (pageContext.getParameter("DeleteYesButton") != null)
				{
			 
   		   	 String customerId = pageContext.getParameter("customerID"); 
			  String lineRefId = pageContext.getParameter("lineRefId"); 
			  String[] items = lineRefId.split("\\s*,\\s*");
			   int itemLength= items.length;
			 
			  		  
              String excCollectAdd = " ";
              int success_count = 0;
              int error_count = 0;
              
              int rowsLength = items.length;
			
              if (rowsLength > 0) {
                            for (int i = 0; i < rowsLength; i++) {
                              
								
                                String methodID =items[i];
                                String AccountNumber = customerId;
                             
                                String[] ccDelCcInfo  = new String[2];
                                ccDelCcInfo =wallet_DelCreditCard(pageContext, webBean, CUST_NO ,methodID);
                                String errorcode = ""; 
                                errorcode = ccDelCcInfo[0];
                               
                                String errormsg = ccDelCcInfo[1];
                                if (errorcode == "S" || errorcode.equals("S") ) {
                                
                                    //excCollectAdd = AccountNumber+" account(s) has been successfully deleted.";

                                    success_count++;
                                }
                                else {
                                    //excCollectAdd = excCollectAdd + " Error: The  "+AccountNumber+" "+" have not been deleted from Ebiz Gateway. Error Code";
                                    error_count++;
                                   
                                }
                             
                            }
                            
                                                if(success_count == 1){
                                                    String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                                                  //  am.initEbizChRtCustAchVO();
													OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CUST_NO);
														VO.executeQuery();
                                                        throw new OAException("Success: "+success_count +" account(s) have been successfully deleted.", OAException.INFORMATION);
                                                }
                                            
                                                                     
                                                     if(success_count > 1 && error_count < 1){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
														 OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CUST_NO);
														VO.executeQuery();
                                                         //am.initEbizChRtCustAchVO();
                                                             throw new OAException("Success: "+success_count +" account(s) have been successfully deleted.", OAException.INFORMATION);
                                                     }
                                                     
                                                     if(success_count < 1 && error_count > 1){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                                                         am.initEbizChRtCustAchVO();
                                                             throw new OAException("Error: "+error_count +" account(s) have not been deleted.", OAException.ERROR);
                                                     }
                                                     
                                                     if(success_count > 1 && error_count > 1){
                                                         String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
                                                       //  am.initEbizChRtCustAchVO();
													   OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
														VO.setWhereClause("customer_no="+CUST_NO);
														VO.executeQuery();
                                                             throw new OAException(success_count +" account(s) have been successfully deleted in EBizCharge but the "+ error_count +" account(s) have not been deleted.", OAException.ERROR);
                                                     }     
                            
                            
                            }

          }

    
			 else if (pageContext.getParameter("DeleteNoButton") != null)
                   {
				//throw new OAException("No",OAException.ERROR);   

					}      
  if (pageContext.getParameter("Clear") != null) { 
clearField(pageContext, webBean);
  }
    
    
  if (pageContext.getParameter("Create") != null) {       

      EbizChWltAchVORowImpl row = (EbizChWltAchVORowImpl)am.getEbizChWltAchVO1().getCurrentRow();
      row.getAccountHolderName();
	  String v_Account_num = row.getBankAccountNumber();
	 validator (pageContext, webBean,row.getAccountHolderName(),row.getBankAccountNumber(),row.getBankRoutingNumber(),row.getAccountType());
			  String[] ccInfo = 
					wallet_add_Ach(pageContext, webBean, 
										  CUST_NO, row.getAccountHolderName(), row.getBankAccountNumber(), 
										  row.getBankRoutingNumber(), row.getAccountType());
				String errorcode = ccInfo[0];
				String errormsg = ccInfo[1];
				if ("E".equals(errorcode)) {
					throw new OAException("Bank Account could not be added due to invalid account information entered. Please verify the Routing Number and/or Bank Account Number before trying again." , OAException.ERROR);
				}
				else if ("S".equals(errorcode)) {
					      String[] ccLov = creditCardLov(pageContext, webBean, CUST_NO);
      if(!ccLov[0].equals("S")){
          throw new OAException("Accounts are not populated.", OAException.ERROR);    
      }
                                    
                                   am.initEbizChRtCustAchVO();
				
				    clearField(pageContext,webBean);
					throw new OAException(  "Account No. " + v_Account_num+ " has been created successfully  ",  OAException.INFORMATION);
				}
				else {
					throw new OAException( "Error code is null.",  OAException.ERROR);
				}
            

         
        }
		String eventParam = pageContext.getParameter(OAWebBeanConstants.EVENT_PARAM);
		if ("DefaultLink".equals(eventParam))
		{
			
			
			//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
			String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow currRow = (OARow)am.findRowByRef(rowReference);
			String MethodId = (String)currRow.getAttribute("MethodId");
			String AchAccount = (String)currRow.getAttribute("AchAccount");
			String AchAccountType = (String)currRow.getAttribute("AchAccountType");
		
			
			String[] defaultCc=defaultCc(pageContext, webBean,CUST_NO,MethodId);
			String errorcode = defaultCc[0];
			String errormsg = defaultCc[1];
			if ("S".equals(errorcode))
			{
				OAViewObject VO = (OAViewObject)am.findViewObject("EbizChRtCustAchVO1");
				VO.setWhereClause("customer_no="+CUST_NO);
				VO.executeQuery();
				
				throw new OAException("Payment Method bank account ending with "+ AchAccount.substring(AchAccount.length()-4) + "(" + AchAccountType + ") has been defaulted successfully.", OAException.INFORMATION);
				
			}
			else
			{
				throw new OAException("Payment Method bank account ending with "+ AchAccount.substring(AchAccount.length()-4) + "(" + AchAccountType + ") has been defaulted successfully.", OAException.ERROR);
				
			}
			
			
		}
		super.processFormRequest(pageContext, webBean);
  }
    public String ConvertDate(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean, String vdate
                                          ) {

        String resp , v_conDate; 
       
        try {
			 OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin ebizch_wlt_CreditCard_pkg.xx_convert_date_cc(:1,:2); end;", 
                                        OADBTransaction.DEFAULT);
            callableStatement.setString(1, vdate);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            

            
            
            callableStatement.execute();
			
			v_conDate = callableStatement.getString(2);
			resp = v_conDate;
            callableStatement.close();

            return resp;
        } catch (SQLException e) {
            throw new OAException("Convert Date: " + e.getMessage(), OAException.ERROR);
        }
    }
    public String[] wallet_DelCreditCard(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean,                                     
                                          String p_cust_no, 
                                          String p_method_id
                                          ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.delete_creditcard(:1,:2, :3, :4); end;", 
                                        OADBTransaction.DEFAULT);
        try {
            
            callableStatement.setString(1, p_cust_no);
            callableStatement.setString(2, p_method_id);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.registerOutParameter(4, Types.VARCHAR);
            callableStatement.execute();

            resp[0] = callableStatement.getString(3);
            resp[1] = callableStatement.getString(4);


            callableStatement.close();
            return resp;
            
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException(errMsg, OAException.INFORMATION);
        }
       

    } 
     
    
 

    public String[] wallet_add_Ach(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean,
                                          String num, 
                                          String p_AccountHolderName,
                                          String p_AccountNumber,
                                          String p_RoutingNumber,
                                          String p_AccountType
                                         
                                          ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin   ebizch_wlt_Ach_pkg.create_ach(:1,:2, :3, :4,:5,:6,:7); end;", 
                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1,  num);
            callableStatement.setString(2,  p_AccountHolderName);
            callableStatement.setString(3,  p_AccountNumber);
            callableStatement.setString(4,  p_RoutingNumber);
            callableStatement.setString(5,  p_AccountType);
           
            callableStatement.registerOutParameter(6, Types.VARCHAR);
            callableStatement.registerOutParameter(7, Types.VARCHAR);

            callableStatement.execute();
			
	    resp[0] = callableStatement.getString(6);
            resp[1] = callableStatement.getString(7);
			
            callableStatement.close();

            return resp;
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException("Account Create: "+errMsg, OAException.ERROR);
        }

    }    
    
    public String[] wallet_CheckAVS(OAPageContext paramOAPageContext, 
                                          OAWebBean paramOAWebBean,                                     
                                          String p_CardNumber, 
                                          String p_CardExpiration, String p_CUST_NO 
                                          ) {

        String[] resp = new String[2];
        OADBTransactionImpl txn = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            txn.createCallableStatement("begin   ebizch_wlt_CreditCard_pkg.cc_ver_resp(:1,:2, :3, :4,:5); end;", 
                                        OADBTransaction.DEFAULT);
        try {
            
           // callableStatement.setString(1, p_CUST_NO);
            callableStatement.setString(1, p_CardNumber);
            callableStatement.setString(2, p_CardExpiration);
			callableStatement.setString(3, p_CUST_NO);
         //   callableStatement.setString(4, p_card_type);
            callableStatement.registerOutParameter(4, Types.VARCHAR);
            callableStatement.registerOutParameter(5, Types.VARCHAR);

            callableStatement.execute();


            resp[0] = callableStatement.getString(4);
            resp[1] = callableStatement.getString(5);

            callableStatement.close();
            
        } catch (SQLException e) {
            String errMsg = e.getMessage();
            throw new OAException("AVS Wallet: "+errMsg, OAException.ERROR);
        }
        return resp;

    } 
    public String[] creditCardLov(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
          callableStatement.registerOutParameter(2, Types.VARCHAR);  
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(2);    
          resp[1] = callableStatement.getString(3);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("creditCardLov: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
    
    public void clearField(OAPageContext pageContext, OAWebBean webBean){

     
        
        OAMessageTextInputBean accountHoldernameBean = (OAMessageTextInputBean)webBean.findChildRecursive("AccountHoldername");
        accountHoldernameBean.setValue(pageContext,null);
        
        OAMessageTextInputBean cardNumberBean = (OAMessageTextInputBean)webBean.findChildRecursive("RoutingNumber");
        cardNumberBean.setValue(pageContext,null);
        
        OAMessageTextInputBean securityCodeBean = (OAMessageTextInputBean)webBean.findChildRecursive("BankAccountNumber");
        securityCodeBean.setValue(pageContext,null);

        
        OAMessageChoiceBean cctype1Bean = (OAMessageChoiceBean)webBean.findChildRecursive("AccountType");
        cctype1Bean.setValue(pageContext,null);
    
        
    }
	public String[] defaultCc(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo,String methodId)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_CreditCard_pkg.ebizch_default_cc(:1,:2,:3,:4); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
		  callableStatement.setString(2, methodId);
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
          callableStatement.registerOutParameter(4, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(3);    
          resp[1] = callableStatement.getString(4);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("defaultCc: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
	
	  public void validator (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String accname,String accNum,String accRoutNum,String accType)
	{
		String v_return="";
		 if (accname==null || accname=="")
		  {
			  v_return =" Account Holder Name";
		  }
		  if (accNum==null || accNum=="")
		  {
			 v_return =v_return + "Bank Account Number";
		  }
		  
		  if (accRoutNum==null || accRoutNum=="")
		  {
			 v_return =v_return + "Bank Routing Number";
		  }
		  
		   if (accType==null || accType=="")
		  {
			   v_return = v_return + "Bank Account Type";
		  }
		
		 
		  if (v_return=="null" || v_return=="")
		  {
		  }
		  else
		  {
			  throw new OAException (v_return + " is a required field. Please fill in all required fields..",OAException.ERROR);
			  
		  }
		  
	} 
      public static String toCSV(String[] array) { 
    String result = ""; 
    if (array.length > 0)
    { 
    StringBuilder sb = new StringBuilder(); 
    for (String s : array) { sb.append(s).append(","); 
    } result = sb.deleteCharAt(sb.length() - 1).toString(); 
    } 
    return result;
    } 

  public String getMerchantData(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput=""; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wallet_common_pkg.get_merchant_transaction_ach(:1); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             
             callableStatement.execute();  
           
             arrOutput = callableStatement.getString(1);   
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get getMerchantData Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }	
}
