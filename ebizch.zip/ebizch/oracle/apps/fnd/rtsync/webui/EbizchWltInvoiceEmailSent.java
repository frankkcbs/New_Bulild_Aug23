 package ebizch.oracle.apps.fnd.rtsync.webui;

import java.math.BigDecimal;

 import java.sql.CallableStatement;
 import java.sql.SQLException;
 import java.sql.Types;
	import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EmaiInvoiceSentVOImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EmaiInvoiceSentVORowImpl;

import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
 import ebizch.oracle.apps.fnd.rtsync.server.GwTemplatesLovVOImpl;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.jbo.domain.Number;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

import oracle.jbo.Row;


public class EbizchWltInvoiceEmailSent extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");


   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName="";
		String fromDate="";
		String toDate="";	   
			
	 
         String inInvOrg = pageContext.getParameter("INV_ORG");
         String inCustNum = pageContext.getParameter("CUST_NO");
		  
		 
					  
         String inCustDefaultEmail = getCustEmail (pageContext, webBean,  Integer.parseInt(inInvOrg), inCustNum);
            
       String getCustname[] =new String[1];
       getCustname = getCustName(pageContext, webBean,inCustNum);
       String Custname = getCustname[0];
            
       
       Truncate(pageContext,webBean);
       
       String getEmailTempResp[] =new String[2];
       getEmailTempResp =  createEmailTemplate(pageContext, webBean);
       
       String getResp[] =new String[3];
       getResp =  get_EmailTempbyClassCode(pageContext,webBean);
       inEmailTemplate = getResp[0];
       inSubjectText = getResp[1];
       inFromMail = getResp[2];
       inFromName= getResp[3];
      
	   String[] updateflag=getTransactionPaid(pageContext,webBean,inCustNum,fromDate, toDate);
            
		String inInvNum = pageContext.getParameter("INV_NO");
        String invAmt= pageContext.getParameter("INV_AMT");
        
        OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
        lovBean.setText(pageContext,inEmailTemplate);
		
		OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
        TemplateIdFvInput.setValue(pageContext,inEmailTemplate);
		
		
        OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
        textBean.setText(inSubjectText);
		
		OAFormValueBean inSubjectFv1 = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
		inSubjectFv1.setValue(inSubjectText);
            
        OAMessageTextInputBean textBeanSalesOrderNo = (OAMessageTextInputBean)webBean.findChildRecursive("InvoiceNo");
        textBeanSalesOrderNo.setText(inInvNum);
            
        OAMessageTextInputBean textBeanSoAmount = (OAMessageTextInputBean)webBean.findChildRecursive("InvAmount");
        textBeanSoAmount.setText(pageContext.getParameter("INV_AMT"));
            
        OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
        EmailFromIntextBean.setText(inFromMail);
		
		OAFormValueBean fromEmailFv1 = (OAFormValueBean)webBean.findIndexedChildRecursive("fromEmailFv");
		fromEmailFv1.setValue(pageContext,inFromMail);
        
        OAMessageTextInputBean CustomerNoBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerNo");
        CustomerNoBean.setText(pageContext,inCustNum);
        
        OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
        CustomerNameBean.setText(pageContext,Custname);
       
        OAMessageTextInputBean EmailToInBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
        EmailToInBean.setText(pageContext,inCustDefaultEmail);
		EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
		
		am.initEmaiInvoiceSentVO(); 
		executeVO(pageContext, webBean, inCustNum);
		
		
	   super.processRequest(pageContext, webBean);	 
        
               
   }


   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       String inFromMail="";
       String inEmailArr="";
       String strEvent= pageContext.getParameter(EVENT_PARAM) ;
       String messageValue="";
       int success_count = 0;
       int error_count = 0;
	   String inCustNum = pageContext.getParameter("CUST_NO");
	   

	  EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
      
	  if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("TemplateLovIn".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
             //String inSubjectFv1 = inSubjectFv.getValue(pageContext).toString();
             String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("fromEmailFv");
             //String infromEmailFv = fromEmailFv.getValue(pageContext).toString(); 
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }

	  String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID     from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATETYPEID = 'WebFormEmail'";
                     try
                     {
              
                           GwTemplatesLovVOImpl vo1 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                           vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                           vo1.setQuery(query);
                           vo1.executeQuery();
                      }
                      catch (Exception e)
                      {
                          throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                      }  
	 
       if (pageContext.getParameter("Send") != null) {
                   
                   if (pageContext.getParameter("EmailFromIn") != null) {
                           inFromMail = pageContext.getParameter("EmailFromIn");
                           checkEmailAddress(inFromMail);
           }
                   else{
                           throw new OAException("Enter the From Email Address.", OAException.ERROR);
                   }

           if (pageContext.getParameter("EmailToIn") != null) {
               inEmailArr = pageContext.getParameter("EmailToIn");
                           checkEmailAddress(inEmailArr);
           }
                   else{
                           throw new OAException("Enter the To Email Address.", OAException.ERROR);
                   }     
                   
           String inInvNum = pageContext.getParameter("INV_NO");
           String inInvOrg = pageContext.getParameter("INV_ORG");

           String[] invDetails = getInvDetails (pageContext, webBean, Integer.parseInt(inInvOrg), inInvNum) ;
           
          String custIdStr = invDetails[1];
          
           String CustAccNoString = invDetails[2]; 

           String invCustomerName = invDetails[0];

           String invNumb = invDetails[3];

           String invdateStr = invDetails[9];
           
           String invOrgIdStr = inInvOrg;
           
           String invCurr = invDetails[7];

           String invAmtDueStr = invDetails[4];
        //   BigDecimal invAmtDueBD = new BigDecimal(invAmtDueStr);

           String invSaleOrder = invDetails[14]; 
           
           int invInvoiceToInt = Integer.parseInt(invDetails[15]);
           
           int invShipToInt = Integer.parseInt(invDetails[16]);

           if (pageContext.getParameter("EmailFromIn") != null) {
               inFromMail = pageContext.getParameter("EmailFromIn");
           }

           if (pageContext.getParameter("EmailToIn") != null) {
               inEmailArr = pageContext.getParameter("EmailToIn");
           }
		   
           OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
           String inTemplateName = String.valueOf(TemplateIdFvInput.getValue(pageContext));
		  
            OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("inSubjectFv");
            String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
		   
			String[] validationsMessage = isValidate(inTemplateName,inSubjectFv1,invNumb,pageContext.getParameter("InvAmount"),inFromMail,CustAccNoString,inEmailArr);
		   //	String messageValue="";
		   
		   if (validationsMessage[0].equals("1")) {
			        messageValue = messageValue + validationsMessage[1];
			      }
				  
           if (validationsMessage[0].equals("1")){
			       throw new OAException (messageValue,OAException.ERROR);
			      }
				  
			 checkEmailAddress(inFromMail);  
		     checkEmailAddress(inEmailArr);
			 
			if (Float.parseFloat(pageContext.getParameter("InvAmount"))>Float.parseFloat(pageContext.getParameter("INV_AMT")))
		   {
			   throw new OAException ("Requested Amount should not be greater than Invoice Amount. Please Check!",OAException.ERROR);
			   
		   }
		   
		   String invCount =getInvCount(pageContext, webBean,invNumb);
		   if (Integer.parseInt(invCount)>=1)
		   {
			 throw new OAException ("Invoice payment request has been already sent one time. Please resend it below.",OAException.ERROR);  
			   
		   }
		   
		    if (Float.parseFloat(pageContext.getParameter("InvAmount"))<=0)
		   {
			  throw new OAException ("Please Check the requested amount either it is 0 or less than 0.",OAException.ERROR);   
			   
		   }
		   
		   if (pageContext.getParameter("EmailToIn").equals("nobody@localhost"))
		   {
			  throw new OAException ("Please enter valid to email address.",OAException.ERROR);  
		   }
       /*    String[] validationsMessage = isValidate(CustAccNoString,invNumb,invOrgIdStr,inFromMail,inEmailArr,inSubjectFv1,inTemplateName);

              if (validationsMessage[0].equals("1")) {
                    messageValue = messageValue + validationsMessage[1];
                   }
                                          
                                       if (validationsMessage[0].equals("1")){
                                          error_count++;
                                       }
                                       else{*/
                                                  String[] sendinv=sendInvoice(pageContext, webBean, CustAccNoString,invSaleOrder,invOrgIdStr,invNumb,inEmailArr,inFromMail,inSubjectFv1,inTemplateName,pageContext.getParameter("InvAmount"));
                                         if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                                              {
                                                 success_count++;
												 executeVO(pageContext, webBean, inCustNum);
												  //am.initEmaiInvoiceSentVO();
                                                 throw new OAException("Invoice payment request sent successfully.Invoice Number :" +invNumb, OAException.INFORMATION);
                                                 
                                             }
                                          else{
                                               
                                         error_count++;
										 executeVO(pageContext, webBean, inCustNum);
										  //am.initEmaiInvoiceSentVO();
                                        throw new OAException("Invoice payment request have not been sent successfully.Invoice Number :" +invNumb, OAException.ERROR);
                                            }
                                      // }
         
             
       
       }
	      if (pageContext.getParameter("ResendReqBtn") != null) {

              EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
              EmaiInvoiceSentVOImpl custVo = am1.getEmaiInvoiceSentVO1();
              EmaiInvoiceSentVORowImpl EmailInvoiceSentVO = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              int requestSentCount=0;
             // int error_count=0;
              //String messageValue="";
            
		
					  
              if (rowsLength > 0) {
                  for (int i = 0; i < rowsLength; i++) {
					  
                      EmailInvoiceSentVO = (EmaiInvoiceSentVORowImpl) rows[i];
                      
                      Number inPendingReqIdNumb = (Number) EmailInvoiceSentVO.getAttribute("InvSentId");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      
                      inCustId = (String) EmailInvoiceSentVO.getAttribute("CustNum");
					  
					  String getCustname[] =new String[1];
					  getCustname = getCustName(pageContext, webBean,inCustId);
					  inCustName = getCustname[0];
                    
                      inUrlId = (String) EmailInvoiceSentVO.getAttribute("OutEbizUrl");
                      inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                      
                      inSentCount = (String) EmailInvoiceSentVO.getAttribute("sentCount");
                      int inSentCountInt = Integer.parseInt(inSentCount);
                      inSentCountInt = inSentCountInt + 1;
                      String countString=String.valueOf(inSentCountInt) ;
                      
                      String responseResend[] = resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId,inPendingReqIdString,countString);
                      String rurl = responseResend[0];
                      outWebUrl = outWebUrl +  rurl;
                           
                       
                      if(updatePendingReqCount(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                          requestSentCount++;
                      }else{
                          throw new OAException("Update Pending Request not done in Database", OAException.ERROR);
                      }
                      
                  }

			  if(requestSentCount>0 && error_count>0){
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(requestSentCount+" request(s) sent again successfully. " + error_count + " request(s) not sent again successfully " +" Beacause " +messageValue, OAException.WARNING);          
                }
                else if(requestSentCount>0 && error_count==0)
                {
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(requestSentCount+" request(s) sent again successfully." , OAException.INFORMATION);
                }
                else if(requestSentCount<=0 && error_count>0)
                {  
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(error_count + " request(s) not sent again successfully " +" Beacuase " +messageValue, OAException.ERROR);
                }
                else{
                  
                    throw new OAException("Error sending request(s), check log.", OAException.ERROR);
                }
                
              }

                    throw new OAException("Please select request to send it again.", OAException.WARNING);
              
          }
     super.processFormRequest(pageContext, webBean);
     
   }

     public String[] getInvDetails (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inInvNo){
         String[] invDetails = new String[17]; 
                     CallableStatement stmtGetCustAddDetails;
         try {
               OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                               stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetrtinv(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19); end;",
                                       OADBTransaction.DEFAULT);
                               
                               
                               stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(9, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(10, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(11, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(12, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(13, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(14, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(15, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(16, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(17, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(18, Types.VARCHAR);
                               stmtGetCustAddDetails.registerOutParameter(19, Types.VARCHAR);
                             
                               stmtGetCustAddDetails.setInt(1, inOrgId);
                               stmtGetCustAddDetails.setString(2, inInvNo);      
                               //int inAcctSiteId = Integer.parseInt(outParamValue12);
                               //stmtGetCustAddDetails.setString(2, addType);
                                     
                               stmtGetCustAddDetails.execute();
                               
                               invDetails[0] = stmtGetCustAddDetails.getString(3);
                               invDetails[1] = stmtGetCustAddDetails.getString(4);
                               invDetails[2] = stmtGetCustAddDetails.getString(5);
                               invDetails[3] = stmtGetCustAddDetails.getString(6);
                               invDetails[4] = stmtGetCustAddDetails.getString(7);
                               invDetails[5] = stmtGetCustAddDetails.getString(8);
                               invDetails[6] = stmtGetCustAddDetails.getString(9);
                               invDetails[7] = stmtGetCustAddDetails.getString(10);
                               invDetails[8] = stmtGetCustAddDetails.getString(11);
                               invDetails[9] = stmtGetCustAddDetails.getString(12);
                               invDetails[10] = stmtGetCustAddDetails.getString(13);
                               invDetails[11] = stmtGetCustAddDetails.getString(14);
                               invDetails[12] = stmtGetCustAddDetails.getString(15);
                               invDetails[13] = stmtGetCustAddDetails.getString(16);
                               invDetails[14] = stmtGetCustAddDetails.getString(17);
                               invDetails[15] = stmtGetCustAddDetails.getString(18);
                               invDetails[16] = stmtGetCustAddDetails.getString(19);
                                     
                               stmtGetCustAddDetails.close();   
              /* if(true)
               {
               throw new OAException("Issue:"+invDetails[0] +" - "+ invDetails[1] +" - "+ invDetails[2] +" - "+ invDetails[3] +" - "+ invDetails[4] +" - "+ invDetails[5] +" - "+ invDetails[6] +" - "+ invDetails[7] +" - "+ invDetails[8] +" - "+ invDetails[9] +" - "+ invDetails[10] +" - "+ invDetails[11] +" - "+ invDetails[12], OAException.ERROR);
               }*/
           } catch (SQLException e) {
               throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
           }
                       
                       return invDetails;
     }
     
     
     public String[] tokenizerStr(String inEmailArr){
         String  inputString = inEmailArr.replaceAll("\\s+", "");
         String[] arry = inputString.split(",");
         
         return arry;
     }
     
     
     public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo) {
         String[] addDetails = new String[6];
         CallableStatement stmtGetCustAddDetails;
         try {
             OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
             stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetcustsiteadd(:1,:2,:3,:4,:5,:6,:7); end;",
                 OADBTransaction.DEFAULT);

             stmtGetCustAddDetails.registerOutParameter(2, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
             stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);

             stmtGetCustAddDetails.setInt(1, siteNo);

             //int inAcctSiteId = Integer.parseInt(outParamValue12);
             //stmtGetCustAddDetails.setString(2, addType);

             stmtGetCustAddDetails.execute();

             addDetails[0] = stmtGetCustAddDetails.getString(2);
             addDetails[1] = stmtGetCustAddDetails.getString(3);
             addDetails[2] = stmtGetCustAddDetails.getString(4);
             addDetails[3] = stmtGetCustAddDetails.getString(5);
             addDetails[4] = stmtGetCustAddDetails.getString(6);
             addDetails[5] = stmtGetCustAddDetails.getString(7);

             stmtGetCustAddDetails.close();

         } catch (SQLException e) {
             throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
         }

         return addDetails;
     }

    
    public String getCustEmail (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inCustNum){
        String outCustEmail = ""; 
                    CallableStatement stmtGetCustAddDetails;
        try {
              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.get_cust_email(:1,:2,:3); end;",
                                      OADBTransaction.DEFAULT);
                              
                              
                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                            
                              stmtGetCustAddDetails.setInt(1, inOrgId);
                              stmtGetCustAddDetails.setString(2, inCustNum);
                                    
                              stmtGetCustAddDetails.execute();
                              
                              outCustEmail = stmtGetCustAddDetails.getString(3);
                                    
                              stmtGetCustAddDetails.close();   
                              
          } catch (SQLException e) {
              throw new OAException("Exception getting email:" + e.getMessage(), OAException.ERROR);
          }
                      
                      return outCustEmail;
    }

     public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_inv_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_invoice_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                          OADBTransaction.DEFAULT);
                      
                              stmtaddTemplate.setString(1, p_cust_num);
                              stmtaddTemplate.setString(2, p_cust_name);
                              stmtaddTemplate.setString(3, p_inv_num);
                              stmtaddTemplate.setString(4, p_inv_org_id);
                              stmtaddTemplate.setString(5, p_email_to);
                              stmtaddTemplate.setString(6, p_out_ebiz_url);
                              stmtaddTemplate.setString(7, p_in_from_mail);
                              stmtaddTemplate.setString(8, p_in_to_mail);
                              stmtaddTemplate.setString(9, p_created_by);
                              
                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }
                                 
              return true;
       }
           
           public void checkEmailAddress(String inEmailArr){
           String[] emailArray = tokenizerStr(inEmailArr);
               
               for(int i = 0; i<emailArray.length; i++) {
                 if(isValidEmailAddress(emailArray[i])){
                     
                 }
                 else{
                     
                     throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                 }
               }
       }
       
       public boolean isValidEmailAddress(String email) {
          boolean result = true;
          try {
             InternetAddress emailAddr = new InternetAddress(email);
             emailAddr.validate();
          } catch (AddressException ex) {
             result = false;
          }
          return result;
       }   

     public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum, String inEmailArr,String inFromMail,String emSubject,String tempName,String amt){
                     String[] sendInvDetails = new String[2];
                     CallableStatement sendInvoiceDetails;
                     try {
                           OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                           sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_invoice_email(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11); end;",
                                                   OADBTransaction.DEFAULT);

                                                                                    sendInvoiceDetails.setString(1, custNum);
                                                                                    sendInvoiceDetails.setString(2, inSO);
                                                                                    sendInvoiceDetails.setString(3, orgId);
                                                                                    sendInvoiceDetails.setString(4, invNum);
                                                                                    sendInvoiceDetails.setString(5, inEmailArr);
                                                                                    sendInvoiceDetails.setString(6, inFromMail);
                                                                                    sendInvoiceDetails.setString(7, emSubject);
                                                                                    sendInvoiceDetails.setString(8, tempName);
																					sendInvoiceDetails.setString(9, amt);
                                                                                    sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
                                                                                    sendInvoiceDetails.registerOutParameter(11, Types.VARCHAR);

                                                                                    sendInvoiceDetails.execute();

                                           sendInvDetails[0] = sendInvoiceDetails.getString(10);
                                           sendInvDetails[1] = sendInvoiceDetails.getString(11);

                                           sendInvoiceDetails.close();

                       } catch (SQLException e) {
                           throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                       }

                                   return sendInvDetails;
         }   
     public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
                  CallableStatement stmtaddTemplate;
                       try {
                              OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.TRUNCATETABLE; end;",
                              OADBTransaction.DEFAULT);
                          
                                
                                  
                              stmtaddTemplate.execute();

                              stmtaddTemplate.close();   
                                             
                         } catch (SQLException e) {
                             throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                         }
                                     
                 
           }

     public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean){
                  
              
                  String resp[] = new String[6];
                  CallableStatement callableStatement;
                       try {
                              OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                              callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_emailtempinvoice(:1,:2,:3,:4,:5,:6); end;",
                              OADBTransaction.DEFAULT);
                                  
                            callableStatement.registerOutParameter(1, Types.VARCHAR);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            callableStatement.registerOutParameter(3, Types.VARCHAR);
                            callableStatement.registerOutParameter(4, Types.VARCHAR);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                             callableStatement.registerOutParameter(6, Types.VARCHAR); 
                             callableStatement.execute();
							 
                             String      o_temp = callableStatement.getString(1);
                             String      o_subject = callableStatement.getString(2);
                             String      o_fromemail = callableStatement.getString(3);
                             String      o_fromname = callableStatement.getString(4);
                             String      errorcode = callableStatement.getString(5);
                             String      errormsg = callableStatement.getString(6);
                             
                             resp[0] = o_temp;
                             resp[1] = o_subject;
                             resp[2] = o_fromemail;
                             resp[3] = o_fromname;
                             resp[4] = errorcode;
                             resp[5] = errormsg;
                                  
                             

                              callableStatement.close();   
                                             
                         } catch (SQLException e) {
                             throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                         }
                  
                  return resp;
              }
     public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
            String errMsg="";
            String arrOutput[] = new String[2]; 
            OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
            CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;", 
                                                             OADBTransaction.DEFAULT);
               try { 
                 callableStatement.registerOutParameter(1, Types.VARCHAR);  
                 callableStatement.registerOutParameter(2, Types.VARCHAR);  
                
               
                 callableStatement.execute();  
               
                 arrOutput[0] = callableStatement.getString(1);  
                 arrOutput[1] = callableStatement.getString(2);  
                  
                 callableStatement.close();                                                  
               }
               catch(Exception e){
               errMsg = e.getMessage();
                   throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
               }   
            return arrOutput;
            
        }
     public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){
              
          
              String resp[] = new String[6];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                        callableStatement.setString(1, p_cust_num);
                        callableStatement.registerOutParameter(2, Types.VARCHAR);
                         callableStatement.execute();
                         String  p_cust_name = callableStatement.getString(2);
                         resp[0] = p_cust_name;  
                         callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              return resp;
          }
  
	public String[] getTransactionPaid(OAPageContext pageContext, OAWebBean webBean,String custNum,String fromDate,String toDate){

              String resp[]  = new String[2];
              CallableStatement callableStatement;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_transaction_paid_inv(:1,:2,:3,:4,:5); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.setString(2, fromDate);
                            callableStatement.setString(3, toDate);
                            callableStatement.registerOutParameter(4, Types.VARCHAR);
                            callableStatement.registerOutParameter(5, Types.VARCHAR);
                            
                         
                            callableStatement.execute();
                           
                            String  errorcode = callableStatement.getString(4);
                            String  errormsg = callableStatement.getString(5);

                      
                         resp[0] = errorcode;
                         resp[1] = errormsg;
                              
                          

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getTransactionPaid Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return resp;
          }
		  public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

                   String resp[]  = new String[2];
                   CallableStatement callableStatement;
                        try {
                               OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                               callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                               OADBTransaction.DEFAULT);
                           
                                 callableStatement.setString(1, custNum);
                                   callableStatement.setString(2, internalId);
                              callableStatement.setString(3, sentId);
                              callableStatement.setString(4, sentCount);
                                 callableStatement.registerOutParameter(5, Types.VARCHAR);
                                 callableStatement.registerOutParameter(6, Types.VARCHAR);
                                 
                              
                                 callableStatement.execute();
                                
                                 String  errorcode = callableStatement.getString(5);
                                 String  errormsg = callableStatement.getString(6);

                           
                              resp[0] = errorcode;
                              resp[1] = errormsg;
                                   
                               

                               callableStatement.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                          }
                   
                   
                   return resp;
               }
      public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                       CallableStatement stmtaddTemplate;
                    String userId = String.valueOf(paramOAPageContext.getUserId());
                            try {
                                   OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                   stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count(:1,:2,:3); end;",
                                   OADBTransaction.DEFAULT);
                               
                                       stmtaddTemplate.setInt(1, pendingreqId);
                                       stmtaddTemplate.setInt(2, count); 
                                       stmtaddTemplate.setString(3, userId); 
                                       
                                       
                                       
                                   stmtaddTemplate.execute();

                                   stmtaddTemplate.close();   
                                                  
                              } catch (SQLException e) {
                                  throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                              }
                                          
                       return true;
                }  
    public void executeVO(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String inCustNum)
		{
					  String query = "select inv_sent_id,cust_num,cust_name,inv_num,inv_org_id,email_to,to_char (email_sent_time, 'YYYY-MM-DD HH12:MI:SS AM') email_sent_time,out_ebiz_url,in_from_mail,in_to_mail,creation_date,created_by,last_update_date,last_updated_by,sent_count,decode (pay_flag, 'Y', 'Paid', 'Not Paid') pay_flag from ebizch_invoice_email_sent where nvl (pay_flag, 'N') != 'Y' and cust_num= '"+inCustNum+"' order by email_sent_time desc";
              try
                 {
                    EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
                    EmaiInvoiceSentVOImpl vo1 = (EmaiInvoiceSentVOImpl)am.findViewObject("EmaiInvoiceSentVO1");
                    vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                    vo1.setQuery(query);
                    vo1.executeQuery();
                 }
              catch (Exception e)
                  {
                    throw new OAException("Updating Query of VO.  Exception: " + e.getMessage(), OAException.ERROR);
                   } 
					
				}
	  public String getInvCount(OAPageContext pageContext, OAWebBean webBean,String invNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.getInvoiceEmailCount(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, invNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getSoCount Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }

 public String[] isValidate(String TemplateLovIn,String EmailSubjectIn,String invNo,String invAmount,String EmailFromIn,String CustomerNo,String EmailToIn) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(TemplateLovIn)) || "".equals(String.valueOf(TemplateLovIn))) {
        retMessage = retMessage + "Template, ";
      }

      if ("null".equals(String.valueOf(EmailSubjectIn)) || "".equals(String.valueOf(EmailSubjectIn))) {
        retMessage = retMessage + "Email Subject, ";
      }

      if ("null".equals(String.valueOf(invNo)) || "".equals(String.valueOf(invNo))) {
        retMessage = retMessage + "Invoice Number, ";
      }

      if ("null".equals(String.valueOf(invAmount)) || "".equals(String.valueOf(invAmount))) {
        retMessage = retMessage + "Invoice Amount, ";
      }
      if ("null".equals(String.valueOf(EmailFromIn)) || "".equals(String.valueOf(EmailFromIn))) {
        retMessage = retMessage + "From Email, ";
      }
      if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
        retMessage = retMessage + "Customer Number, ";
      }

      if ("null".equals(String.valueOf(EmailToIn)) || "".equals(String.valueOf(EmailToIn))) {
        retMessage = retMessage + "To Email ";
      }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invNo + " . ";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Invoice data is validated.";
      }
      return output;
    }
		 /* public void checkEmailAddress(String inEmailArr){
          String[] emailArray = tokenizerStr(inEmailArr);
              
              for(int i = 0; i<emailArray.length; i++) {
                if(isValidEmailAddress(emailArray[i])){
                    
                }
                else{
                    
                    throw new OAException("Email Validation Failed: "+ emailArray[i]+", Please correct email and try again.", OAException.ERROR);
                }
              }
      }
      
      public boolean isValidEmailAddress(String email) {
         boolean result = true;
         try {
            InternetAddress emailAddr = new InternetAddress(email);
            emailAddr.validate();
         } catch (AddressException ex) {
            result = false;
         }
         return result;
      }
	  
	      public String[] tokenizerStr(String inEmailArr){
        String  inputString = inEmailArr.replaceAll("\\s+", "");
        String[] arry = inputString.split(",");
        
        return arry;
    }*/

 }
