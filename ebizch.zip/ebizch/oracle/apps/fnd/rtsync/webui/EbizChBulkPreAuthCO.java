
package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import com.sun.java.util.collections.HashMap;
import java.text.DecimalFormat;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChBulkPreAuthVOImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChBulkPreAuthVORowImpl;
import oracle.apps.fnd.framework.OAViewObject;
import java.sql.CallableStatement;

import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;

import oracle.jbo.Row;
import oracle.jbo.RowSetIterator;

public class EbizChBulkPreAuthCO extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
		private static final DecimalFormat df = new DecimalFormat("0.00");


  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      EbizChRtsyncAMImpl am = 
        (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
        
		String markupValue=GetMarkupValue(pageContext, webBean);
		float markupper = Float.parseFloat("100.0")+Float.parseFloat(markupValue) ;
		am.initEbizChBulkPreAuthVO();
		OAViewObject EbizChPreauthHeaderVO = (OAViewObject)am.findViewObject("EbizChBulkPreAuthVO1");
		/* if (EbizChPreauthHeaderVO  != null)
                         {
                         EbizChPreauthHeaderVO.reset();
                         }
		*//*while ( EbizChPreauthHeaderVO.hasNext())
                {

				    	EbizChBulkPreAuthVORowImpl currow = (EbizChBulkPreAuthVORowImpl)EbizChPreauthHeaderVO.next();
						String vTotAmount=String.valueOf(currow.getAttribute("Amount"));
						float TotAmount = ((Float.parseFloat(vTotAmount)/100)*Float.parseFloat(markupValue))+Float.parseFloat(vTotAmount);
						float Percentage = markupper;
						Double firstAttr = Double.parseDouble(String.valueOf(Percentage));//Double.parseDouble(String.valueOf(currow.getAttribute("Percentage")));
                        
                        currow.setAttribute("ViewAttr5", firstAttr);
						currow.setAttribute("headerPercentage", firstAttr);
						
                        Double SecondAttr = Double.parseDouble(String.valueOf(TotAmount));
						DecimalFormat df = new DecimalFormat("0.00");
                        currow.setAttribute("ProcessedAmount", df.format(SecondAttr));
                        	
						
                        
                }
		*///EbizChPreauthHeaderVO.reset();
    super.processRequest(pageContext, webBean);
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
  int error_count=0;
      int success_count=0;
   
	  if (pageContext.getParameter("AddNewCard")!=null)
	  {
		 HashMap vhashMap = new HashMap(1);
		 vhashMap.put("Type", "BulkPreAuth"); 
		pageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChCreateCreditCardPG&retainAM=Y", null, (byte)0, null, vhashMap, true, "Y", (byte)99);    
		  
	  }
            String lovEvent = pageContext.getParameter(EVENT_PARAM); 
	  if("lovPrepare".equals(lovEvent)) { 
	  
	  String lovInputSourceId = pageContext.getLovInputSourceId();  
		  if("methodLovInput".equals(lovInputSourceId)) {  
		  EbizChRtsyncAMImpl am = 
        (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
		String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
		OARow currRow = (OARow)am.findRowByRef(rowReference);
		String attrValue = (String)currRow.getAttribute("AccountNumber");
		String[] ccLov = creditCardLov(pageContext, webBean, attrValue);
		
				
		if(!ccLov[0].equals("S")){
					  throw new OAException("Credit Card List are not populated. Error Message: "+ccLov[1], OAException.ERROR);    
				  }
		  }
				
	  }
	  
	  String soCount=checkPreauth(pageContext,webBean,pageContext.getParameter("OR_NO"));
	 
	 if (Integer.parseInt(soCount)>0)
	 {
		 error_count++;
	 }
	 if (pageContext.getParameter("ProcessPreauth") != null) {
			
            String methodId = "";
			String headerId = "";
			String holdId = "";
			String Amount = "";
            String viewAttrval = "";
			String preauthStatus = "";
			
            /*String headerId = paramOAPageContext.getParameter("OH_ID");
            String orderNum = paramOAPageContext.getParameter("OR_NO");
            String vPercentageAmount = paramOAPageContext.getParameter("Amount");
			Integer OH_ID = Integer.parseInt(headerId);
			
            String[] getSalesOrderAmt = GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
            String vTotAmount = getSalesOrderAmt[0];
            String vTaxAmount = getSalesOrderAmt[1];
			
            float TotAmount = Float.parseFloat(vTotAmount);
            float vPercentage = Float.parseFloat(vPercentageAmount);
			
        */
             EbizChRtsyncAMImpl am = 
               (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
            EbizChBulkPreAuthVOImpl EbizChBulkPreAuthVOImpl =  am.getEbizChBulkPreAuthVO1();
            EbizChBulkPreAuthVORowImpl EbizChBulkPreAuthVORowImpl = null;
			
            Row[] row =  EbizChBulkPreAuthVOImpl.getFilteredRows("ViewAttr", "Y");
            int rowsLength = row.length;
		     
			
            if (rowsLength > 0)
                for (int i = 0; i < rowsLength; i++) {
                    EbizChBulkPreAuthVORowImpl =  (EbizChBulkPreAuthVORowImpl)row[i];
					
                    methodId = (String)EbizChBulkPreAuthVORowImpl.getAttribute("ViewAttr3");
					headerId = (String)EbizChBulkPreAuthVORowImpl.getAttribute("HeaderId");
					holdId = (String)EbizChBulkPreAuthVORowImpl.getAttribute("holdTypeId");
					Amount = (String)EbizChBulkPreAuthVORowImpl.getAttribute("ProcessedAmount");//("Amount");
					 /*if(true)
					 {
						 
					 throw new OAException(methodId + " - " + headerId + " " +Amount,OAException.ERROR );	 
					 }*/
					
                    if (EbizChBulkPreAuthVORowImpl.getAttribute("ViewAttr4") != null) 
					{
                        viewAttrval = (String)EbizChBulkPreAuthVORowImpl.getAttribute("ViewAttr4");

                    } else {
                        viewAttrval = "";

                    }
					preauthStatus = performPreAuth(pageContext, webBean, headerId, methodId, viewAttrval, Amount);
			
					if (preauthStatus != null) {
						if (preauthStatus.equals("S"))
						{
							success_count++;
							
	
						}
						  else
						  {
							error_count++;	
							String holdrep=applyHold(pageContext, webBean,pageContext.getParameter("OR_NO"),holdId);
							if (holdrep!=null)
							{
								if (holdrep.equals("S"))
								{
									
								}
							}							
						  }
						

					}
                }
          
          
				if(success_count >= 1 && error_count < 1){
				  am.initEbizChBulkPreAuthVO();
					ccclear( pageContext, webBean);				  
                  throw new OAException("The "+ success_count +" Pre-Auth(s) have been processed sucessfully.", OAException.INFORMATION);
				}
				if(success_count < 1 && error_count >= 1){
				   am.initEbizChBulkPreAuthVO();
					ccclear( pageContext, webBean);				  
                  throw new OAException("Error: "+ error_count +"  Pre-Auth(s) have not processed sucessfully." , OAException.ERROR);
				}
				if(success_count >= 1 && error_count >= 1){
					 am.initEbizChBulkPreAuthVO();
					 ccclear( pageContext, webBean);
					throw new OAException("The "+ success_count +"  Pre-Auth(s) have  processed sucessfully but the "+ error_count +"  Pre-Auth(s) have not processed sucessfully.", OAException.WARNING);
				}
              
	 }
      EbizChRtsyncAMImpl am = 
      (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
	  
	 if ("updatePercentage".equals(pageContext.getParameter(EVENT_PARAM))) 
		{

		OAViewObject EbizChPreauthHeaderVO = (OAViewObject)am.findViewObject("EbizChBulkPreAuthVO1");
		String rowReference =  
            pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
			OARow row = (OARow)am.findRowByRef(rowReference);
		String Percentage = String.valueOf(row.getAttribute("ViewAttr5"));
		if (!"".equals(Percentage) || !"null".equals(Percentage)) {
			 float vPercentage = Float.parseFloat(Percentage);
			 String TotAmount=String.valueOf(row.getAttribute("Amount"));
			 float PercentageAmount = (Float.parseFloat(TotAmount) / 100) * vPercentage;
					
             PercentageAmount = Float.parseFloat(df.format(PercentageAmount));
			 
			 row.setAttribute("ProcessedAmount", PercentageAmount);
			 
			 }
		
		}
		
		/* if ("updatePercentage2".equals(pageContext.getParameter(EVENT_PARAM))) 
		{

		OAViewObject EbizChPreauthHeaderVO = (OAViewObject)am.findViewObject("EbizChBulkPreAuthVO1");
		 if (EbizChPreauthHeaderVO  != null)
                         {
                         EbizChPreauthHeaderVO.reset();
                         }
		while ( EbizChPreauthHeaderVO.hasNext())
                {

			  	EbizChBulkPreAuthVORowImpl row = (EbizChBulkPreAuthVORowImpl)EbizChPreauthHeaderVO.next();
			 String Percentage = String.valueOf(row.getAttribute("headerPercentage"));
			 if (!"".equals(Percentage) || !"null".equals(Percentage)) {
			 float vPercentage = Float.parseFloat(Percentage);
			 String TotAmount=String.valueOf(row.getAttribute("Amount"));
			 float PercentageAmount = (Float.parseFloat(TotAmount) / 100) * vPercentage;
					
             PercentageAmount = Float.parseFloat(df.format(PercentageAmount));
			 row.setAttribute("ViewAttr5", Percentage);
			 row.setAttribute("ProcessedAmount", PercentageAmount);
			 
			 }
		}

		}*/
		
		 if ("updateAmount".equals(pageContext.getParameter(EVENT_PARAM))) {
			OAViewObject EbizChPreauthHeaderVO = (OAViewObject)am.findViewObject("EbizChBulkPreAuthVO1");
		 if (EbizChPreauthHeaderVO  != null)
                         {
                         EbizChPreauthHeaderVO.reset();
                         }
		while ( EbizChPreauthHeaderVO.hasNext())
                {
					EbizChBulkPreAuthVORowImpl row = (EbizChBulkPreAuthVORowImpl)EbizChPreauthHeaderVO.next();
            String MarkupAmount = 
                String.valueOf(row.getAttribute("ProcessedAmount"));
				
            if (!"".equals(MarkupAmount) || !"null".equals(MarkupAmount)) {
				
				float vMarkupAmount = Float.parseFloat(MarkupAmount);
				String TotAmount = 
                String.valueOf(row.getAttribute("Amount"));
				
				float Percentage = (vMarkupAmount / Float.parseFloat(TotAmount)) * 100;
                Percentage = Math.round((vMarkupAmount / Float.parseFloat(TotAmount)) * 100);
				row.setAttribute("ViewAttr5", Percentage);
				
		 }
		 }
		 }
    super.processFormRequest(pageContext, webBean);
  }
  
  public void ccclear(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean)
	{
		 EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
		EbizChBulkPreAuthVOImpl EbizChBulkPreAuthVOImpl =  ebizChRtsyncAMImpl.getEbizChBulkPreAuthVO1();
            EbizChBulkPreAuthVORowImpl EbizChBulkPreAuthVORowImpl = null;
			
            Row[] row =  EbizChBulkPreAuthVOImpl.getFilteredRows("ViewAttr", "Y");
            int rowsLength = row.length;
			
		if (rowsLength > 0)
                for (int i = 0; i < rowsLength; i++) {
                    EbizChBulkPreAuthVORowImpl =  (EbizChBulkPreAuthVORowImpl)row[i];
					EbizChBulkPreAuthVORowImpl.setAttribute("ViewAttr3",null);
                  

                }
		
	}
	
	
   public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, 
								 Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }

    public String performPreAuth(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, String orderNum, 
                                 String methodId, String cvv, String vPercentageAmount) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.create_preauth_markup(:1,:2,:3,:4,:5); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(2, orderNum);
            callableStatement.setString(3, methodId);
            callableStatement.setString(4, cvv);
			callableStatement.setString(5, vPercentageAmount);
            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String str = callableStatement.getString(1);
            callableStatement.close();
            return str;

        } catch (SQLException sQLException) {
            throw new OAException("Exception in Method named performPreAuth. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }

    }


    public String[] creditCardLov(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String inCustNum)
		 {
        String[] arrayOfString = new String[2];
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, inCustNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();
            arrayOfString[0] = callableStatement.getString(2);
            arrayOfString[1] = callableStatement.getString(3);
            callableStatement.close();
            return arrayOfString;

        } catch (SQLException sQLException) {
            throw new OAException("Exception in Method named creditCardLov. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }

    }
	
	public String checkPreauth(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String soNum)
		 {
        String soCount = "";
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.ebizch_check_preauth(:1,:2); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, soNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.execute();
            soCount = callableStatement.getString(2);
            callableStatement.close();
            

        } catch (SQLException sQLException) {
            throw new OAException("Exception in method named checkPreauth. Error Message: " + sQLException.getMessage(), OAException.ERROR);

        }
			return soCount;
    }
	 public String GetMarkupValue(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String markupValue="";
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.get_markup_value(:1); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();

            markupValue = callableStatement.getString(1);

            callableStatement.close();
        } catch (SQLException e) {
			
            throw new OAException("Error in GetMarkupValue, Error Message:" + e.getMessage(), OAException.INFORMATION);
        }
        return markupValue;
    }
	public String applyHold(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean,String inSo,String holdId) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String errormsg="";
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.so_apply_hold(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
			callableStatement.setString(1, inSo);
			callableStatement.setString(2, holdId);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            errormsg = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
			
            throw new OAException("Error in applyHold, Error Message:" + e.getMessage(), OAException.INFORMATION);
        }
        return errormsg;
    }
	
}
