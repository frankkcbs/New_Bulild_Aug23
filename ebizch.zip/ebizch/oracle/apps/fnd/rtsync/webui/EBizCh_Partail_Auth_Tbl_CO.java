package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCustCcVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.PartialRenderingVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import java.text.DecimalFormat;

import java.util.HashMap;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EBizCh_Partail_Auth_Tbl_CO extends OAControllerImpl {

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        ebizChRtsyncAMImpl.invokeMethod("initPartialRenderingVO");
        String str = paramOAPageContext.getParameter("CUST_NO");
        String OrderNo = paramOAPageContext.getParameter("OR_NO");
       

        OAMessageTextInputBean textBeanSoNumber = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SoNumber");
        OAMessageTextInputBean textBeanCustomerNo = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerNo");
        OAMessageTextInputBean textBeanCustomerName = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerName");

        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCustCcVO1");
        oAViewObject.setWhereClause("customer_no=" + str);
        oAViewObject.executeQuery();

     
     
        String str3 = paramOAPageContext.getParameter("OH_ID");
        Integer OH_ID = Integer.parseInt(str3);
        String[] getSalesOrderAmt = 
            GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
        String vTotAmount = getSalesOrderAmt[0];
        String vTaxAmount = getSalesOrderAmt[1];
        


        OAViewObject vo = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("PartialRenderingVO1");
        OARow row = (OARow)vo.getCurrentRow();
        Double a = 100.0 ;
        float TotAmount = Float.parseFloat(vTotAmount);
        float Percentage = Float.parseFloat("100.0");
      

        OAViewObject PartialRenderingVO = (OAViewObject)ebizChRtsyncAMImpl.findViewObject("PartialRenderingVO1");

                 if (PartialRenderingVO  != null)
                         {
                         PartialRenderingVO.reset();
                         }
               
                while ( PartialRenderingVO.hasNext())
                {

                PartialRenderingVORowImpl currow = (PartialRenderingVORowImpl)PartialRenderingVO.next();
                Double firstAttr = 100.0;//Double.parseDouble(currow.getAttribute("Percentage").toString());
                        currow.setAttribute("Percentage", firstAttr);
                        Double SecondAttr = Double.parseDouble(vTotAmount);
                        currow.setAttribute("PartialAmount", SecondAttr);
                        
                        currow.setAttribute("SoNumber", OrderNo);
						String getCustname[] =new String[1];
						getCustname = getCustName(paramOAPageContext, paramOAWebBean,str);
						String CustomerName = getCustname[0];
                        
                     
                        currow.setAttribute("CustName", CustomerName);
                        
                        currow.setAttribute("CustNo", str);
                        
                }


    }


    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        OAViewObject vo = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("PartialRenderingVO1");
        OARow row = (OARow)vo.getCurrentRow();


        if ("updatePercentage".equals(paramOAPageContext.getParameter(EVENT_PARAM))) {
            String str3 = paramOAPageContext.getParameter("OH_ID");
            String Percentage = String.valueOf(row.getAttribute("Percentage"));
            if (!"".equals(Percentage) || !"null".equals(Percentage)) {
                Integer OH_ID = Integer.parseInt(str3);
                String[] getSalesOrderAmt = 
                    GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
                String vTotAmount = getSalesOrderAmt[0];
                String vTaxAmount = getSalesOrderAmt[1];
                float vPercentage = Float.parseFloat(Percentage);
                float TotAmount = Float.parseFloat(vTotAmount);
                float PercentageAmount = (TotAmount / 100) * vPercentage;
                PercentageAmount = Math.round(PercentageAmount);

                
                if (PercentageAmount > TotAmount) {
					 row.setAttribute("PartialAmount", PercentageAmount);
                    throw new OAException("Amount is greater then or equal to sales order amount.", 
                                          OAException.WARNING);
                } else {
                    row.setAttribute("PartialAmount", PercentageAmount);
                    HashMap param = new HashMap(1);
                    param.put("vPercentageAmount", 
                              String.valueOf(PercentageAmount));
                    String vPercentageAmount = 
                        paramOAPageContext.getParameter("vPercentageAmount");

                 
                }
            }
        }


        if ("updateAmount".equals(paramOAPageContext.getParameter(EVENT_PARAM))) {

            String str3 = paramOAPageContext.getParameter("OH_ID");

            String PartialAmount = 
                String.valueOf(row.getAttribute("PartialAmount"));
            if (!"".equals(PartialAmount) || !"null".equals(PartialAmount)) {
                Integer OH_ID = Integer.parseInt(str3);
                String[] getSalesOrderAmt = 
                    GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
                String vTotAmount = getSalesOrderAmt[0];
                String vTaxAmount = getSalesOrderAmt[1];
                float vPartialAmount = Float.parseFloat(PartialAmount);
                float TotAmount = Float.parseFloat(vTotAmount);
                float Percentage = (vPartialAmount / TotAmount) * 100;
                             Percentage = Math.round((vPartialAmount / TotAmount) * 100);
                

                                

                if (vPartialAmount > TotAmount) {
					 row.setAttribute("Percentage", Percentage);
                    throw new OAException("Amount is greater then or equal to sales order amount.", 
                                          OAException.WARNING);
                } else {

                    row.setAttribute("Percentage", Percentage);

                  
                }

            }
        }


        /*   if (paramOAPageContext.getParameter("preAuthBtn1") != null) {
            String str1 = "";
            String str2 = "";
            String str3 = paramOAPageContext.getParameter("OH_ID");
            String str4 = paramOAPageContext.getParameter("OR_NO");
            String str5 = "";
            String PartialAmount =
            row.getAttribute("PartialAmount").toString();
            float vPartialAmount = Float.parseFloat(PartialAmount);

            String payMethodId = "";

            String OH_ID = paramOAPageContext.getParameter("OH_ID");

            String OR_NO = paramOAPageContext.getParameter("OR_NO");

            String preAuthResp = "";

            EbizChRtsyncAMImpl am =
                (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
            EbizChRtCustCcVOImpl CustCcListVo = am.getEbizChRtCustCcVO1();
            EbizChRtCustCcVORowImpl CustCcListRowVo = null;


            Row rows[] = CustCcListVo.getFilteredRows("ViewAttr", "Y");
            int rowsLength = rows.length;

            if (rowsLength > 0) {
                for (int i = 0; i < rowsLength; i++) {
                    CustCcListRowVo = (EbizChRtCustCcVORowImpl)rows[i];

                    payMethodId =
                            (String)CustCcListRowVo.getAttribute("MethodId");
                    //String CustNoString = CustNo.toString();

                }
            }


            if (true) {
                throw new OAException("str1" + str1, OAException.INFORMATION);
            }


            // str5 = performPreAuth(paramOAPageContext, paramOAWebBean, str3, str1, str2);
            str5 =
performPreAuth(paramOAPageContext, paramOAWebBean, str3, str1, str2,
               vPartialAmount);

            if (str5 != null) {
                if (str5.equals("S"))
                    throw new OAException("Partial Pre-Auth is completed successfully for this SalesOrder : " +
                                          str4, (byte)2);
                throw new OAException("SalesOrder is not Pre-Authorized for this SalesOrder : " +
                                      str4 + " preAuthResp:" + str5,
                                      OAException.INFORMATION);

            }
            throw new OAException("Partial Pre-Auth is completed successfully for this SalesOrder : " +
                                  str4, OAException.INFORMATION);

        }
*/

    }


    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }

    public String performPreAuth(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, String paramString1, 
                                 String paramString2, String paramString3, 
                                 float PartialAmounts) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKG.CREATE_PARTIAL_PREAUTH(:1,:2,:3,:4,:5); end;", 
                                                        -1);
        try {
            callableStatement.setString(2, paramString1);
            callableStatement.setString(3, paramString2);
            callableStatement.setString(4, paramString3);
            callableStatement.setFloat(5, PartialAmounts);
            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();
            String str = callableStatement.getString(1);
            callableStatement.close();
            return str;

        } catch (SQLException sQLException) {
            throw new OAException("performPreAuth: " + 
                                  sQLException.getMessage(), (byte)2);

        }

    }


    public String[] creditCardLov(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String paramString) {
        String[] arrayOfString = new String[2];
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;", 
                                                        -1);
        try {
            callableStatement.setString(1, paramString);
            callableStatement.registerOutParameter(2, 12);
            callableStatement.registerOutParameter(3, 12);
            callableStatement.execute();
            arrayOfString[0] = callableStatement.getString(2);
            arrayOfString[1] = callableStatement.getString(3);
            callableStatement.close();
            return arrayOfString;

        } catch (SQLException sQLException) {
            throw new OAException("creditCardLov: " + 
                                  sQLException.getMessage(), (byte)2);

        }

    }
	    public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){
          
      
          String resp[] = new String[6];
          CallableStatement callableStatement;
               try {
                      OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                      callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                      OADBTransaction.DEFAULT);
                    callableStatement.setString(1, p_cust_num);
                    callableStatement.registerOutParameter(2, Types.VARCHAR);
                     callableStatement.execute();
                     String  p_cust_name = callableStatement.getString(2);
                     resp[0] = p_cust_name;  
                     callableStatement.close();   
                                     
                 } catch (SQLException e) {
                     throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                 }
          
          return resp;
      }

}
