package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;
import com.sun.java.util.collections.HashMap;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EbizChargePrepayDetailCO extends OAControllerImpl {

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
		
        String custNum = paramOAPageContext.getParameter("CUST_NO");
		String str4 = paramOAPageContext.getParameter("OR_NO");
		String str3 = paramOAPageContext.getParameter("OH_ID");
		
		
        String[] arrayOfString = creditCardLov(paramOAPageContext, paramOAWebBean, custNum);
			
        if (!arrayOfString[0].equals("S"))
		{
			throw new OAException("CreditCardLov not populated.",OAException.ERROR);	
		}
            
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCcInfoVO1");
        oAViewObject.setWhereClause("customer_no=" + custNum);
        oAViewObject.executeQuery();
		
		String checkpay=checkPayment(paramOAPageContext, paramOAWebBean,str4);
		if("Y".equals(checkpay))
		{
			throw new OAException("You are not allowed to do the pre-payment because pre-auth is already done against this sales order.",OAException.ERROR);
		}
		
		   }
    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {


	    EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
	        (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
	     String custNum = paramOAPageContext.getParameter("CUST_NO");
		 
			HashMap vhashMap = new HashMap(5);
			vhashMap.put("CustomerNumber", custNum);
			vhashMap.put("CUST_NO", paramOAPageContext.getParameter("CUST_NO"));
			vhashMap.put("OR_NO", paramOAPageContext.getParameter("OR_NO"));
			vhashMap.put("OH_ID", paramOAPageContext.getParameter("OH_ID"));
			vhashMap.put("PaymentFlag","Y");
			  

	
	   if (paramOAPageContext.getParameter("goBtn1")!=null)
		{
	   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreditCardPG&retainAM=Y", null, (byte)0, null, vhashMap, true, "Y", (byte)99);  
		
		}
	 
        if (paramOAPageContext.getParameter("prepayBtn") != null) {
			
            String methodId = "";
            String viewAttrval = "";
			//String[] preauthStatus = "";
			
            String headerId = paramOAPageContext.getParameter("OH_ID");
            String orderNum = paramOAPageContext.getParameter("OR_NO");
            String vPercentageAmount = paramOAPageContext.getParameter("Amount");
			Integer OH_ID = Integer.parseInt(headerId);
			
			String checkpay=checkPayment(paramOAPageContext, paramOAWebBean,orderNum);
			
			if("Y".equals(checkpay))
			{
				throw new OAException("You are not allowed to do the pre-payment because pre-auth is already done against this sales order.",OAException.ERROR);
			}
		
		
            String[] getSalesOrderAmt = GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
            String vTotAmount = getSalesOrderAmt[0];
            String vTaxAmount = getSalesOrderAmt[1];
			
            float TotAmount = Float.parseFloat(vTotAmount);
            float vPercentage = Float.parseFloat(vPercentageAmount);
			
        

            EbizChRtCcInfoVOImpl EbizChRtCcInfoVOImpl =  ebizChRtsyncAMImpl.getEbizChRtCcInfoVO1();
            EbizChRtCcInfoVORowImpl EbizChRtCcInfoVORowImpl = null;
			
            Row[] row =  EbizChRtCcInfoVOImpl.getFilteredRows("ViewAttr", "Y");
            int rowsLength = row.length;
		     
			
            if (rowsLength > 0)
                for (int i = 0; i < rowsLength; i++) {
                    EbizChRtCcInfoVORowImpl =  (EbizChRtCcInfoVORowImpl)row[i];
					
                    methodId = (String)EbizChRtCcInfoVORowImpl.getAttribute("MethodId");
					
                    if (EbizChRtCcInfoVORowImpl.getAttribute("ViewAttr1") != null) 
					{
                        viewAttrval = (String)EbizChRtCcInfoVORowImpl.getAttribute("ViewAttr1");

                    } else {
                        viewAttrval = "";

                    }

                }
				String prePaymentCount=getPrePayStatus(paramOAPageContext, paramOAWebBean, orderNum);

			   if ("Y".equals(prePaymentCount))
			   {
				   throw new OAException ("Pre-Payment already done against your SalesOrder : " + orderNum ,OAException.ERROR);
				   
			   }		
		   
            String gwToken = getGwTokenNo(paramOAPageContext, paramOAWebBean, methodId,custNum);
		   
            String[] prepayStatus = runCustomerTransaction(paramOAPageContext, paramOAWebBean, orderNum,vPercentageAmount,gwToken,methodId,custNum,viewAttrval);
			
			
            if (prepayStatus[0] != null) {
                if (prepayStatus[0].equals("S"))
				{
				 throw new OAException("Pre-Payment is completed successfully for this SalesOrder : " + 
										orderNum, OAException.INFORMATION);	
					
				}
                  else
				  {
					throw new OAException("Pre-Payment is not done for this SalesOrder : " + 
                                      orderNum + " Prepayment Response:" + prepayStatus[1], OAException.ERROR);  
					  
				  }
                

            }

        super.processFormRequest(paramOAPageContext, paramOAWebBean);
        
								   }}

    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, 
								 Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_PREAUTH_PKg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }

public String[] runCustomerTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String invNumb,String inamt,String gwToken,String payMethodId,String CustAccNoString,String cvv){
                 String[] runTransDetails = new String[3]; 
                 CallableStatement stmtTransAddDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       stmtTransAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.prepay_customer_transaction(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       stmtTransAddDetails.setString(1, invNumb);
									   stmtTransAddDetails.setString(2, inamt);
									   stmtTransAddDetails.setString(3, gwToken);
									   stmtTransAddDetails.setString(4, payMethodId);
									   stmtTransAddDetails.setString(5, CustAccNoString);
									    stmtTransAddDetails.setString(6, cvv);
                                       stmtTransAddDetails.registerOutParameter(7, Types.VARCHAR);
                                       stmtTransAddDetails.registerOutParameter(8, Types.VARCHAR);
                                       stmtTransAddDetails.registerOutParameter(9, Types.VARCHAR);
									   
                                       stmtTransAddDetails.execute();
                                       
                                       runTransDetails[0] = stmtTransAddDetails.getString(7);
                                       runTransDetails[1] = stmtTransAddDetails.getString(8);
                                       runTransDetails[2] = stmtTransAddDetails.getString(9);
									   
                                       stmtTransAddDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While Capturing the Customer Transaction Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return runTransDetails;
     } 
	 
	  public String getGwTokenNo(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String PayMethodId, String custNo){
                 String gwTokenNo = ""; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.get_gw_token_no(:1,:2,:3); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      sendInvoiceDetails.setString(1, custNo);
                                      sendInvoiceDetails.setString(2, PayMethodId);
                                       sendInvoiceDetails.registerOutParameter(3, Types.VARCHAR);
									   
                                      sendInvoiceDetails.execute();
                                       
                                       gwTokenNo = sendInvoiceDetails.getString(3);
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the gateway token no Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return gwTokenNo;
     } 
	   public String[] creditCardLov(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean, 
                                  String inCustNum)
		 {
        String[] arrayOfString = new String[2];
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            callableStatement.setString(1, inCustNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();
            arrayOfString[0] = callableStatement.getString(2);
            arrayOfString[1] = callableStatement.getString(3);
            callableStatement.close();
            return arrayOfString;

        } catch (SQLException sQLException) {
            throw new OAException("Exception in Method named creditCardLov. Error Message: " + sQLException.getMessage(), OAException.ERROR);


        }

    }
	
	 public String getPrePayStatus(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String ordNum){
                 String PrePayStatus = ""; 
                 CallableStatement prepayDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       prepayDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.get_prepay_status(:1,:2); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      prepayDetails.setString(1, ordNum);
                                       prepayDetails.registerOutParameter(2, Types.VARCHAR);
									   
                                      prepayDetails.execute();
                                       
                                       PrePayStatus = prepayDetails.getString(2);
									   
                                       prepayDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the prepayment status Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return PrePayStatus;
     }
	 public String checkPayment(OAPageContext paramOAPageContext, 
                                  OAWebBean paramOAWebBean,String inSO) {
    String check = "";
	 OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
			CallableStatement cs = 
            oADBTransactionImpl.createCallableStatement("BEGIN :1 := ebizch_wlt_cc_preauth_pkg.check_payment(:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
     try {
        cs.registerOutParameter(1, Types.VARCHAR);
        cs.setString(2, inSO);
		 cs.setString(3, "Pre-Payment");
        cs.execute();
        check = cs.getString(1);
        cs.close();
    } catch (SQLException sQLException) {
       throw new OAException("Exception found in method named checkPayment"+ sQLException.getMessage(),OAException.ERROR);
    }
    return check;
}

}
