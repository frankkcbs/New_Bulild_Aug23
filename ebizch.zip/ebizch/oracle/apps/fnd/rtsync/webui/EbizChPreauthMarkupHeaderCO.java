package ebizch.oracle.apps.fnd.rtsync.webui;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVOImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtCcInfoVORowImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;
import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChPreauthMarkupHeaderVORowImpl;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import java.text.DecimalFormat;

import java.util.HashMap;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OAViewObject;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

import oracle.jbo.Row;

public class EbizChPreauthMarkupHeaderCO extends OAControllerImpl {

    public void processRequest(OAPageContext paramOAPageContext, 
                               OAWebBean paramOAWebBean) {
        super.processRequest(paramOAPageContext, paramOAWebBean);
		
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
        ebizChRtsyncAMImpl.initEbizChPreauthMarkupHeaderVO();
		
        String custNum = paramOAPageContext.getParameter("CUST_NO");
        String OrderNo = paramOAPageContext.getParameter("OR_NO");
        String headerId = paramOAPageContext.getParameter("OH_ID");
        Integer OH_ID = Integer.parseInt(headerId);
        
		 String[] getSalesOrderAmt =  GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
			
        String vTotAmount = getSalesOrderAmt[0];
        String vTaxAmount = getSalesOrderAmt[1];
		
        OAMessageTextInputBean textBeanSoNumber = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SoNumber");
			
        OAMessageTextInputBean textBeanCustomerNo = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerNo");
			
        OAMessageTextInputBean textBeanCustomerName = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("CustomerName");
			
        OAMessageTextInputBean textBeanSoAmount = 
            (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("SoAmount");
			
        OAViewObject oAViewObject = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChRtCcInfoVO1");
        oAViewObject.setWhereClause("customer_no=" + custNum);
        oAViewObject.executeQuery();
		      
		 
		String markupValue=GetMarkupValue(paramOAPageContext, paramOAWebBean);
        
	//vTotAmount = ((Float.parseFloat(vTotAmount)/100)*Float.parseFloat(markupValue))+vTotAmount;
		
        OAViewObject vo = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChPreauthMarkupHeaderVO1");
        OARow row = (OARow)vo.getCurrentRow();
		
        float markupper = Float.parseFloat("100.0")+Float.parseFloat(markupValue) ;
        float TotAmount = ((Float.parseFloat(vTotAmount)/100)*Float.parseFloat(markupValue))+Float.parseFloat(vTotAmount);//Float.parseFloat(vTotAmount);
        //float Percentage = Float.parseFloat("100.0");
        float Percentage = markupper;

        OAViewObject EbizChPreauthMarkupHeaderVO = (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChPreauthMarkupHeaderVO1");

                 if (EbizChPreauthMarkupHeaderVO  != null)
                         {
                         EbizChPreauthMarkupHeaderVO.reset();
                         }
               
                while ( EbizChPreauthMarkupHeaderVO.hasNext())
                {

					EbizChPreauthMarkupHeaderVORowImpl currow = (EbizChPreauthMarkupHeaderVORowImpl)EbizChPreauthMarkupHeaderVO.next();
						Double firstAttr = Double.parseDouble(String.valueOf(Percentage));//Double.parseDouble(String.valueOf(currow.getAttribute("Percentage")));
                        
                        currow.setAttribute("Percentage", firstAttr);
						
                        Double SecondAttr = Double.parseDouble(String.valueOf(TotAmount));
						
                        currow.setAttribute("MarkupAmount", SecondAttr);
                        
                        currow.setAttribute("SoNumber", OrderNo);
						
                        String CustomerName = getCustName(paramOAPageContext, paramOAWebBean, custNum);
                     
                        currow.setAttribute("CustName", CustomerName);
                        
                        currow.setAttribute("CustNo", custNum);
						
						currow.setAttribute("SoAmount", vTotAmount);
						
						currow.setAttribute("MarkupPercentage", markupValue);
						
						
                        
                }
				   
						

    }


    public void processFormRequest(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
		
        EbizChRtsyncAMImpl ebizChRtsyncAMImpl = 
            (EbizChRtsyncAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
			
        OAViewObject vo = 
            (OAViewObject)ebizChRtsyncAMImpl.findViewObject("EbizChPreauthMarkupHeaderVO1");
        OARow row = (OARow)vo.getCurrentRow();

        if ("updateMarkupPercentage".equals(paramOAPageContext.getParameter(EVENT_PARAM))) 
		{
			String MarkupPercentage = String.valueOf(row.getAttribute("MarkupPercentage"));
			if (Float.parseFloat(MarkupPercentage)<0)
			{
				throw new OAException("Markup Value should not be less than zero.Please enter value greater than zero.",OAException.ERROR);
				
			}
			else
			{
			float markupper = Float.parseFloat("100.0")+Float.parseFloat(MarkupPercentage) ;
			row.setAttribute("Percentage", markupper);
			
			String headerId = paramOAPageContext.getParameter("OH_ID");
			Integer OH_ID = Integer.parseInt(headerId);
			
			String[] getSalesOrderAmt = GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
					
            String vTotAmount = getSalesOrderAmt[0];
            String vTaxAmount = getSalesOrderAmt[1];
			float TotAmount = Float.parseFloat(vTotAmount);
			float PercentageAmount = (TotAmount / 100) * markupper;
			
			row.setAttribute("MarkupAmount", Math.round(PercentageAmount));
			
			}
			
			
		}
        if ("updatePercentage".equals(paramOAPageContext.getParameter(EVENT_PARAM))) 
		{
            String headerId = paramOAPageContext.getParameter("OH_ID");
            String Percentage = String.valueOf(row.getAttribute("Percentage"));
			
            if (!"".equals(Percentage) || !"null".equals(Percentage)) {
				
                Integer OH_ID = Integer.parseInt(headerId);
                String[] getSalesOrderAmt = 
                    GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
					
                String vTotAmount = getSalesOrderAmt[0];
                String vTaxAmount = getSalesOrderAmt[1];
                float vPercentage = Float.parseFloat(Percentage);
                float TotAmount = Float.parseFloat(vTotAmount);
                float PercentageAmount = (TotAmount / 100) * vPercentage;
				
                PercentageAmount = Math.round(PercentageAmount);

                
                if (PercentageAmount < TotAmount) {
				    row.setAttribute("MarkupAmount", PercentageAmount);
                   // throw new OAException("Amount is greater then or equal to sales order amount.",  OAException.WARNING);
				    throw new OAException("Percentage should be greater then or equal to 100%.",  OAException.ERROR);
                } else {
                    row.setAttribute("MarkupAmount", PercentageAmount);
                    HashMap param = new HashMap(1);
                    param.put("vPercentageAmount", 
                              String.valueOf(PercentageAmount));
                    String vPercentageAmount = 
                        paramOAPageContext.getParameter("vPercentageAmount");
						
				    float markupper = Float.parseFloat(Percentage) - Float.parseFloat("100.0") ;
                    row.setAttribute("MarkupPercentage", Math.round(markupper));
                 
                }
            }
        }


        if ("updateAmount".equals(paramOAPageContext.getParameter(EVENT_PARAM))) {

            String headerId = paramOAPageContext.getParameter("OH_ID");

            String MarkupAmount = 
                String.valueOf(row.getAttribute("MarkupAmount"));
				
            if (!"".equals(MarkupAmount) || !"null".equals(MarkupAmount)) {
				
                Integer OH_ID = Integer.parseInt(headerId);
				
                String[] getSalesOrderAmt = GetTotAmount(paramOAPageContext, paramOAWebBean, OH_ID);
					
                String vTotAmount = getSalesOrderAmt[0];
                String vTaxAmount = getSalesOrderAmt[1];
                float vMarkupAmount = Float.parseFloat(MarkupAmount);
                float TotAmount = Float.parseFloat(vTotAmount);
                float Percentage = (vMarkupAmount / TotAmount) * 100;
                Percentage = Math.round((vMarkupAmount / TotAmount) * 100);
                

                                

                if (vMarkupAmount < TotAmount) {
					row.setAttribute("Percentage", Percentage);
                    throw new OAException("Entered amount is not less than sales order amount.Please Check!", 
                                          OAException.ERROR);
                } else {

                    row.setAttribute("Percentage", Percentage);
                    float markupper = Percentage - Float.parseFloat("100.0") ;
                    row.setAttribute("MarkupPercentage", markupper);
                  
                }

            }
        }

    }


    public String[] GetTotAmount(OAPageContext paramOAPageContext, 
                                 OAWebBean paramOAWebBean, Integer HeaderID) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String[] getSaleOrderAmount = new String[2];
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.get_tot_amt(:1,:2,:3); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.setInt(1, HeaderID);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();

            getSaleOrderAmount[0] = callableStatement.getString(2);
            getSaleOrderAmount[1] = callableStatement.getString(3);

            callableStatement.close();
        } catch (SQLException e) {
            throw new OAException("Error in GetTotAmount, Error Message:" + 
                                  e.getMessage(), OAException.INFORMATION);
        }
        return getSaleOrderAmount;
    }
	
    public String GetMarkupValue(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String markupValue="";
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.get_markup_value(:1); end;", 
                                                        OADBTransaction.DEFAULT);
        try {

            callableStatement.registerOutParameter(1, Types.VARCHAR);
            callableStatement.execute();

            markupValue = callableStatement.getString(1);

            callableStatement.close();
        } catch (SQLException e) {
			
            throw new OAException("Error in GetMarkupValue, Error Message:" + e.getMessage(), OAException.INFORMATION);
        }
        return markupValue;
    }
	
	  public String getCustName(OAPageContext paramOAPageContext, 
                                   OAWebBean paramOAWebBean,String custNum) {
        OADBTransactionImpl oADBTransactionImpl = 
            (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        String custName="";
        CallableStatement callableStatement = 
            oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_cc_preauth_pkg.get_cust_name(:1,:2); end;", 
                                                        OADBTransaction.DEFAULT);
        try {
            
            callableStatement.setString(1, custNum);
            callableStatement.registerOutParameter(2, Types.VARCHAR);
            callableStatement.execute();

            custName = callableStatement.getString(2);

            callableStatement.close();
        } catch (SQLException e) {
			
            throw new OAException("Error in getCustName, Error Message:" + e.getMessage(), OAException.INFORMATION);
        }
        return custName;
    }
	

}
