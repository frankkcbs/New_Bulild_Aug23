/*===========================================================================+
 |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
 |                         All rights reserved.                              |
 +===========================================================================+
 |  HISTORY                                                                  |
 +===========================================================================*/
package ebizch.oracle.apps.fnd.rtsync.webui;

import oracle.jbo.domain.Number;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import ebizch.oracle.apps.fnd.rtsync.server.EmaiInvoiceSentVOImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EbizChRtsyncAMImpl;

import ebizch.oracle.apps.fnd.rtsync.server.EmaiInvoiceSentVORowImpl;

import java.sql.CallableStatement;

import java.sql.SQLException;

import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;

import oracle.jbo.Row;


public class EbizchWltInvoiceEmailSentDetails extends OAControllerImpl
{
  public static final String RCS_ID="$Header$";
  public static final boolean RCS_ID_RECORDED =
        VersionInfo.recordClassVersion(RCS_ID, "%packagename%");


  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	
	      EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
			//am.initEmaiInvoiceSentVO(); 
			  String inCustNum = pageContext.getParameter("CUST_NO");
		  String query = "select inv_sent_id,cust_num,cust_name,inv_num,inv_org_id,email_to,to_char (email_sent_time, 'YYYY-MM-DD HH12:MI:SS AM') email_sent_time,out_ebiz_url,in_from_mail,in_to_mail,creation_date,created_by,last_update_date,last_updated_by,sent_count,decode (pay_flag, 'Y', 'Paid', 'Not Paid') pay_flag from ebizch_invoice_email_sent where nvl (pay_flag, 'N') != 'Y' and cust_num= '"+inCustNum+"' order by email_sent_time desc";
              try
                 {
		     		//EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
                    EmaiInvoiceSentVOImpl vo1 = (EmaiInvoiceSentVOImpl)am.findViewObject("EmaiInvoiceSentVO1");
                    vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                    vo1.setQuery(query);
                    vo1.executeQuery();
                 }
              catch (Exception e)
                  {
                    throw new OAException("Updating Query of VO.  Exception: " + e.getMessage(), OAException.ERROR);
                   } 			
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
	  
	  if (pageContext.getParameter("Send") != null)
	  {
		  String inCustNum = pageContext.getParameter("CUST_NO");
		  String query = "select inv_sent_id,cust_num,cust_name,inv_num,inv_org_id,email_to,to_char (email_sent_time, 'YYYY-MM-DD HH12:MI:SS AM') email_sent_time,out_ebiz_url,in_from_mail,in_to_mail,creation_date,created_by,last_update_date,last_updated_by,sent_count,decode (pay_flag, 'Y', 'Paid', 'Not Paid') pay_flag from ebizch_invoice_email_sent where nvl (pay_flag, 'N') != 'Y' and cust_num= '"+inCustNum+"' order by email_sent_time desc";
              try
                 {
		     		EbizChRtsyncAMImpl am = (EbizChRtsyncAMImpl)pageContext.getApplicationModule(webBean);
                    EmaiInvoiceSentVOImpl vo1 = (EmaiInvoiceSentVOImpl)am.findViewObject("EmaiInvoiceSentVO1");
                    vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                    vo1.setQuery(query);
                    vo1.executeQuery();
                 }
              catch (Exception e)
                  {
                    throw new OAException("Updating Query of VO.  Exception: " + e.getMessage(), OAException.ERROR);
                   } 	
		  
		  
	  }
    if (pageContext.getParameter("ResendReqBtn") != null) {

              EbizChRtsyncAMImpl am1 = (EbizChRtsyncAMImpl) pageContext.getApplicationModule(webBean);
              EmaiInvoiceSentVOImpl custVo = am1.getEmaiInvoiceSentVO1();
              EmaiInvoiceSentVORowImpl EmailInvoiceSentVO = null;
              String excCollectAdd = " ";
              
              Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

              String inPendingReqId="";
              String inCustId="";
              String inCustName="";
              String inUrlId="";
              String inSentCount="";
              String outWebUrl="";
              String inUrlIdStr = "";
              int requestSentCount=0;
              int error_count=0;
              String messageValue="";
            
		
					  
              if (rowsLength > 0) {
                  for (int i = 0; i < rowsLength; i++) {
					  
                      EmailInvoiceSentVO = (EmaiInvoiceSentVORowImpl) rows[i];
                      
                      Number inPendingReqIdNumb = (Number) EmailInvoiceSentVO.getAttribute("InvSentId");
                      String inPendingReqIdString = inPendingReqIdNumb.toString();
                      int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                      
                      inCustId = (String) EmailInvoiceSentVO.getAttribute("CustNum");
					  
					  String getCustname[] =new String[1];
					  getCustname = getCustName(pageContext, webBean,inCustId);
					  inCustName = getCustname[0];
                    
                      inUrlId = (String) EmailInvoiceSentVO.getAttribute("OutEbizUrl");
                      inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                      
                      inSentCount = (String) EmailInvoiceSentVO.getAttribute("sentCount");
                      int inSentCountInt = Integer.parseInt(inSentCount);
                      inSentCountInt = inSentCountInt + 1;
                      String countString=String.valueOf(inSentCountInt) ;
                      
                      String responseResend[] = resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId,inPendingReqIdString,countString);
                      String rurl = responseResend[0];
                      outWebUrl = outWebUrl +  rurl;
                           
                       
                      if(updatePendingReqCount(pageContext, webBean, inPendingReqIdInt, inSentCountInt) ) {
                          requestSentCount++;
                      }else{
                          throw new OAException("Update Pending Request not done in Database", OAException.ERROR);
                      }
                      
                  }

			  if(requestSentCount>0 && error_count>0){
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(requestSentCount+" request(s) sent again successfully. " + error_count + " request(s) not sent again successfully " +" Beacause " +messageValue, OAException.WARNING);          
                }
                else if(requestSentCount>0 && error_count==0)
                {
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(requestSentCount+" request(s) sent again successfully." , OAException.INFORMATION);
                }
                else if(requestSentCount<=0 && error_count>0)
                {  
                    am1.initEmaiInvoiceSentVO();
                    throw new OAException(error_count + " request(s) not sent again successfully " +" Beacuase " +messageValue, OAException.ERROR);
                }
                else{
                  
                    throw new OAException("Error sending request(s), check log.", OAException.ERROR);
                }
                
              }

                    throw new OAException("Please select request to send it again.", OAException.WARNING);
              
          }
    super.processFormRequest(pageContext, webBean);
    
  }

    public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum,String sentId,String sentCount){

                   String resp[]  = new String[2];
                   CallableStatement callableStatement;
                        try {
                               OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                               callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_email(:1,:2,:3,:4,:5,:6); end;",
                               OADBTransaction.DEFAULT);
                           
                                 callableStatement.setString(1, custNum);
                                   callableStatement.setString(2, internalId);
                              callableStatement.setString(3, sentId);
                              callableStatement.setString(4, sentCount);
                                 callableStatement.registerOutParameter(5, Types.VARCHAR);
                                 callableStatement.registerOutParameter(6, Types.VARCHAR);
                                 
                              
                                 callableStatement.execute();
                                
                                 String  errorcode = callableStatement.getString(5);
                                 String  errormsg = callableStatement.getString(6);

                           
                              resp[0] = errorcode;
                              resp[1] = errormsg;
                                   
                               

                               callableStatement.close();   
                                              
                          } catch (SQLException e) {
                              throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                          }
                   
                   
                   return resp;
               }
      public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
                       CallableStatement stmtaddTemplate;
                    String userId = String.valueOf(paramOAPageContext.getUserId());
                            try {
                                   OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                   stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.update_request_count(:1,:2,:3); end;",
                                   OADBTransaction.DEFAULT);
                               
                                       stmtaddTemplate.setInt(1, pendingreqId);
                                       stmtaddTemplate.setInt(2, count); 
                                       stmtaddTemplate.setString(3, userId); 
                                       
                                       
                                       
                                   stmtaddTemplate.execute();

                                   stmtaddTemplate.close();   
                                                  
                              } catch (SQLException e) {
                                  throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                              }
                                          
                       return true;
                }  
    public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){
                  
              
                  String resp[] = new String[6];
                  CallableStatement callableStatement;
                       try {
                              OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                              callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                              OADBTransaction.DEFAULT);
                            callableStatement.setString(1, p_cust_num);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                             callableStatement.execute();
                             String  p_cust_name = callableStatement.getString(2);
                             resp[0] = p_cust_name;  
                             callableStatement.close();   
                                             
                         } catch (SQLException e) {
                             throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                         }
                  
                  return resp;
              }
}
