 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.pmr.webui;
 
 import com.sun.java.util.collections.HashMap;
 import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVOImpl;
 import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;
 import ebizch.oracle.apps.fnd.pmr.server.EbizChPmrAMImpl;
 import ebizch.oracle.apps.fnd.pmr.server.GwTemplatesLovVOImpl;
 import ebizch.oracle.apps.fnd.pmr.server.PayMethodCustMasterVOImpl;

 import java.sql.CallableStatement;
 import java.sql.SQLException;

 import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
 import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

 /**
  * Controller for ...
  */
 public class EbizChargeReqPayMethodWalletACHCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
     String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName="";
   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       super.processRequest(pageContext, webBean);

       String  CUST_NO = pageContext.getParameter("IbyCustAcctNumber");
       String getCustname[] =new String[1];
       getCustname = getCustName(pageContext, webBean,CUST_NO);
       String Custname = getCustname[0];
       String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
		String toEmail= getcustEmail(pageContext, webBean,CUST_NO);
       
	   String IbyReturnlink = pageContext.getParameter("IbyReturnlink");

       Truncate(pageContext,webBean);
       String getEmailTempResp[] =new String[2];
       getEmailTempResp =  createEmailTemplate(pageContext, webBean);

       String getResp[] =new String[3];
       getResp =  get_EmailTempbyClassCode(pageContext,webBean);
       inEmailTemplate = getResp[0];
       inSubjectText = getResp[1];
       inFromMail = getResp[2];
       inFromName= getResp[3];

       OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
       lovBean.setText(pageContext,inEmailTemplate);

       OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
       textBean.setText(inSubjectText);

       OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
       EmailFromIntextBean.setText(inFromMail);

       OAMessageTextInputBean CustomerNoBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerNo");
      CustomerNoBean.setText(pageContext,inIbyCustAcctNumber);

       OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
       CustomerNameBean.setText(pageContext,Custname);
		
		OAMessageTextInputBean EmailToInBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
		EmailToInBean.setText(pageContext,toEmail);
		
	String getMerchantData=getMerchantData(pageContext,webBean);
	
	if ("false".equals(getMerchantData))
	{
		OASubmitButtonBean sendReqBtn = (OASubmitButtonBean) webBean.findChildRecursive("Send");
		sendReqBtn.setDisabled(true);
		throw new OAException("Bank Account transactions are not enabled on your merchant account. To enable this feature, please contact your account manager or support@centurybizsolutions.com for more information.", OAException.WARNING);
	}


   }

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       super.processFormRequest(pageContext, webBean);

       String inTemplateName="";
       String inSubject="";
       String inEmailNotes="";
       String inCustId="";
       String inFromMail="";
       String inEmailArr="";
       String outWebUrl = " ";
       String inCustName = "";
       String EmailToIn = "";
       String messageValue="";
       int error_count = 0;
       int requestSentCount=0;
       String IbyReturnlink = pageContext.getParameter("IbyReturnlink");
       String  CUST_NO = pageContext.getParameter("IbyCustAcctNumber");
       String  CUST_Name = pageContext.getParameter("HzPuiSubPartyName");


       String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
	   String IbyCustAccountId= pageContext.getParameter("IbyCustAccountId");
	   String  str4 = pageContext.getParameter("IbyOrgId");
 
       EbizChPmrAMImpl am = (EbizChPmrAMImpl)pageContext.getApplicationModule(webBean);
	       HashMap localHashMap = new HashMap();
     
     localHashMap.put("IbyOrgId", str4);
     localHashMap.put("AcctId", IbyCustAccountId);


	  if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("TemplateLovIn".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("SubjectInFV");
             //String inSubjectFv1 = inSubjectFv.getValue(pageContext).toString();
            String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromInFV");
             //String infromEmailFv = fromEmailFv.getValue(pageContext).toString(); 
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }




     String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID    from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATETYPEID = 'AddPaymentMethodFormEmail'";
                      try
                      {

                         GwTemplatesLovVOImpl vo1 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                            vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                             vo1.setQuery(query);
                            vo1.executeQuery();
                       }
                       catch (Exception e)
                       {
                           throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                       }
 //      }
 //  }

       if (pageContext.getParameter("Cancel") != null) {
          pageContext.setForwardURL(IbyReturnlink+"&retainAM=Y",
                                                  null, 
                                                  OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                                  null, localHashMap, true, "Y", (byte)99);
       }

       if (pageContext.getParameter("EmailFromIn") != null) {
           inFromMail = pageContext.getParameter("EmailFromIn");
       }

       if (pageContext.getParameter("EmailSubjectIn") != null) {
         inSubject =   pageContext.getParameter("EmailSubjectIn");
       }

       if (pageContext.getParameter("EmailToIn") != null) {
         EmailToIn =   pageContext.getParameter("EmailToIn");
       }

       if (pageContext.getParameter("EmailNotesIn") != null) {
         inEmailNotes =   pageContext.getParameter("EmailNotesIn");
       }

       if (pageContext.getParameter("CustomerName") != null) {
        String  CustomerName =   pageContext.getParameter("CustomerName");
        OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
        CustomerNameBean.setText(pageContext,CustomerName);

       }
       if (pageContext.getParameter("sendReqBtn") != null) {

        OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
        inTemplateName = TemplateIdFvInput.getValue(pageContext).toString();//getText(pageContext);
         
		throw new OAException("inTemplateName. " +inTemplateName, OAException.INFORMATION);
       
       }
       OASubmitButtonBean  Send =  (OASubmitButtonBean)webBean.findChildRecursive("Send");
       if (pageContext.getParameter("Send") != null){
		     OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
           inTemplateName = TemplateIdFvInput.getValue(pageContext).toString();
		     String[] validationsMessage = isValidate(inTemplateName,inSubject,inFromMail,CUST_NO,EmailToIn);
		   //	String messageValue="";
		   
		   if (validationsMessage[0].equals("1")) {
			        messageValue = messageValue + validationsMessage[1];
			      }
				  
           if (validationsMessage[0].equals("1")){
			       throw new OAException (messageValue,OAException.ERROR);
			      }
         
             outWebUrl = outWebUrl + setEbizWebForm(pageContext,webBean,EmailToIn,inTemplateName,inFromMail,inSubject,inEmailNotes,CUST_NO,inCustName);
			 OAMessageTextInputBean EmailToIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
             EmailToIntextBean.setText("");            
			throw new OAException("Request Payment Method has been successfully sent.", OAException.INFORMATION);
            
       }
   }



       public String  setEbizWebForm(OAPageContext pageContext, OAWebBean webBean, String inEmailArr, String inTemplateName, String inFromMail, String inSubject, String inEmailNotes, String inCustId, String inCustName) {

         String errorMsgList = "";
         String webUrl = "";
         String userId = String.valueOf(pageContext.getUserId());
         String emailArray = inEmailArr;
           int pendingReqId = getPendingReqId(pageContext, webBean, emailArray,inCustId);
            if(pendingReqId == 0){

         String[]  webUrlOne = sendEbizWebFormURL(pageContext,webBean,emailArray,inFromMail ,inCustId, inEmailNotes,inTemplateName,inSubject);
                          String errorcode  = webUrlOne[0] ;
                          String errormsg  = webUrlOne[1] ;
                          String epaymentURL  = webUrlOne[2]  ;
                          webUrl = webUrl + epaymentURL +"  ";

                    if("E".equals(errorcode)){
                        throw new OAException("Error in sendEbizWebFormURL. ", OAException.ERROR);
                    }
                if(addPendingPayment(pageContext, webBean, inCustId , inCustName , emailArray ,epaymentURL  ,inTemplateName  ,inSubject ,inEmailNotes , inFromMail  , emailArray ,userId )){
                    }

            } else {
                String[] pendingReqDetails = getPendingReqDetails(pageContext, webBean, pendingReqId);
                String inUrlId = pendingReqDetails[0];
                String inSentCountStr = pendingReqDetails[1];
                String inUrlIdStr = inUrlId.substring(inUrlId.length() - 36);
                int inSentCountInt = Integer.parseInt(inSentCountStr);
                inSentCountInt = inSentCountInt + 1;
                String responseResend[] =resendEbizWebFormURL(pageContext, webBean, inUrlIdStr,inCustId);
                String rurl= responseResend[0];
                webUrl = webUrl +  rurl;

                if(updatePendingReqCount(pageContext, webBean, pendingReqId, inSentCountInt) ) {

                }else{
                throw new OAException("Update Pending Request: inPendingReqIdInt. "+pendingReqId+ " inSentCountInt:"+inSentCountInt, OAException.ERROR);
                }

            }
             return webUrl;
       }

     public String[] sendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String inemailaddress , String inFromEmail, String CustomerId,String EmailNotes ,String inTempname,String inSubject){


           String resp[] = new String[3] ;
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_webformURL_byclass(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                       OADBTransaction.DEFAULT);

                         callableStatement.setString(1,inemailaddress );
                         callableStatement.setString(2, inFromEmail);
                         callableStatement.setString(3, CustomerId);
                         callableStatement.setString(4, EmailNotes);
                         callableStatement.registerOutParameter(5, Types.VARCHAR);
                         callableStatement.registerOutParameter(6, Types.VARCHAR);
                         callableStatement.registerOutParameter(7, Types.VARCHAR);
						 callableStatement.setString(8, inTempname);
                         callableStatement.setString(9, inSubject);
                         callableStatement.execute();

                         String      errorcode = callableStatement.getString(5);
                         String      errormsg = callableStatement.getString(6);
                         String      epayURL = callableStatement.getString(7);

                               resp[0] = errorcode;
                               resp[1] = errormsg;
                               resp[2] = epayURL;



                       callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
                  }

           return resp;
       }



     public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.TRUNCATETABLE; end;",
                          OADBTransaction.DEFAULT);



                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();

                     } catch (SQLException e) {
                         throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                     }


       }

     public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
         String errMsg="";
         String arrOutput[] = new String[2];
         OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
         CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;",
                                                          OADBTransaction.DEFAULT);
            try {
              callableStatement.registerOutParameter(1, Types.VARCHAR);
              callableStatement.registerOutParameter(2, Types.VARCHAR);


              callableStatement.execute();

              arrOutput[0] = callableStatement.getString(1);
              arrOutput[1] = callableStatement.getString(2);

              callableStatement.close();                                         
            }
            catch(Exception e){
            errMsg = e.getMessage();
                throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
            }
         return arrOutput;

     }


         public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean){


               String resp[] = new String[6];
               CallableStatement callableStatement;
                    try {
                           OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                           callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                           OADBTransaction.DEFAULT);

                         callableStatement.registerOutParameter(1, Types.VARCHAR);
                         callableStatement.registerOutParameter(2, Types.VARCHAR);
                         callableStatement.registerOutParameter(3, Types.VARCHAR);
                         callableStatement.registerOutParameter(4, Types.VARCHAR);
                         callableStatement.registerOutParameter(5, Types.VARCHAR);
                          callableStatement.registerOutParameter(6, Types.VARCHAR);
                          callableStatement.execute();
                          
						  String      o_temp = callableStatement.getString(1);
                          String      o_subject = callableStatement.getString(2);
                          String      o_fromemail = callableStatement.getString(3);
                          String      o_fromname = callableStatement.getString(4);
                          String      errorcode = callableStatement.getString(5);
                          String      errormsg = callableStatement.getString(6);

                          resp[0] = o_temp;
                          resp[1] = o_subject;
                          resp[2] = o_fromemail;
                          resp[3] = o_fromname;
                          resp[4] = errorcode;
                          resp[5] = errormsg;



                           callableStatement.close();

                      } catch (SQLException e) {
                          throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                      }

               return resp;
           }

     public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){


           String resp[] = new String[6];
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                       OADBTransaction.DEFAULT);

                     callableStatement.setString(1, p_cust_num);
                     callableStatement.registerOutParameter(2, Types.VARCHAR);

                      callableStatement.execute();
                      String  p_cust_name = callableStatement.getString(2);
                      resp[0] = p_cust_name;
                      callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                  }

           return resp;
       }


     public Boolean addPendingPayment(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_customerno , String p_customername , String p_email , String p_outebizurl  , String p_intemplatename  , String p_insubject ,String p_inemailnotes , String p_infrommail  , String p_intomail , String p_created_by ){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.add_pending_pay_method_req(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;",
                          OADBTransaction.DEFAULT);

                              stmtaddTemplate.setString(1, p_customerno);
                              stmtaddTemplate.setString(2, p_customername);
                              stmtaddTemplate.setString(3, p_email);
                              stmtaddTemplate.setString(4, p_outebizurl);
                              stmtaddTemplate.setString(5, p_intemplatename);
                              stmtaddTemplate.setString(6, p_insubject);
                              stmtaddTemplate.setString(7, p_inemailnotes);
                              stmtaddTemplate.setString(8, p_infrommail);
                              stmtaddTemplate.setString(9, p_intomail);
                              stmtaddTemplate.setString(10, p_created_by);

                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();

                     } catch (SQLException e) {
                         throw new OAException("Templates Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }

              return true;
       }

     public int getPendingReqId(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inEmail, String inCustId){
           CallableStatement stmtGetPendingReqId;
           int pendingreqId;

                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtGetPendingReqId = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_pmrid_from_email(:1,:2,:3); end;",
                          OADBTransaction.DEFAULT);


                             stmtGetPendingReqId.setString(1, inEmail);
                             stmtGetPendingReqId.setString(2, inCustId);
                             stmtGetPendingReqId.registerOutParameter(3, Types.VARCHAR);


                          stmtGetPendingReqId.execute();

                             String pendingReqIdStr = stmtGetPendingReqId.getString(3);
                             pendingreqId =  Integer.parseInt(pendingReqIdStr);

                          stmtGetPendingReqId.close();

                     } catch (SQLException e) {
                         throw new OAException("Get Pending Request ID from db exception: " + e.getMessage(), OAException.ERROR);
                     }

              return pendingreqId;
       }
     public String[] getPendingReqDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,int inPendingReqId) {
         String errMsg="";
         String arrOutput[] = new String[2];
         OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
         CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_pmr_detail_from_pid(:1,:2,:3); end;",
                                                          OADBTransaction.DEFAULT);
            try {
                callableStatement.setInt(1, inPendingReqId);
              callableStatement.registerOutParameter(2, Types.LONGVARCHAR);
                callableStatement.registerOutParameter(3, Types.VARCHAR);


              callableStatement.execute();

              arrOutput[0] = callableStatement.getString(2);
              arrOutput[1] = callableStatement.getString(3);


              callableStatement.close();                                         
            }
            catch(Exception e){
            errMsg = e.getMessage();
                throw new OAException("Get Pending Req Details: " + e.getMessage(), OAException.ERROR);
            }
     return arrOutput;
     }

     public String[] resendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String internalId,String custNum){

           String resp[] = new String[3];
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_resendEbizWebFormURL(:1,:2,:3,:4,:5); end;",
                       OADBTransaction.DEFAULT);

                         callableStatement.setString(1, custNum);
                         callableStatement.setString(2, internalId);
                         callableStatement.registerOutParameter(3, Types.VARCHAR);
                         callableStatement.registerOutParameter(4, Types.VARCHAR);
                         callableStatement.registerOutParameter(5, Types.VARCHAR);

                         callableStatement.execute();
                         String  rurl = callableStatement.getString(3);
                         String  errorcode = callableStatement.getString(4);
                         String  errormsg = callableStatement.getString(5);
                      resp[0] = rurl;
                      resp[1] = errorcode;
                      resp[2] = errormsg;



                       callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling resendEbizWebFormURL Exception: " + e.getMessage(), OAException.ERROR);
                  }


           return resp;
       }

     public Boolean updatePendingReqCount(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int pendingreqId, int count){
              CallableStatement stmtaddTemplate;
           String userId = String.valueOf(paramOAPageContext.getUserId());
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.update_pending_request_count(:1,:2,:3); end;",
                          OADBTransaction.DEFAULT);

                                                  stmtaddTemplate.setInt(1, pendingreqId);
                              stmtaddTemplate.setInt(2, count);
                              stmtaddTemplate.setString(3, userId);

                          stmtaddTemplate.execute();


                          stmtaddTemplate.close();

                     } catch (SQLException e) {
                         throw new OAException("Updating Pending Request into DB. Exception: " + e.getMessage(), OAException.ERROR);
                     }

              return true;
       }
  public String getcustEmail(OAPageContext pageContext, OAWebBean webBean,String custNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_cust_email(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getcustEmail Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
 public String[] isValidate(String TemplateLovIn,String EmailSubjectIn,String EmailFromIn,String CustomerNo,String EmailToIn) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(TemplateLovIn)) || "".equals(String.valueOf(TemplateLovIn))) {
        retMessage = retMessage + "Template, ";
      }

      if ("null".equals(String.valueOf(EmailSubjectIn)) || "".equals(EmailSubjectIn)) {
        retMessage = retMessage + "Email Subject, ";
      }

     if ("null".equals(String.valueOf(EmailFromIn)) || "".equals(EmailFromIn)) {
        retMessage = retMessage + "Email Send From, ";
      }
      if ("null".equals(String.valueOf(CustomerNo)) || "".equals(String.valueOf(CustomerNo))) {
        retMessage = retMessage + "Customer Number, ";
      }

      if ("null".equals(String.valueOf(EmailToIn)) || "".equals(String.valueOf(EmailToIn))) {
        retMessage = retMessage + "Email Send To ";
      }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are required field(s). Please fill in all required fields.";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Payment method data is validated.";
      }
      return output;
    }
	 public String getMerchantData(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput=""; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wallet_common_pkg.get_merchant_transaction_ach(:1); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             
             callableStatement.execute();  
           
             arrOutput = callableStatement.getString(1);   
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get getMerchantData Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }	
 }
