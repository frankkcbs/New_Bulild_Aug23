

 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.pmr.webui;

 import com.sun.java.util.collections.HashMap;
 import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVOImpl;
 import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;
 import ebizch.oracle.apps.fnd.pmr.server.EbizChPmrAMImpl;
 import ebizch.oracle.apps.fnd.pmr.server.GwTemplatesLovVOImpl;
 import ebizch.oracle.apps.fnd.pmr.server.PayMethodCustMasterVOImpl;

 import java.sql.CallableStatement;
 import java.sql.SQLException;

 import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
 import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

 /**
  * Controller for ...
  */
 public class EbizChargeReqPayMethodWalletCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
     String inSubjectText ="" ,inFromMail="" , inEmailTemplate="" , inFromName="";
   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
       super.processRequest(pageContext, webBean);

       String  CUST_NO = pageContext.getParameter("IbyCustAcctNumber");
       String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
       String getCustname[] =new String[1];
       getCustname = getCustName(pageContext, webBean,CUST_NO);
       String Custname = getCustname[0];
       String IbyReturnlink = pageContext.getParameter("IbyReturnlink");

       Truncate(pageContext,webBean);
       String getEmailTempResp[] =new String[2];
       getEmailTempResp =  createEmailTemplate(pageContext, webBean);

       String getResp[] =new String[3];
       getResp =  get_EmailTempbyClassCode(pageContext,webBean);
       inEmailTemplate = getResp[0];
       inSubjectText = getResp[1];
       inFromMail = getResp[2];
       inFromName= getResp[3];
       
	   String toEmail= getcustEmail(pageContext, webBean,CUST_NO);
	   
	   
       OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("TemplateLovIn");
       lovBean.setText(pageContext,inEmailTemplate);

       OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
       textBean.setText(inSubjectText);

       OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
       EmailFromIntextBean.setText(inFromMail);

       OAMessageTextInputBean CustomerNoBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerNo");
       CustomerNoBean.setText(pageContext,inIbyCustAcctNumber);

       OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
       CustomerNameBean.setText(pageContext,Custname);
		
		OAMessageTextInputBean EmailToInBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
		EmailToInBean.setText(pageContext,toEmail);



   }

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {

       String inTemplateName="";
       String inSubject="";
       String inEmailNotes="";
       String inCustId="";
       String inFromMail="";
       String inEmailArr="";
       String outWebUrl = " ";
       String inCustName = "";
       String EmailToIn = "";
       String messageValue="";
       int error_count = 0;
       int requestSentCount=0;
       String IbyReturnlink = pageContext.getParameter("IbyReturnlink");
       String  CUST_NO = pageContext.getParameter("IbyCustAcctNumber");
       String  inIbyCustAcctNumber = pageContext.getParameter("IbyCustAcctNumber");
	   String IbyCustAccountId= pageContext.getParameter("IbyCustAccountId");
       String  str4 = pageContext.getParameter("IbyOrgId");

       EbizChPmrAMImpl am = (EbizChPmrAMImpl)pageContext.getApplicationModule(webBean);
	    HashMap localHashMap = new HashMap();
     
     localHashMap.put("IbyOrgId", str4);
     localHashMap.put("AcctId", IbyCustAccountId);
	 
	     if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("TemplateLovIn".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("SubjectInFv");
             //String inSubjectFv1 = inSubjectFv.getValue(pageContext).toString();
             String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromInFV");
             //String infromEmailFv = fromEmailFv.getValue(pageContext).toString(); 
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }

	 
 //      if(pageContext.isLovEvent())
 //       {
 //       String lovInputSourceId = pageContext.getLovInputSourceId();
 //      if ("TemplateLovIn".equals(lovInputSourceId)){

     String query = "select  GWEMAILTEMPLATES_ID,  TEMPLATENAME , TEMPLATEINTERNALID   ,TEMPLATESUBJECT , TEMPLATEDESCRIPTION  ,TEMPLATEHTML  ,TEMPLATETEXT   , FROMEMAIL   , FROMNAME   , REPLYTOEMAIL  ,REPLYTODISPLAYNAME  ,TEMPLATESOURCE  ,TEMPLATETYPEID    from  EBIZCH_GW_EMAIL_TEMPLATES where TEMPLATETYPEID = 'AddPaymentMethodFormEmail'";
                      try
                      {

                         GwTemplatesLovVOImpl vo1 = (GwTemplatesLovVOImpl)am.findViewObject("GwTemplatesLovVO1");
                            vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
                             vo1.setQuery(query);
                            vo1.executeQuery();
                       }
                       catch (Exception e)
                       {
                           throw new OAException("Updating Query of lov.  Exception: " + e.getMessage(), OAException.ERROR);
                       }
 //      }
 //  }

       if (pageContext.getParameter("Cancel") != null) {
           pageContext.setForwardURL(IbyReturnlink+"&retainAM=Y",
                                                  null, 
                                                  OAWebBeanConstants.KEEP_MENU_CONTEXT, 
                                                  null, localHashMap, true, "Y", (byte)99);
       }

       if (pageContext.getParameter("EmailFromIn") != null) {
           inFromMail = pageContext.getParameter("EmailFromIn");
       }

       if (pageContext.getParameter("EmailSubjectIn") != null) {
         inSubject =   pageContext.getParameter("EmailSubjectIn");
       }

       if (pageContext.getParameter("EmailToIn") != null) {
         EmailToIn =   pageContext.getParameter("EmailToIn");
       }

       if (pageContext.getParameter("EmailNotesIn") != null) {
         inEmailNotes =   pageContext.getParameter("EmailNotesIn");
       }

       if (pageContext.getParameter("CustomerName") != null) {
        String  CustomerName =   pageContext.getParameter("CustomerName");
        OAMessageTextInputBean CustomerNameBean = (OAMessageTextInputBean)webBean.findChildRecursive("CustomerName");
        CustomerNameBean.setText(pageContext,CustomerName);

       }
       if (pageContext.getParameter("sendReqBtn") != null) {

        OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
        inTemplateName = TemplateIdFvInput.getValue(pageContext).toString();//getText(pageContext);
         throw new OAException("inTemplateName. " +inTemplateName, OAException.INFORMATION);
       // outWebUrl = outWebUrl + setEbizWebForm(pageContext,webBean,EmailToIn,inTemplateName,inFromMail,inSubject,inEmailNotes,inCustId,inCustName);
      //  throw new OAException("Request Payment Method form was successfully sent.", OAException.INFORMATION);

       }
       OASubmitButtonBean  Send =  (OASubmitButtonBean)webBean.findChildRecursive("Send");
       if (pageContext.getParameter("Send") != null){
           OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
           inTemplateName = TemplateIdFvInput.getValue(pageContext).toString();//getText(pageContext);
             outWebUrl = outWebUrl + setEbizWebForm(pageContext,webBean,EmailToIn,inTemplateName,inFromMail,inSubject,inEmailNotes,CUST_NO,inCustName);
		   OAMessageTextInputBean EmailToIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailToIn");
           EmailToIntextBean.setText("");
              throw new OAException("Request Payment Method form was successfully sent.", OAException.INFORMATION);
            //throw new OAException("inTemplateName. " +inTemplateName, OAException.INFORMATION);
       }
       super.processFormRequest(pageContext, webBean);
   }



       public String  setEbizWebForm(OAPageContext pageContext, OAWebBean webBean, String inEmailArr, String inTemplateName, String inFromMail, String inSubject, String inEmailNotes, String inCustId, String inCustName ) {

         String errorMsgList = "";
         String webUrl = "";
         String userId = String.valueOf(pageContext.getUserId());
         String emailArray = inEmailArr;

         String[]  webUrlOne = sendEbizWebFormURL(pageContext,webBean,emailArray,inFromMail ,inCustId, inEmailNotes,inTemplateName,inSubject);
                          String errorcode  = webUrlOne[0] ;
                          String errormsg  = webUrlOne[1] ;
                          String epaymentURL  = webUrlOne[2]  ;
                          webUrl = webUrl + epaymentURL +"  ";

                    if("E".equals(errorcode)){
                        throw new OAException("Error in sendEbizWebFormURL. ", OAException.ERROR);
                    }

             return webUrl;
       }

     public String[] sendEbizWebFormURL(OAPageContext pageContext, OAWebBean webBean, String inemailaddress , String inFromEmail, String CustomerId ,String inEmailNotes,String inTempName,String inSubject){


           String resp[] = new String[3] ;
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_webformURL_byclass(:1,:2,:3,:4,:5,:6,:7,:8); end;",
                       OADBTransaction.DEFAULT);

                         callableStatement.setString(1,inemailaddress );
                         callableStatement.setString(2, inFromEmail);
                         callableStatement.setString(3, CustomerId);
                         callableStatement.registerOutParameter(4, Types.VARCHAR);
                         callableStatement.registerOutParameter(5, Types.VARCHAR);
                         callableStatement.registerOutParameter(6, Types.VARCHAR);
						  callableStatement.setString(7, inTempName);
                         callableStatement.setString(8, inSubject);
						 
                         callableStatement.execute();

                         String      errorcode = callableStatement.getString(4);
                         String      errormsg = callableStatement.getString(5);
                         String      epayURL = callableStatement.getString(6);

                               resp[0] = errorcode;
                               resp[1] = errormsg;
                               resp[2] = epayURL;



                       callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
                  }

           return resp;
       }



     public void Truncate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
              CallableStatement stmtaddTemplate;
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                          stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.TRUNCATETABLE; end;",
                          OADBTransaction.DEFAULT);



                          stmtaddTemplate.execute();

                          stmtaddTemplate.close();

                     } catch (SQLException e) {
                         throw new OAException("Truncate Procedure. Exception: " + e.getMessage(), OAException.ERROR);
                     }


       }

     public String[] createEmailTemplate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
         String errMsg="";
         String arrOutput[] = new String[2];
         OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
         CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_multi_emailtemp_pmr_div(:1,:2); end;",
                                                          OADBTransaction.DEFAULT);
            try {
              callableStatement.registerOutParameter(1, Types.VARCHAR);
              callableStatement.registerOutParameter(2, Types.VARCHAR);


              callableStatement.execute();

              arrOutput[0] = callableStatement.getString(1);
              arrOutput[1] = callableStatement.getString(2);

              callableStatement.close();
            }
            catch(Exception e){
            errMsg = e.getMessage();
                throw new OAException("Get Default Templates Details: " + e.getMessage(), OAException.ERROR);
            }
         return arrOutput;

     }


         public String[] get_EmailTempbyClassCode(OAPageContext pageContext, OAWebBean webBean){


               String resp[] = new String[6];
               CallableStatement callableStatement;
                    try {
                           OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                           callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_CC_pkg.get_EmailTempbyClassCode(:1,:2,:3,:4,:5,:6); end;",
                           OADBTransaction.DEFAULT);

                         callableStatement.registerOutParameter(1, Types.VARCHAR);
                         callableStatement.registerOutParameter(2, Types.VARCHAR);
                         callableStatement.registerOutParameter(3, Types.VARCHAR);
                         callableStatement.registerOutParameter(4, Types.VARCHAR);
                         callableStatement.registerOutParameter(5, Types.VARCHAR);
                          callableStatement.registerOutParameter(6, Types.VARCHAR);
                          callableStatement.execute();
						  
                          String      o_temp = callableStatement.getString(1);
                          String      o_subject = callableStatement.getString(2);
                          String      o_fromemail = callableStatement.getString(3);
                          String      o_fromname = callableStatement.getString(4);
                          String      errorcode = callableStatement.getString(5);
                          String      errormsg = callableStatement.getString(6);

                          resp[0] = o_temp;
                          resp[1] = o_subject;
                          resp[2] = o_fromemail;
                          resp[3] = o_fromname;
                          resp[4] = errorcode;
                          resp[5] = errormsg;



                           callableStatement.close();

                      } catch (SQLException e) {
                          throw new OAException("Error in calling getEmailTemplateFetch Exception: " + e.getMessage(), OAException.ERROR);
                      }

               return resp;
           }


     public String[] getCustName(OAPageContext pageContext, OAWebBean webBean, String p_cust_num){


           String resp[] = new String[6];
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.getCustomerName(:1,:2); end;",
                       OADBTransaction.DEFAULT);
                     callableStatement.setString(1, p_cust_num);
                     callableStatement.registerOutParameter(2, Types.VARCHAR);
                      callableStatement.execute();
                      String  p_cust_name = callableStatement.getString(2);
                      resp[0] = p_cust_name;
                      callableStatement.close();

                  } catch (SQLException e) {
                      throw new OAException("Error in calling getCustomerName Exception: " + e.getMessage(), OAException.ERROR);
                  }

           return resp;
       }
  public String getcustEmail(OAPageContext pageContext, OAWebBean webBean,String custNum)
		  {
              CallableStatement callableStatement;
			   String  email ="";
                   try {
                          OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                          callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_cust_email(:1,:2); end;",
                          OADBTransaction.DEFAULT);
                      
                            callableStatement.setString(1, custNum);
                            callableStatement.registerOutParameter(2, Types.VARCHAR);
                            
                            callableStatement.execute();
                           
                              email = callableStatement.getString(2);

                          callableStatement.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error in calling getcustEmail Exception: " + e.getMessage(), OAException.ERROR);
                     }
              
              
              return email;
          }
 }
