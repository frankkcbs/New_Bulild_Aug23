package ebizch.oracle.apps.fnd.pmr.server;

import ebizch.oracle.apps.fnd.pmr.server.DivLovVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.EbizChPmrAMImpl;
import ebizch.oracle.apps.fnd.pmr.server.GwTemplatesLovVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodAddedCCAllVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodCcDetailsVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodCustMasterVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodFilterVOImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodPendingReqImpl;
import ebizch.oracle.apps.fnd.pmr.server.PayMethodReceivedReqImpl;
import oracle.apps.fnd.framework.server.OAApplicationModuleImpl;
import oracle.jbo.server.ViewLinkImpl;

public class EbizChPmrAMImpl extends OAApplicationModuleImpl {
	
	public EbizChPmrAMImpl() {
    }
	
  public GwTemplatesLovVOImpl getGwTemplatesLovVO1() {
    return (GwTemplatesLovVOImpl)findViewObject("GwTemplatesLovVO1");
  }
  
  public void initGwTemplatesLovVO() {
    GwTemplatesLovVOImpl gwTemplatesLovVOImpl = getGwTemplatesLovVO1();
    gwTemplatesLovVOImpl.executeQuery();
  }
  
  public void initPayMethodPendingReq() {
    PayMethodPendingReqImpl payMethodPendingReqImpl = getPayMethodPendingReq1();
    payMethodPendingReqImpl.executeQuery();
  }
  public void initPayMethodReceivedReq() {
    PayMethodReceivedReqImpl payMethodReceivedReqImpl = getPayMethodReceivedReq1();
    payMethodReceivedReqImpl.executeQuery();
  }
  public PayMethodAddedCCAllVOImpl getPayMethodAddedCCAllVO1() {
    return (PayMethodAddedCCAllVOImpl)findViewObject("PayMethodAddedCCAllVO1");
  }
  
  public PayMethodCcDetailsVOImpl getPayMethodCcDetailsVO1() {
    return (PayMethodCcDetailsVOImpl)findViewObject("PayMethodCcDetailsVO1");
  }
  
  public PayMethodCustMasterVOImpl getPayMethodCustMasterVO1() {
    return (PayMethodCustMasterVOImpl)findViewObject("PayMethodCustMasterVO1");
  }
  
  public PayMethodCcDetailsVOImpl getPayMethodCcDetailsVO2() {
    return (PayMethodCcDetailsVOImpl)findViewObject("PayMethodCcDetailsVO2");
  }
  
  public void initPayMethodAddedCCAllVO() {
    PayMethodAddedCCAllVOImpl payMethodAddedCCAllVOImpl = getPayMethodAddedCCAllVO1();
    payMethodAddedCCAllVOImpl.executeQuery();
  }
  
  public PayMethodFilterVOImpl getPayMethodFilterVO1() {
    return (PayMethodFilterVOImpl)findViewObject("PayMethodFilterVO1");
  }
  
  public void initPayMethodCustMasterVO() {
    PayMethodCustMasterVOImpl payMethodCustMasterVOImpl = getPayMethodCustMasterVO1();
    payMethodCustMasterVOImpl.executeQuery();
  }
  
  public PayMethodPendingReqImpl getPayMethodPendingReq1() {
    return (PayMethodPendingReqImpl)findViewObject("PayMethodPendingReq1");
  }
   public PayMethodReceivedReqImpl getPayMethodReceivedReq1() {
    return (PayMethodReceivedReqImpl)findViewObject("PayMethodReceivedReq1");
  }
  public ViewLinkImpl getPayMethodCustCcVL1() {
    return (ViewLinkImpl)findViewLink("PayMethodCustCcVL1");
  }
  
  public static void main(String[] paramArrayOfString) {
    launchTester("ebizch.oracle.apps.fnd.pmr.server", "EbizChPmrAMLocal");
  }
  
  public DivLovVOImpl getDivLovVO1() {
    return (DivLovVOImpl)findViewObject("DivLovVO1");
  }
}
