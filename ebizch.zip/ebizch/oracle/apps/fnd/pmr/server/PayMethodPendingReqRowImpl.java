package ebizch.oracle.apps.fnd.pmr.server;

import ebizch.oracle.apps.fnd.pmr.server.PayMethodPendingReqRowImpl;
import oracle.apps.fnd.framework.server.OAViewRowImpl;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.AttributeDefImpl;

public class PayMethodPendingReqRowImpl extends OAViewRowImpl {
  public static final int PENDINGREQID = 0;
  
  public static final int CUSTOMERNO = 1;
  
  public static final int CUSTOMERNAME = 2;
  
  public static final int EMAIL = 3;
  
  public static final int EMAILSENTTIME = 4;
  
  public static final int SENTCOUNT = 5;
  
  public static final int OUTEBIZURL = 6;
  
  public static final int INTEMPLATENAME = 7;
  
  public static final int INSUBJECT = 8;
  
  public static final int INEMAILNOTES = 9;
  
  public static final int INFROMMAIL = 10;
  
  public static final int INTOMAIL = 11;
  
  public static final int CREATEDAT = 12;
  
  public static final int CREATEDBY = 13;
  
  public static final int LASTUPDATEDAT = 14;
  
  public static final int LASTUPDATEDBY = 15;
  
  public static final int REMOVEFLAG = 16;
  
  public static final int VIEWATTR = 17;
  
  public Number getPendingreqid() {
    return (Number)getAttributeInternal(0);
  }
  
  public void setPendingreqid(Number paramNumber) {
    setAttributeInternal(0, paramNumber);
  }
  
  public String getCustomerno() {
    return (String)getAttributeInternal(1);
  }
  
  public void setCustomerno(String paramString) {
    setAttributeInternal(1, paramString);
  }
  
  public String getCustomername() {
    return (String)getAttributeInternal(2);
  }
  
  public void setCustomername(String paramString) {
    setAttributeInternal(2, paramString);
  }
  
  public String getEmail() {
    return (String)getAttributeInternal(3);
  }
  
  public void setEmail(String paramString) {
    setAttributeInternal(3, paramString);
  }
  
  public String getEmailsenttime() {
    return (String)getAttributeInternal(4);
  }
  
  public void setEmailsenttime(String paramDate) {
    setAttributeInternal(4, paramDate);
  }
  
  public String getSentcount() {
    return (String)getAttributeInternal(5);
  }
  
  public void setSentcount(String paramString) {
    setAttributeInternal(5, paramString);
  }
  
  public String getOutebizurl() {
    return (String)getAttributeInternal(6);
  }
  
  public void setOutebizurl(String paramString) {
    setAttributeInternal(6, paramString);
  }
  
  public String getIntemplatename() {
    return (String)getAttributeInternal(7);
  }
  
  public void setIntemplatename(String paramString) {
    setAttributeInternal(7, paramString);
  }
  
  public String getInsubject() {
    return (String)getAttributeInternal(8);
  }
  
  public void setInsubject(String paramString) {
    setAttributeInternal(8, paramString);
  }
  
  public String getInemailnotes() {
    return (String)getAttributeInternal(9);
  }
  
  public void setInemailnotes(String paramString) {
    setAttributeInternal(9, paramString);
  }
  
  public String getInfrommail() {
    return (String)getAttributeInternal(10);
  }
  
  public void setInfrommail(String paramString) {
    setAttributeInternal(10, paramString);
  }
  
  public String getIntomail() {
    return (String)getAttributeInternal(11);
  }
  
  public void setIntomail(String paramString) {
    setAttributeInternal(11, paramString);
  }
  
  public Date getCreatedAt() {
    return (Date)getAttributeInternal(12);
  }
  
  public void setCreatedAt(Date paramDate) {
    setAttributeInternal(12, paramDate);
  }
  
  public Number getCreatedBy() {
    return (Number)getAttributeInternal(13);
  }
  
  public void setCreatedBy(Number paramNumber) {
    setAttributeInternal(13, paramNumber);
  }
  
  public String getLastUpdatedAt() {
    return (String)getAttributeInternal(14);
  }
  
  public void setLastUpdatedAt(String paramDate) {
    setAttributeInternal(14, paramDate);
  }
  
  public Number getLastUpdatedBy() {
    return (Number)getAttributeInternal(15);
  }
  
  public void setLastUpdatedBy(Number paramNumber) {
    setAttributeInternal(15, paramNumber);
  }
  
  public String getRemoveFlag() {
    return (String)getAttributeInternal(16);
  }
  
  public void setRemoveFlag(String paramString) {
    setAttributeInternal(16, paramString);
  }
  
  protected Object getAttrInvokeAccessor(int paramInt, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        return getPendingreqid();
      case 1:
        return getCustomerno();
      case 2:
        return getCustomername();
      case 3:
        return getEmail();
      case 4:
        return getEmailsenttime();
      case 5:
        return getSentcount();
      case 6:
        return getOutebizurl();
      case 7:
        return getIntemplatename();
      case 8:
        return getInsubject();
      case 9:
        return getInemailnotes();
      case 10:
        return getInfrommail();
      case 11:
        return getIntomail();
      case 12:
        return getCreatedAt();
      case 13:
        return getCreatedBy();
      case 14:
        return getLastUpdatedAt();
      case 15:
        return getLastUpdatedBy();
      case 16:
        return getRemoveFlag();
      case 17:
        return getViewAttr();
    } 
    return super.getAttrInvokeAccessor(paramInt, paramAttributeDefImpl);
  }
  
  protected void setAttrInvokeAccessor(int paramInt, Object paramObject, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        setPendingreqid((Number)paramObject);
        return;
      case 1:
        setCustomerno((String)paramObject);
        return;
      case 2:
        setCustomername((String)paramObject);
        return;
      case 3:
        setEmail((String)paramObject);
        return;
      case 4:
        setEmailsenttime((String)paramObject);
        return;
      case 5:
        setSentcount((String)paramObject);
        return;
      case 6:
        setOutebizurl((String)paramObject);
        return;
      case 7:
        setIntemplatename((String)paramObject);
        return;
      case 8:
        setInsubject((String)paramObject);
        return;
      case 9:
        setInemailnotes((String)paramObject);
        return;
      case 10:
        setInfrommail((String)paramObject);
        return;
      case 11:
        setIntomail((String)paramObject);
        return;
      case 12:
        setCreatedAt((Date)paramObject);
        return;
      case 13:
        setCreatedBy((Number)paramObject);
        return;
      case 14:
        setLastUpdatedAt((String)paramObject);
        return;
      case 15:
        setLastUpdatedBy((Number)paramObject);
        return;
      case 16:
        setRemoveFlag((String)paramObject);
        return;
      case 17:
        setViewAttr((String)paramObject);
        return;
    } 
    super.setAttrInvokeAccessor(paramInt, paramObject, paramAttributeDefImpl);
  }
  
  public String getViewAttr() {
    return (String)getAttributeInternal(17);
  }
  
  public void setViewAttr(String paramString) {
    setAttributeInternal(17, paramString);
  }
}
