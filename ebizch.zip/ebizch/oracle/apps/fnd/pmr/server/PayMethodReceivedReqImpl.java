package ebizch.oracle.apps.fnd.pmr.server;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class PayMethodReceivedReqImpl extends OAViewObjectImpl {
	
	 public PayMethodReceivedReqImpl() {
    }
	
}


