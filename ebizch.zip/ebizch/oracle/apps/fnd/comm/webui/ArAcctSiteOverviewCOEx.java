 package ebizch.oracle.apps.fnd.comm.webui;

 import com.sun.java.util.collections.HashMap;


 import oracle.apps.ar.cusstd.acctSite.webui.ArAcctSiteOverviewCO;
 import java.sql.CallableStatement;

 import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.layout.OAFlowLayoutBean;
 import oracle.apps.fnd.framework.webui.beans.nav.OAButtonBean;
 import oracle.apps.fnd.framework.webui.beans.nav.OALovActionButtonBean;

 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;

 import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;


 public class ArAcctSiteOverviewCOEx extends ArAcctSiteOverviewCO {
     
     public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
         
         super.processRequest(paramOAPageContext, paramOAWebBean);
                 String CustomerNo = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                   String getResp[] =new String[2];
                 getResp = getMerchantData(paramOAPageContext, paramOAWebBean, CustomerNo);
         String vAchFlag = "";
		 vAchFlag =getResp[0];
                 String vCcFlag = "";
				vCcFlag=  getResp[1];
         OAFlowLayoutBean  oatb1 = (OAFlowLayoutBean)paramOAWebBean.findChildRecursive("LOVActionRN");
         OAFlowLayoutBean  oatb = (OAFlowLayoutBean)paramOAWebBean.findChildRecursive("LovActionRN");
		
		
		  
	//	 if(vCcFlag == "true"){		 
                 OASubmitButtonBean oasb5 = (OASubmitButtonBean)paramOAPageContext.getWebBeanFactory().createWebBean(paramOAPageContext, "BUTTON_SUBMIT");         
                  oasb5.setID("CreateCreditCardBtn");
                  oasb5.setUINodeName("CreateCreditCardBtn");
                  oasb5.setEvent("CreateCreditCardBtn");
                  oasb5.setText("Add New Card");
                  oatb.addIndexedChild(oasb5);   
                 
                  OASubmitButtonBean oasb6 = (OASubmitButtonBean)paramOAPageContext.getWebBeanFactory().createWebBean(paramOAPageContext, "BUTTON_SUBMIT");         
                  oasb6.setID("RequestPayBtn");
                  oasb6.setUINodeName("RequestPayBtn");
                  oasb6.setEvent("RequestPayBtn");
                  oasb6.setText("Request Credit Card");
                  oatb.addIndexedChild(oasb6); 
		// }
                 // ACH Code For Buttons --- End //
       //  if(vAchFlag == "true"){
			 
                  OASubmitButtonBean oasb3 = (OASubmitButtonBean)paramOAPageContext.getWebBeanFactory().createWebBean(paramOAPageContext, "BUTTON_SUBMIT");         
             oasb3.setID("RequestPayBtnAch");         
             oasb3.setUINodeName("RequestPayBtnAch");         
             oasb3.setEvent("RequestPayBtnAch");         
             oasb3.setText("Request Bank Account");    
         oatb1.addIndexedChild(oasb3);
		 // throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
          //    }    
                 
                 OASubmitButtonBean oasb4 = (OASubmitButtonBean)paramOAPageContext.getWebBeanFactory().createWebBean(paramOAPageContext, "BUTTON_SUBMIT");     
             oasb4.setID("CreateBtnAch");
             oasb4.setUINodeName("CreateBtnAch");
             oasb4.setEvent("CreateBtnAch");
             oasb4.setText("Create Bank Account");
         oatb1.addIndexedChild(oasb4); 
         
                 OAButtonBean  CreateButton =  (OAButtonBean)oatb.findChildRecursive("CreateButton");
                 CreateButton.setRendered(false);
                 OALovActionButtonBean   Add =  (OALovActionButtonBean)oatb.findChildRecursive("AddButton");
                 Add.setRendered(false);    
				 
				       OAButtonBean  CreateButtons =  (OAButtonBean)oatb1.findChildRecursive("CreateBankAccount");
                 CreateButtons.setRendered(false);
                 OALovActionButtonBean   Adds =  (OALovActionButtonBean)oatb1.findChildRecursive("BAAddButton");
                 Adds.setRendered(false);  
				 
						//   throw new OAException("cc flag " +vCcFlag  +vAchFlag  +CustomerNo, OAException.ERROR);

     
     }
     public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
                 
          String CustomerNo = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
          String getResp[] =new String[2];
		  String vaccountnum[] =new String[2];
		  
		  String str1 = paramOAPageContext.getParameter("event");   
                  
             /*     if("false".equals(vCcFlag)){
         OASubmitButtonBean RequestPayBtn = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("RequestPayBtn");
         RequestPayBtn.setDisabled(true);
                          }
                  if("false".equals(vAchFlag)){
         OASubmitButtonBean RequestPayBtnAch = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("RequestPayBtnAch");
         RequestPayBtnAch.setDisabled(true);
                          }      */ 
                          
                         
              if("CreateBtnAch".equals(str1)){
                   String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                   String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                   String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                   String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                   String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                   String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                   
                   String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                   String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                   String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                   
                   String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                   String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                   String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                   String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                   
                   String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   
                   HashMap localHashMap = new HashMap();
                       localHashMap.put("IbyPayerPartyId", str3);
                       localHashMap.put("IbyPaymentFunction", str8);
                       localHashMap.put("IbyCustAccountId", str4);
                       localHashMap.put("IbyCustAccountSiteId", str5);
                       localHashMap.put("IbyOrgId", str6);
                       localHashMap.put("IbyOrgType", str7);
                       localHashMap.put("HzPuiAddressEvent", "CREATE");
                       localHashMap.put("HzPuiAddressLocationId", "");
                       localHashMap.put("IbyReturnLink", str9);
                       localHashMap.put("IbyReturnlink", str9);
                       localHashMap.put("IbyReturnLinkLabel", str10);
                       //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                       localHashMap.put("IbyPayerId", str11);
                       localHashMap.put("IbyPartyName", str13);
                       localHashMap.put("IbyOrgName", str12);
                       localHashMap.put("IbyCustAcctNumber", str14);
                       localHashMap.put("CUST_NO", str14);
                       localHashMap.put("IbyCustAcctSiteName", str15);
                       localHashMap.put("IbyReadOnlyFlag", str16);
                       localHashMap.put("IbyInstrumentType", "CREDITCARD");
                   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreateACHPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
               
               }
			     if("CreateCreditCardBtn".equals(str1)){
                   String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                   String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                   String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                   String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                   String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                   String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                   
                   String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                   String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                   String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                   
                   String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                   String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                   String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                   String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                   
                   String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   
                   HashMap localHashMap = new HashMap();
                       localHashMap.put("IbyPayerPartyId", str3);
                       localHashMap.put("IbyPaymentFunction", str8);
                       localHashMap.put("IbyCustAccountId", str4);
                       localHashMap.put("IbyCustAccountSiteId", str5);
                       localHashMap.put("IbyOrgId", str6);
					   localHashMap.put("ORG_ID", str6);
                       localHashMap.put("IbyOrgType", str7);
                       localHashMap.put("HzPuiAddressEvent", "CREATE");
                       localHashMap.put("HzPuiAddressLocationId", "");
                       localHashMap.put("IbyReturnLink", str9);
                       localHashMap.put("IbyReturnlink", str9);
                       localHashMap.put("IbyReturnLinkLabel", str10);
                       //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                       localHashMap.put("IbyPayerId", str11);
                       localHashMap.put("IbyPartyName", str13);
                       localHashMap.put("IbyOrgName", str12);
                       localHashMap.put("IbyCustAcctNumber", str14);
                       localHashMap.put("CUST_NO", str14);
                       localHashMap.put("IbyCustAcctSiteName", str15);
                       localHashMap.put("IbyReadOnlyFlag", str16);
                       localHashMap.put("IbyInstrumentType", "CREDITCARD");
                   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreditCardPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                //throw new OAException("Org ID ." + str6 , OAException.INFORMATION);
	 
               }
			   
                           else if("RequestPayBtn".equals(str1)){
                  String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                  String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                  String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                  String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                  String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                  String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                  
                  String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                  String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                  String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                  
                  String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                  String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                  String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                  String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                  
                  String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                   String str17 = (String)paramOAPageContext.getTransactionValue("HzPuiSubPartyName");
				 
				  
				   
				   
                  HashMap localHashMap = new HashMap();
                      localHashMap.put("IbyPayerPartyId", str3);
                      localHashMap.put("IbyPaymentFunction", str8);
                      localHashMap.put("IbyCustAccountId", str4);
                      localHashMap.put("IbyCustAccountSiteId", str5);
                      localHashMap.put("IbyOrgId", str6);
                      localHashMap.put("IbyOrgType", str7);
                      localHashMap.put("HzPuiAddressEvent", "CREATE");
                      localHashMap.put("HzPuiAddressLocationId", "");
                      localHashMap.put("IbyReturnLink", str9);
                      localHashMap.put("IbyReturnlink", str9);
                      localHashMap.put("IbyReturnLinkLabel", str10);
                      //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                      localHashMap.put("IbyPayerId", str11);
                      localHashMap.put("IbyPartyName", str13);
                      localHashMap.put("IbyOrgName", str12);
                      localHashMap.put("IbyCustAcctNumber", str14);
                      localHashMap.put("IbyCustAcctSiteName", str15);
                      localHashMap.put("IbyReadOnlyFlag", str16);
                      localHashMap.put("IbyInstrumentType", "CREDITCARD");
                                         localHashMap.put("HzPuiSubPartyName", str17);
				getResp = getMerchantData(paramOAPageContext, paramOAWebBean, str14);
                  String vAchFlag = getResp[0];
                  String vCcFlag = getResp[1];							 
						  if("true".equals(vCcFlag)){ 				 
                //paramOAPageContext.setForwardURL("OA.jsp?page=/oracle/apps/iby/creditcard/setup/webui/CreditCardCreatePG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                 paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/pmr/webui/EbizChargeRequestPayMethodWalletPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
						 }
              }
                          
                           if("RequestPayBtnAch".equals(str1)){
                  String str3 = (String)paramOAPageContext.getTransactionValue("IbyPayerPartyId");
                  String str4 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
                  String str5 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteId");
                  String str6 = (String)paramOAPageContext.getTransactionValue("IbyOrgId");
                  String str7 = (String)paramOAPageContext.getTransactionValue("IbyOrgType");
                  String str8 = (String)paramOAPageContext.getTransactionValue("IbyPaymentFunction");
                  
                  String str9 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnURL");
                  String str10 = (String)paramOAPageContext.getTransactionValue("IbyBasePageReturnLinkLabel");
                  String str11 = (String)paramOAPageContext.getTransactionValue("IbyPayerId");
                  
                  String str12 = (String)paramOAPageContext.getTransactionValue("IbyOrgName");
                  String str13 = (String)paramOAPageContext.getTransactionValue("IbyPayerName");
                  String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
                  String str15 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountSiteName");
                  
                  String str16 = (String)paramOAPageContext.getTransactionValue("IbyReadOnlyFlag");
                  String str17 = (String)paramOAPageContext.getTransactionValue("HzPuiSubPartyName");
                  HashMap localHashMap = new HashMap();
                      localHashMap.put("IbyPayerPartyId", str3);
                      localHashMap.put("IbyPaymentFunction", str8);
                      localHashMap.put("IbyCustAccountId", str4);
                      localHashMap.put("IbyCustAccountSiteId", str5);
                      localHashMap.put("IbyOrgId", str6);
                      localHashMap.put("IbyOrgType", str7);
                      localHashMap.put("HzPuiAddressEvent", "CREATE");
                      localHashMap.put("HzPuiAddressLocationId", "");
                      localHashMap.put("IbyReturnLink", str9);
                      localHashMap.put("IbyReturnlink", str9);
                      localHashMap.put("IbyReturnLinkLabel", str10);
                      //localHashMap.put("IbyPaymentFlow", this.FundsCapture);
                      localHashMap.put("IbyPayerId", str11);
                      localHashMap.put("IbyPartyName", str13);
                      localHashMap.put("IbyOrgName", str12);
                      localHashMap.put("IbyCustAcctNumber", str14);
                      localHashMap.put("IbyCustAcctSiteName", str15);
                      localHashMap.put("IbyReadOnlyFlag", str16);
                      localHashMap.put("IbyInstrumentType", "CREDITCARD");
                                          localHashMap.put("HzPuiSubPartyName", str17);
                getResp = getMerchantData(paramOAPageContext, paramOAWebBean, str14);
                  String vAchFlag = getResp[0];
                  String vCcFlag = getResp[1];							 
						 if("false".equals(vAchFlag)){
						    
                //paramOAPageContext.setForwardURL("OA.jsp?page=/oracle/apps/iby/creditcard/setup/webui/CreditCardCreatePG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/pmr/webui/EbizChargeRequestPayMethodWalletACHPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
              //   paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/ach/webui/EbizChargeRequestAchEmailPayPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
                                 //paramOAPageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/pmr/webui/EbizChargeRequestPayMethodWalletPG&retainAM=Y", null, (byte)0, null, localHashMap, true, "Y", (byte)99);
						 }
						 else 
						 {
					    OASubmitButtonBean RequestPayBtnAch = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("RequestPayBtnAch");
						RequestPayBtnAch.setDisabled(true);
							 
						 }
							 
              }
                if(paramOAPageContext.getParameter("Apply") != null)                 
       //  if("Apply".equals(str1))
         {
          //    String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
			 String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
			              String str15 =  null ;
            str15 = paramOAPageContext.getParameter("AcctId").toString();
			             String str16 =  null ;
            str16 = paramOAPageContext.getParameter("AcctId");
			 vaccountnum= getcustaccount(paramOAPageContext, paramOAWebBean, str16);
            String cust_acct_num  = vaccountnum[0];     
            getResp = UpdateCustomer(paramOAPageContext, paramOAWebBean,  cust_acct_num);
			String ErrorMsg = getResp[1];
           //  getResp = UpdateCustomer(paramOAPageContext, paramOAWebBean, str14);
             if (getResp[0]!="E")
             {
     //throw new OAException("Your changes has been saved cust_acct_num " +cust_acct_num+ " str15 " +str15+ " getResp[0] " +getResp[0] , OAException.INFORMATION);
	    throw new OAException("Your changes has been saved."  , OAException.INFORMATION);
	 
	   }
	   else
		throw new OAException("Error: " +ErrorMsg , OAException.ERROR);
		   
         }	  
                          
                           


         super.processFormRequest(paramOAPageContext, paramOAWebBean);
 
     }
     
         
         public String[] getMerchantData(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {
           
       
           String resp[] = new String[3] ;
           CallableStatement callableStatement;
                try {
                       OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                       callableStatement = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_Req_ACH_pkg.get_merchant_transaction_data(:1,:2,:3); end;",
                       OADBTransaction.DEFAULT);
                   
                         callableStatement.setString(1,CustomerNo );
                         callableStatement.registerOutParameter(2, Types.VARCHAR);
                         callableStatement.registerOutParameter(3, Types.VARCHAR);
                      
                         callableStatement.execute();
                      
                         String      achFlag = callableStatement.getString(2);
                         String      ccFlag = callableStatement.getString(3);

                               resp[0] = achFlag;
                               resp[1] = ccFlag;
                           
                     

                       callableStatement.close();   
                                      
                  } catch (SQLException e) {
                      throw new OAException("Error in calling get_webformURL Exception: " + e.getMessage(), OAException.ERROR);
                  }
           
           return resp;
      
         }
    
         
     public String[] UpdateCustomer(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {
       
         String[] resp = new String[2];
                                    CallableStatement sendcustDetails;
                                    try {
                                          OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                                                          sendcustDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_customer(:1,:2,:3); end;",
                                                                  OADBTransaction.DEFAULT);


                                                          sendcustDetails.registerOutParameter(1, Types.VARCHAR);
                                                          sendcustDetails.registerOutParameter(2, Types.VARCHAR);
                                                          sendcustDetails.setString(3, CustomerNo);
                                                                                         
                                                          sendcustDetails.execute();

                                                          resp[0] = sendcustDetails.getString(1);
                                                          resp[1] = sendcustDetails.getString(2);
                                                                                         
                                                          sendcustDetails.close();

                                      } catch (SQLException e) {
                                          throw new OAException("Error While Updating the Customer into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                                      }

                                                  return resp;
     
     }
	
	public String[] getcustaccount(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {
       
         String[] resp = new String[2];
                                    CallableStatement sendcustDetails;
                                    try {
                                          OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                                                          sendcustDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.get_Cust_account(:1,:2); end;",
                                                                  OADBTransaction.DEFAULT);


                                                          sendcustDetails.setString(1, CustomerNo);
                                                          sendcustDetails.registerOutParameter(2, Types.VARCHAR);
                                                                                         
                                                          sendcustDetails.execute();

                                                          resp[0] = sendcustDetails.getString(2);
                                                          
                                                                                         
                                                          sendcustDetails.close();

                                      } catch (SQLException e) {
                                          throw new OAException("Error While getting Customer Account Error Message:" + e.getMessage(), OAException.INFORMATION);
                                      }

                                                  return resp;
     
     }  
public String getMerchantDatacc(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        String errMsg="";
        String arrOutput=""; 
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  ebizch_wallet_common_pkg.get_merchant_transaction_cc(:1); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(1, Types.VARCHAR);  
             
             callableStatement.execute();  
           
             arrOutput = callableStatement.getString(1);   
              
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
               throw new OAException("Get getMerchantData Details: " + e.getMessage(), OAException.ERROR);
           }   
        return arrOutput;
        
    }			 
	 
 }