package ebizch.oracle.apps.fnd.comm.webui;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import java.util.Enumeration;

import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;


import oracle.apps.ar.cusstd.ovrview.webui.ArCusOvrCO;
import oracle.apps.fnd.framework.OAApplicationModule;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;


public class ArCusOvrCOEx extends ArCusOvrCO//AcctOviewPageCO 
{
    String firstAttr = "";
    String ScndAttr = "Update: ";
    String excCollect = " ";
    
    public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
       super.processRequest(paramOAPageContext, paramOAWebBean);
		
             // OAApplicationModule oAApplicationModule = paramOAPageContext.getApplicationModule(paramOAWebBean);
			 
			 // String acct_num = (String)oAApplicationModule.invokeMethod("getAcctNum");
             /*  String AcctId = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
              int AcctIdInt = Integer.parseInt(AcctId);
              String OuId = Integer.toString(paramOAPageContext.getOrgId());
              String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
              String getResp[] =new String[2];
              String vaccountnum[] =new String[2];
			  
              String str15 =  null ;
			  
              str15 = paramOAPageContext.getParameter("AcctId").toString();
              String str16 =  null ;
			  
              str16 = paramOAPageContext.getParameter("HzPuiCustAccountId");
			  
			  if (true)
			  {
				  throw new OAException(str14,OAException.ERROR);
			  }
              vaccountnum= getcustaccount(paramOAPageContext, paramOAWebBean, str16); */
			  String getResp[] =new String[2];
			  String vaccountnum[] =new String[2];
			  
              String str16  = paramOAPageContext.getParameter("HzPuiCustAccountId");
			  vaccountnum= getcustaccount(paramOAPageContext, paramOAWebBean, str16);//vaccountnum[0];
			  String cust_acct_num =vaccountnum[0];
			  
              getResp = UpdateCustomer(paramOAPageContext, paramOAWebBean,  cust_acct_num);
			
              String ErrorMsg = getResp[1];
              
              if (getResp[0]!="E")
              {
                                                                 
              throw new OAException("Your changes has been saved."  , OAException.INFORMATION);

              }
              else
			  {
				throw new OAException("Error: " +ErrorMsg , OAException.ERROR);  
			  }
              
         
          }
          
    public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
        
        super.processFormRequest(paramOAPageContext, paramOAWebBean);
      /* String OuId = Integer.toString(paramOAPageContext.getOrgId());
       String CustomerNo = (String)paramOAPageContext.getTransactionValue("IbyCustAccountNumber");
       String getResp[] =new String[2];
       String vaccountnum[] =new String[2];
       String str1 = paramOAPageContext.getParameter("event");
	   
       if("Apply".equals(str1))
        {
         
           String str14 = (String)paramOAPageContext.getTransactionValue("IbyCustAccountId");
           String str15 =  null ;
           str15 = paramOAPageContext.getParameter("AcctId").toString();
           String str16 =  null ;
           str16 = paramOAPageContext.getParameter("AcctId");
           vaccountnum= getcustaccount(paramOAPageContext, paramOAWebBean, str16);
           String cust_acct_num  = vaccountnum[0];
           getResp = UpdateCustomer(paramOAPageContext, paramOAWebBean,  cust_acct_num);
                       String ErrorMsg = getResp[1];
         
            if (getResp[0]!="E")
            {
                                                            
           throw new OAException("Your changes has been saved."  , OAException.INFORMATION);

          }
          else
               throw new OAException("Error: " +ErrorMsg , OAException.ERROR);

        }
		*/
    }
    
    public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo, String addType){
                String[] addDetails = new String[6]; 
                            CallableStatement stmtGetCustAddDetails;
                try {
                      OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                      stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_creditcard_pkg.get_cust_add_cc(:1,:2,:3,:4,:5,:6,:7,:8); end;",
                                              OADBTransaction.DEFAULT);
                                      
                                      stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                                      stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                                      stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                                      stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                                      stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                                      stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                                            
                                      stmtGetCustAddDetails.setInt(1, siteNo);
                                            
                                      //int inAcctSiteId = Integer.parseInt(outParamValue12);
                                      stmtGetCustAddDetails.setString(2, addType);
                                            
                                      stmtGetCustAddDetails.execute();
                                      
                                      addDetails[0] = stmtGetCustAddDetails.getString(3);
                                      addDetails[1] = stmtGetCustAddDetails.getString(4);
                                      addDetails[2] = stmtGetCustAddDetails.getString(5);
                                      addDetails[3] = stmtGetCustAddDetails.getString(6);
                                      addDetails[4] = stmtGetCustAddDetails.getString(7);
                                      addDetails[5] = stmtGetCustAddDetails.getString(8);
                                            
                                      stmtGetCustAddDetails.close();   
                                      
                  } catch (SQLException e) {
                      throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
                  }
                              
                              return addDetails;
    }
    
    public String[] getcustaccount(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {

            String[] resp = new String[2];
                                       CallableStatement sendcustDetails;
                                       try {
                                             OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                                                             sendcustDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.get_Cust_account(:1,:2); end;",
                                                                     OADBTransaction.DEFAULT);


                                                             sendcustDetails.setString(1, CustomerNo);
                                                             sendcustDetails.registerOutParameter(2, Types.VARCHAR);

                                                             sendcustDetails.execute();

                                                             resp[0] = sendcustDetails.getString(2);


                                                             sendcustDetails.close();

                                         } catch (SQLException e) {
                                             throw new OAException("Error While getting Customer Account Error Message:" + e.getMessage(), OAException.INFORMATION);
                                         }

                                                     return resp;

        }
    public String[] getNewCustDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int custNo, String OuId){
                    String[] newCustDetails = new String[6]; 
                    CallableStatement stmtGetCustAddDetails;
        try {
              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_CreditCard_pkg.get_new_cust_details(:1,:2,:3,:4,:5,:6,:7,:8); end;",
                                      OADBTransaction.DEFAULT);
                              
                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                                    
                              stmtGetCustAddDetails.setInt(1, custNo);
                              stmtGetCustAddDetails.setString(2, OuId);     
                              //int inAcctSiteId = Integer.parseInt(outParamValue12);
                              //stmtGetCustAddDetails.setString(2, addType);
                                    
                              stmtGetCustAddDetails.execute();
                              
                              newCustDetails[0] = stmtGetCustAddDetails.getString(3);
                              newCustDetails[1] = stmtGetCustAddDetails.getString(4);
                              newCustDetails[2] = stmtGetCustAddDetails.getString(5);
                              newCustDetails[3] = stmtGetCustAddDetails.getString(6);
                              newCustDetails[4] = stmtGetCustAddDetails.getString(7);
                              newCustDetails[5] = stmtGetCustAddDetails.getString(8);
                              
                              
                                    
                              stmtGetCustAddDetails.close();   
                              
          } catch (SQLException e) {
              throw new OAException("Error while getting new customer details:" + e.getMessage(), OAException.ERROR);
          }
                      
                      return newCustDetails;
    }

	  
	  public String[] UpdateCustomer(OAPageContext pageContext, OAWebBean webBean,String CustomerNo ) {

         String[] resp = new String[2];
                                    CallableStatement sendcustDetails;
                                    try {
                                          OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) pageContext.getApplicationModule(webBean).getOADBTransaction();
                                                          sendcustDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_UpldSync_pkg.create_customer(:1,:2,:3); end;",
                                                                  OADBTransaction.DEFAULT);


                                                          sendcustDetails.registerOutParameter(1, Types.VARCHAR);
                                                          sendcustDetails.registerOutParameter(2, Types.VARCHAR);
                                                          sendcustDetails.setString(3, CustomerNo);

                                                          sendcustDetails.execute();

                                                          resp[0] = sendcustDetails.getString(1);
                                                          resp[1] = sendcustDetails.getString(2);

                                                          sendcustDetails.close();

                                      } catch (SQLException e) {
                                          throw new OAException("Error While Updating the Customer into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                                      }

                                                  return resp;

     }


    
}
