 package ebizch.oracle.apps.fnd.dwld.webui;

 import ebizch.oracle.apps.fnd.dwld.server.CheckBoxVORowImpl;
 import ebizch.oracle.apps.fnd.dwld.server.EbizChdwldAMImpl;
 import ebizch.oracle.apps.fnd.dwld.webui.EbizchWltTransHistCO;
 import java.sql.CallableStatement;
 import java.sql.SQLException;
 import java.text.SimpleDateFormat;
 import java.util.Calendar;
 import java.util.Date;
import oracle.cabo.ui.validate.Formatter;

import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OADecimalValidater;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.OAWebBeanConstants;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.form.OASubmitButtonBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.apps.fnd.framework.webui.beans.table.OATableBean;

import oracle.cabo.style.CSSStyle;
import oracle.cabo.ui.UIConstants;
 import oracle.cabo.ui.data.DataObjectList;
 import oracle.cabo.ui.data.DictionaryData;

 public class EbizchWltTransHistCO extends OAControllerImpl {
   public static final String RCS_ID = "$Header$";
   
   public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header$", "%packagename%");
   
   public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
     super.processRequest(paramOAPageContext, paramOAWebBean);
     EbizChdwldAMImpl ebizChdwldAMImpl = (EbizChdwldAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
     ebizChdwldAMImpl.initEbizchTransHistVO();
     if (!ebizChdwldAMImpl.getCheckBoxVO1().isPreparedForExecution()) {
       ebizChdwldAMImpl.getCheckBoxVO1().executeQuery();
       ebizChdwldAMImpl.getCheckBoxVO1().first();
     } 
     Date date1 = Calendar.getInstance().getTime();
     SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
     String str1 = simpleDateFormat1.format(date1);
     Calendar calendar = Calendar.getInstance();
     calendar.add(5, -60);
     Date date2 = calendar.getTime();
     SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
     String str2 = simpleDateFormat2.format(date2);
      //Amount
       //alignFormatter(paramOAPageContext, paramOAWebBean,"Amount","mit");  
       //alignFormatter(paramOAPageContext, paramOAWebBean,"CustomerId","mst");  	   
       //centerAlignment(paramOAPageContext, paramOAWebBean, "EbizchTransHistVO11", "Amount");
       
                CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                //csNum.setProperty("width", "75px");
                csNum.setProperty("text-align", "right");
              OAMessageTextInputBean omstb1 =
                 (OAMessageTextInputBean)paramOAWebBean.findChildRecursive("Amount");
                omstb1.setInlineStyle(csNum);
				 OAMessageStyledTextBean omstb11 =
                 (OAMessageStyledTextBean)paramOAWebBean.findChildRecursive("CustomerId");
				 omstb11.setInlineStyle(csNum);
   }
   
   public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
     super.processFormRequest(paramOAPageContext, paramOAWebBean);
     EbizChdwldAMImpl ebizChdwldAMImpl = (EbizChdwldAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
     if (paramOAPageContext.getParameter("GWImportTransHist") != null) {
       Date date1 = Calendar.getInstance().getTime();
       SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
       String str1 = simpleDateFormat1.format(date1);
       System.out.println("Converted String: " + str1);
       Calendar calendar = Calendar.getInstance();
       calendar.add(5, -120);
       Date date2 = calendar.getTime();
       SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
       String str2 = simpleDateFormat2.format(date2);
       String[] arrayOfString = getTransactions(paramOAPageContext, paramOAWebBean, str2, str1);
       ebizChdwldAMImpl.initEbizchTransHistVO();
       if (arrayOfString[0] != "E" || !arrayOfString[0].equals("E"))
         throw new OAException("Success: Transaction History downloaded ", (byte)2); 
       throw new OAException("Error: No Data Found on Gateway.", (byte)2);
     } 
     if ("Checked".equals(paramOAPageContext.getParameter("event"))) {
       String str = ((CheckBoxVORowImpl)ebizChdwldAMImpl.getCheckBoxVO1().getCurrentRow()).getVal();
       if ("N".equals(str)) {
         ebizChdwldAMImpl.initEbizchTransHistWhereClauseVO();
         ebizChdwldAMImpl.getCheckBoxVO1().getCurrentRow().setAttribute("Val", "Y");
         OASubmitButtonBean oASubmitButtonBean = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("Checked1");
         oASubmitButtonBean.setText("Include Card Verification Transactions");
       } else {
         ebizChdwldAMImpl.initEbizchTransHistWhereClausenotZeroVO();
         ebizChdwldAMImpl.getCheckBoxVO1().getCurrentRow().setAttribute("Val", "N");
         OASubmitButtonBean oASubmitButtonBean = (OASubmitButtonBean)paramOAWebBean.findChildRecursive("Checked1");
         oASubmitButtonBean.setText("Exclude Card Verification Transactions");
       } 
     } 
   }
   
   public String[] getTransactions(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String paramString1, String paramString2) {
     String[] arrayOfString = new String[2];
     try {
       OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
       CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_transhis_pkg.ins_multiple_transhis_div(:1,:2,:3,:4); end;", -1);
       callableStatement.setString(1, paramString1);
       callableStatement.setString(2, paramString2);
       callableStatement.registerOutParameter(3, 12);
       callableStatement.registerOutParameter(4, 12);
       callableStatement.execute();
       arrayOfString[0] = callableStatement.getString(3);
       arrayOfString[1] = callableStatement.getString(4);
       callableStatement.close();
     } catch (SQLException sQLException) {
       throw new OAException("Error While getting the Transaction Error Message:" + sQLException.getMessage(), (byte)2);
     } 
     return arrayOfString;
   }
                  public  void centerAlignment(OAPageContext pageContext, OAWebBean webBean, String tableRegion, String tableCol)
                   {
                       OATableBean tbl = (OATableBean)webBean.findChildRecursive(tableRegion);
                       //tbl.prepareForRendering(pageContext);
                       DataObjectList dataformat = tbl.getColumnFormats();
                       DictionaryData data = (DictionaryData)dataformat.getItem(pageContext.findChildIndex(tbl, tableCol));
                       data.put(UIConstants.CELL_NO_WRAP_FORMAT_KEY, Boolean.TRUE);
                   }
                   
                   public void alignFormatter(OAPageContext pageContext, OAWebBean webBean,String fieldName,String fieldStyle) {
                       if (fieldStyle.equals("mit"))
                       {
                       OAMessageTextInputBean bean= (OAMessageTextInputBean)webBean.findIndexedChildRecursive(fieldName);
                       if (bean!=null)
                       {
                       //Formatter formatt=new OADecimalValidater("###,###,##0.00", "###,###,##0.00");
                        Formatter formatter =
                                   new OADecimalValidater("#,###,###,##0.00;(#,###,###,##0.00)",    "#,###,###,##0.00;(#,###,###,##0.00)");
                       bean.setAttributeValue(ON_SUBMIT_VALIDATER_ATTR,
                                         formatter);
                       }
                       }
					                          else if (fieldStyle.equals("mst"))
                       {
                       
                           OAMessageStyledTextBean bean= (OAMessageStyledTextBean)webBean.findIndexedChildRecursive(fieldName);
                           if (bean!=null)
                           {
                           //Formatter formatt=new OADecimalValidater("###,###,##0.00", "###,###,##0.00");
                            Formatter formatter =
                                       new OADecimalValidater("#,###,###,##0.00;(#,###,###,##0.00)",    "#,###,###,##0.00;(#,###,###,##0.00)");
                           bean.setAttributeValue(ON_SUBMIT_VALIDATER_ATTR,
                                             formatter);
                           }
                   }
 }
 }