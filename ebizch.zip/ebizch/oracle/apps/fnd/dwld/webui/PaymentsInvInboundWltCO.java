/*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.dwld.webui;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageStyledTextBean;
 import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
 import oracle.jbo.Row;

 import ebizch.oracle.apps.fnd.dwld.server.EbizChdwldAMImpl;
 import ebizch.oracle.apps.fnd.dwld.server.PaymentsInvInboundVOImpl;
 import ebizch.oracle.apps.fnd.dwld.server.PaymentsInvInboundVORowImpl;

 import java.sql.CallableStatement;

 import java.sql.SQLException;

 import java.sql.Types;

 import java.text.DateFormat;

 import java.text.SimpleDateFormat;

 import java.util.Calendar;

 import java.util.Date;
import oracle.cabo.style.CSSStyle;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;

 /**
  * Controller for ...
  */
 public class PaymentsInvInboundWltCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
                am.initPaymentsInvInboundVO();
				//Amountdue1
				//Invoiceamount1
				//Paidamount1
				 CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                csNum.setProperty("text-align", "right");
                OAMessageTextInputBean omstb1 =(OAMessageTextInputBean)webBean.findChildRecursive("Amountdue1");
				OAMessageTextInputBean omstb11 =(OAMessageTextInputBean)webBean.findChildRecursive("Invoiceamount1");
				OAMessageTextInputBean omstb12 =(OAMessageTextInputBean)webBean.findChildRecursive("Paidamount1");
                omstb1.setInlineStyle(csNum);
				omstb11.setInlineStyle(csNum);
				omstb12.setInlineStyle(csNum);
				
   }

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processFormRequest(pageContext, webBean);
         String invNum=""       ;
       if (pageContext.getParameter("Import") != null) {


                 String convStr = getDate(pageContext, webBean);

         Calendar toDate = Calendar.getInstance();
         Calendar fromDate = Calendar.getInstance();
         fromDate.add(Calendar.DAY_OF_YEAR,-1);


         String[] gtPay=getPayments(pageContext, webBean,fromDate.toString(),toDate.toString()) ;

            Date date = Calendar.getInstance().getTime();
           Calendar cal1 = Calendar.getInstance();
           cal1.setTime(date);
           Calendar calendar = Calendar.getInstance();
           calendar.add(Calendar.DATE, -5);
           Date date1 = calendar.getTime();
           Calendar cal2 = Calendar.getInstance();
           cal2.setTime(date1);


		   String[] gtPaysearch=searchTransactionPayments(pageContext, webBean, cal2.toString(), cal1.toString());
		   
           String[] gtPayWebForm=recievePayments(pageContext, webBean, cal2.toString(), cal1.toString());


            EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
           am.initPaymentsInvInboundVO();

           if(gtPay[0]=="S" || gtPay[0].equals("S")){
                     throw new OAException("Success: "+ "Payments have been downloaded ",OAException.INFORMATION );
                 }

                 else
                     {
                     if(gtPaysearch[0]=="S" || gtPaysearch[0].equals("S")){
                               throw new OAException("Success: "+ "Payments have been downloaded ",OAException.INFORMATION );
                           }
                           else
                  {
					   if(gtPayWebForm[0]=="S" || gtPayWebForm[0].equals("S")){
                               throw new OAException("Success: "+ "Payments have been downloaded ",OAException.INFORMATION );
                           }
						   else
						   {throw new OAException("Error: No Data Found on Gateway.", OAException.INFORMATION);}
                     
                 }}
       }



           
     if (pageContext.getParameter("Mark") != null)
        {


            EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
            String messageValue="";
            int error_count = 0;
            int success_count=0;
            
			PaymentsInvInboundVOImpl PayVo = am.getPaymentsInvInboundVO();
            PaymentsInvInboundVORowImpl PayRowVo = null;

              Row rows[] = PayVo.getFilteredRows("ViewAttr", "Y");
              int rowsLength = rows.length;

          
				
             if (rowsLength > 0) {
            for (int i = 0; i < rowsLength; i++) {
             PayRowVo = (PaymentsInvInboundVORowImpl) rows[i];

               String soNo = (String) PayRowVo.getAttribute("Sonum");
               String InvoiceNo = (String) PayRowVo.getAttribute("Invoicenumber");
               String custNo = (String) PayRowVo.getAttribute("Customerid");
               String amt = (String) PayRowVo.getAttribute("Paidamount");
			   String TransactionType= (String) PayRowVo.getAttribute("Paymenttype");
			   
			if ("Auth Only".equals(TransactionType))	
			{
				throw new OAException("Receipt for auth only type transaction cannot be created.",OAException.ERROR);
			}
			else
			{
             if (soNo==InvoiceNo || (soNo.equals(InvoiceNo)) || "No Invoice".equals(InvoiceNo)) { //(soNo.equals(InvoiceNo))
                 if ("null".equals(soNo) || "".equals(soNo))
                 {
               error_count++;
                 }
                 else
                 {
                 String retValue = ebizchmiscreceipts(pageContext,webBean,soNo,Float.parseFloat(amt) ) ;
                 if ("S".equals(retValue))
                       {

                       success_count++;
                       }
                       else
                       {

                              error_count++;
                       }
             }
             }
             else
             {
             

                            invNum= getInvNum(pageContext, webBean,InvoiceNo);

                                         if ("null".equals(invNum) || "".equals(invNum))
                                         {

                                                error_count++;
                                         }
                                        else
                                        {

                                          String retValue =ebizchreceipts(pageContext,webBean,invNum);

                                   if ("S".equals(retValue))
                                         {

                                         success_count++;
                                         }
                                         else
                                         {

                                                error_count++;
                                         }
                                         }


         
                }
			}
            }

             if (success_count < 1 && error_count > 0)
                         {
                       //  if (invNum==null || invNum=="")
                                      //    {
                                      //     throw new OAException(error_count+" receipts has not been created.Because invoice is not found in oracle ", OAException.ERROR);

                                    //      }
                                     //     else
                                      //    {
                                                am.initPaymentsInvInboundVO();
                                                throw new OAException(error_count+" receipt has not been created. ", OAException.ERROR);

                                    //      }
                         }
                          else if (success_count > 0 && error_count < 1)
                          {
                                                           am.initPaymentsInvInboundVO();
                                throw new OAException(success_count+" receipt has been created. ", OAException.INFORMATION);

                          }
                         else if (success_count>0 && error_count>0)
                   {
                      am.initPaymentsInvInboundVO();
                       throw new OAException(success_count+" receipts has been created. & " + error_count + "  receipts has not been created.", OAException.INFORMATION);
                    }
                  else if(success_count>0 && error_count==0)
                  {
                      am.initPaymentsInvInboundVO();
                      throw new OAException(success_count+" receipts has been created. ", OAException.INFORMATION);
                   }
                  else if(success_count<=0 && error_count>1)
                  {
                      am.initPaymentsInvInboundVO();

                      throw new OAException(error_count+" receipts has not been created. ", OAException.ERROR);
                   }
                    else{
                        throw new OAException("Receipts has not been created.", OAException.ERROR);
                                     }
          }
        }
           ////////////////////////////////////////////////////////////////
       }


  public String[] getPayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pFromDate, String pToDate){
                  String[] Details = new String[2];
                  CallableStatement stmtAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.get_multi_payments_div(:1,:2,:3,:4); end;",
                                                OADBTransaction.DEFAULT);



                                        stmtAddDetails.setString(1, pFromDate);
                                        stmtAddDetails.setString(2, pToDate);
                                        stmtAddDetails.registerOutParameter(3, Types.VARCHAR);
                                        stmtAddDetails.registerOutParameter(4, Types.VARCHAR);

                                        stmtAddDetails.execute();

                                        Details[0] = stmtAddDetails.getString(3);
                                        Details[1] = stmtAddDetails.getString(4);

                                        stmtAddDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While getting the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return Details;
      }
           public String[] recievePayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pFromDate, String pToDate){
                  String[] Details = new String[2];
                  CallableStatement stmtAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.get_multi_Rcv_payments_div(:1,:2,:3,:4); end;",
                                                OADBTransaction.DEFAULT);



                                        stmtAddDetails.setString(1, pFromDate);
                                        stmtAddDetails.setString(2, pToDate);
                                        stmtAddDetails.registerOutParameter(3, Types.VARCHAR);
                                        stmtAddDetails.registerOutParameter(4, Types.VARCHAR);

                                        stmtAddDetails.execute();

                                        Details[0] = stmtAddDetails.getString(3);
                                        Details[1] = stmtAddDetails.getString(4);

                                        stmtAddDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While getting the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return Details;
      }
 public String[] searchTransactionPayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pFromDate, String pToDate){
                  String[] Details = new String[2];
                  CallableStatement stmtAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.insert_transaction_resp(:1,:2,:3,:4,:5); end;",
                                                OADBTransaction.DEFAULT);


										 stmtAddDetails.setString(1, "");
                                        stmtAddDetails.setString(2, pFromDate);
                                        stmtAddDetails.setString(3, pToDate);
                                        stmtAddDetails.registerOutParameter(4, Types.VARCHAR);
                                        stmtAddDetails.registerOutParameter(5, Types.VARCHAR);

                                        stmtAddDetails.execute();

                                        Details[0] = stmtAddDetails.getString(4);
                                        Details[1] = stmtAddDetails.getString(5);

                                        stmtAddDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While getting the payments from search transactions. Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return Details;
      }
 public String getDate(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean)
    {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
        SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        EbizChdwldAMImpl am =
           (EbizChdwldAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
        oracle.jbo.domain.Date convertDate = am.getOADBTransaction().getCurrentDBDate();
        convertDate.addMonths(1);
        java.util.Date date;
        try{
        date = format.parse(convertDate.toString());

        }
        catch(Exception e)
        {
            throw new OAException("Get Date: " + e.getMessage(),
                                  OAException.ERROR);
        }

        String convStr = formatDate.format(date);
        return convStr;
    }
    public String ebizchreceipts(OAPageContext paramOAPageContext,
                                         OAWebBean paramOAWebBean,String invnum ) {

            CallableStatement stmtInertGwPayToLocaldb;
            try {
                OADBTransactionImpl txnGetPayAddDetails =
                    (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();

                stmtInertGwPayToLocaldb =
                                   txnGetPayAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.EBIZ_CASH_RECEIPTS_vone(:1,:2); end;",
                                                                               OADBTransaction.DEFAULT);
             stmtInertGwPayToLocaldb.registerOutParameter(2,Types.VARCHAR);
                stmtInertGwPayToLocaldb.setString(1, invnum);
                stmtInertGwPayToLocaldb.execute();
                String retValue=stmtInertGwPayToLocaldb.getString(2);
                stmtInertGwPayToLocaldb.close();
                 return retValue;
            } catch (SQLException e) {
                throw new OAException("Error from database: " + e.getMessage(),
                                      OAException.ERROR);
            }
        }
  public String[] aplPayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNo, String invNum){
                  String[] Details = new String[2];
                  CallableStatement stmtAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.Applied_payments(:1,:2,:3,:4,:5); end;",
                                                OADBTransaction.DEFAULT);



                                        stmtAddDetails.setString(1, custNo);
                                        stmtAddDetails.setString(2, invNum);
                                                                                 stmtAddDetails.setString(3, "");
                                        stmtAddDetails.registerOutParameter(4, Types.VARCHAR);
                                        stmtAddDetails.registerOutParameter(5, Types.VARCHAR);

                                        stmtAddDetails.execute();

                                        Details[0] = stmtAddDetails.getString(4);
                                        Details[1] = stmtAddDetails.getString(5);

                                        stmtAddDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While applying the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return Details;
      }

          public String getInvNum(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String invNum){
                  String retVal;
                  CallableStatement stmtAddDetails;
                  try {
                        OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                        stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.get_inv_num(:1,:2); end;",
                                                OADBTransaction.DEFAULT);


                                        stmtAddDetails.setString(1, invNum);
                                                                                stmtAddDetails.registerOutParameter(2, Types.VARCHAR);


                                        stmtAddDetails.execute();

                                        retVal= stmtAddDetails.getString(2);


                                        stmtAddDetails.close();

                    } catch (SQLException e) {
                        throw new OAException("Error While getting the Invoice Number Error Message:" + e.getMessage(), OAException.INFORMATION);
                    }

                                return retVal;
      }

     public String ebizchmiscreceipts(OAPageContext paramOAPageContext,
                                          OAWebBean paramOAWebBean,String soNum,float amount ) {

             CallableStatement stmtInertGwPayToLocaldb;
             try {
                 OADBTransactionImpl txnGetPayAddDetails =
                     (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();

                 stmtInertGwPayToLocaldb =
                                    txnGetPayAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.create_misc_receipts(:1,:2,:3); end;",
                                                                                OADBTransaction.DEFAULT);
              stmtInertGwPayToLocaldb.registerOutParameter(3,Types.VARCHAR);
                 stmtInertGwPayToLocaldb.setString(1, soNum);
                 stmtInertGwPayToLocaldb.setFloat(2, amount);
                 stmtInertGwPayToLocaldb.execute();
                 String retValue=stmtInertGwPayToLocaldb.getString(3);
                 stmtInertGwPayToLocaldb.close();
                  return retValue;
             } catch (SQLException e) {
                 throw new OAException("Error from database: " + e.getMessage(),
                                       OAException.ERROR);
             }
         }
 }