 /*===========================================================================+
  |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
  |                         All rights reserved.                              |
  +===========================================================================+
  |  HISTORY                                                                  |
  +===========================================================================*/
 package ebizch.oracle.apps.fnd.dwld.webui;


 import java.sql.CallableStatement;
 import java.sql.SQLException;


 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;

 import ebizch.oracle.apps.fnd.dwld.server.EbizChdwldAMImpl;
 import ebizch.oracle.apps.fnd.dwld.server.PaymentsInboundVOImpl;
 import ebizch.oracle.apps.fnd.dwld.server.PaymentsInboundVORowImpl;

import java.sql.Types;

import java.util.Calendar;
import java.util.Date;

/**
 * Controller for ...
 */
 public class PaymentsInboundCO extends OAControllerImpl
 {
   public static final String RCS_ID="$Header$";
   public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

   /**
    * Layout and page setup logic for a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processRequest(pageContext, webBean);
       
         EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
         am.initPaymentsInboundVO();
      
   }
   

   /**
    * Procedure to handle form submissions for form elements in
    * a region.
    * @param pageContext the current OA page context
    * @param webBean the web bean corresponding to the region
    */
   public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
   {
     super.processFormRequest(pageContext, webBean);
      
       /*   if (pageContext.getParameter("GwPayUploadBtn") != null) {
                    
                  PaymentsInboundInfo GWPaymentInfo = new PaymentsInboundInfo();
                  String convStr = GWPaymentInfo.getDate(pageContext, webBean);

          Calendar toDate = Calendar.getInstance();
          Calendar fromDate = Calendar.getInstance();  
          fromDate.add(Calendar.DAY_OF_YEAR,-1);
                  
                  
          String[] gtPay=getPayments(pageContext, webBean,fromDate.toString(),toDate.toString()) ;
                  
             Date date = Calendar.getInstance().getTime();  
            Calendar cal1 = Calendar.getInstance();
            cal1.setTime(date);
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE, -5);                                         
            Date date1 = calendar.getTime();  
            Calendar cal2 = Calendar.getInstance();
            cal2.setTime(date1);
                    
            String[] gtPayWebForm=recievePayments(pageContext, webBean, cal2.toString(), cal1.toString());
                  
          
             EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
            am.initPaymentsInboundVO();
            
            if(gtPay[0]=="S" || gtPay[0].equals("S")){
                      throw new OAException("Success: "+ "Payments are downloaded ",OAException.INFORMATION );
                  }
                
                  else 
                      {
                      if(gtPayWebForm[0]=="S" || gtPayWebForm[0].equals("S")){
                                throw new OAException("Success: "+ "Payments are downloaded ",OAException.INFORMATION );
                            }
                            else
                   {
                      throw new OAException("Error: No Data Found on Gateway.", OAException.INFORMATION);
                  }}
        }
      
  if (pageContext.getParameter("GWMarkPayment") != null) 
          {
                
               EbizChdwldAMImpl am = (EbizChdwldAMImpl)pageContext.getApplicationModule(webBean);
              String messageValue="";
              int error_count = 0;
              PaymentsInboundVOImpl PayVo = am.getPaymentsInboundVO();
              PaymentsInboundVORowImpl PayRowVo = null;
        
                Row rows[] = PayVo.getFilteredRows("ViewAttr", "Y");
                int rowsLength = rows.length;

               if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
               PayRowVo = (PaymentsInboundVORowImpl) rows[i];
                   
                String InvoiceNo = (String) PayRowVo.getAttribute("Invoicenumber");
                String Payment_InternalID = (String) PayRowVo.getAttribute("Paymentinternalid");
                  String[] validationsMessage = isValidate(InvoiceNo,Payment_InternalID);

                  if (validationsMessage[0].equals("1")) {
                    messageValue = messageValue + validationsMessage[1];
                  }
                     
                  if (validationsMessage[0].equals("1")){
                     error_count++; 
                  }
                  else{
                try{
                  String[] appPayments=applyPayments(pageContext,webBean, InvoiceNo, Payment_InternalID);
                 
                   if(appPayments[0].equals("S") || appPayments[0]=="S"){
                       
                                           throw new OAException("Payment(s)successfully applied to invoice(s)",OAException.INFORMATION );
                                           }
                                           else
                                           {
                                           
                                                   throw new OAException("Payment(s) not applied to invoice(s)",OAException.ERROR );
                                           }
                                                  
                                           
                  // }
                   //else{
                   //     throw new OAException("Payment not Marked due to to: "+appPayments[1],OAException.ERROR ); 
                  // }
                  
               }
                catch(Exception e){
                          throw new OAException("ERROR: "+ e.getMessage(),OAException.ERROR );
                      }
                  }
              }        
            
            }
          }*/
    
   }
    public String[] getPayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pFromDate, String pToDate){
                   String[] Details = new String[2]; 
                   CallableStatement stmtAddDetails;
                   try {
                         OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                         stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.get_payments(:1,:2,:3,:4); end;",
                                                 OADBTransaction.DEFAULT);
                                         
                                         
                                               
                                         stmtAddDetails.setString(1, pFromDate);
                                                                             stmtAddDetails.setString(2, pFromDate);
                                         stmtAddDetails.registerOutParameter(3, Types.VARCHAR);
                                         stmtAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                                             
                                         stmtAddDetails.execute();
                                         
                                         Details[0] = stmtAddDetails.getString(3);
                                         Details[1] = stmtAddDetails.getString(4);
                                                                             
                                         stmtAddDetails.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error While getting the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                     }
                                 
                                 return Details;
       } 
            public String[] recievePayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pFromDate, String pToDate){
                   String[] Details = new String[2]; 
                   CallableStatement stmtAddDetails;
                   try {
                         OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                         stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.Receive_payments(:1,:2,:3,:4); end;",
                                                 OADBTransaction.DEFAULT);
                                         
                                         
                                               
                                         stmtAddDetails.setString(1, pFromDate);
                                                                             stmtAddDetails.setString(2, pFromDate);
                                         stmtAddDetails.registerOutParameter(3, Types.VARCHAR);
                                         stmtAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                                             
                                         stmtAddDetails.execute();
                                         
                                         Details[0] = stmtAddDetails.getString(3);
                                         Details[1] = stmtAddDetails.getString(4);
                                                                             
                                         stmtAddDetails.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error While getting the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                     }
                                 
                                 return Details;
       } 
             public String[] applyPayments(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String pInvoiceNumber, String pPaymentIntId){
                   String[] Details = new String[2]; 
                   CallableStatement stmtAddDetails;
                   try {
                         OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                         stmtAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_dwld_pkg.Applied_payments(:1,:2,:3,:4); end;",
                                                 OADBTransaction.DEFAULT);
                                         
                                         
                                               
                                         stmtAddDetails.setString(1, pInvoiceNumber);
                                                                             stmtAddDetails.setString(2, pPaymentIntId);
                                         stmtAddDetails.registerOutParameter(3, Types.VARCHAR);
                                         stmtAddDetails.registerOutParameter(4, Types.VARCHAR);
                                                                             
                                         stmtAddDetails.execute();
                                         
                                         Details[0] = stmtAddDetails.getString(3);
                                         Details[1] = stmtAddDetails.getString(4);
                                                                             
                                         stmtAddDetails.close();   
                                         
                     } catch (SQLException e) {
                         throw new OAException("Error While Applying the payment Error Message:" + e.getMessage(), OAException.INFORMATION);
                     }
                                 
                                 return Details;
       } 
      public String[] isValidate(String InvoiceNo,String Payment_InternalID) {
        String retMessage = "";
        String retValue = "null";
        String[] output = new String[2];
        output[0] = "0";
        if ("null".equals(String.valueOf(InvoiceNo)) || "".equals(String.valueOf(InvoiceNo))) {
          retMessage = retMessage + "Customer No,";
        }

        if ("null".equals(String.valueOf(Payment_InternalID)) || "".equals(String.valueOf(Payment_InternalID))) {
          retMessage = retMessage + "Payment Internal Id,";
        }

       
        if (retMessage!="") {
          output[0] = "1";
          retValue = retMessage + "are not found against your selected Invoice No" + " : " + InvoiceNo + " . ";
          output[1] = retValue;
        } else if (retMessage=="") {

          output[0] = "0";
          output[1] = "Data is validated.";
        }
        return output;
      }
 }
