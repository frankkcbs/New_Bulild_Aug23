package ebizch.oracle.apps.fnd.dwld.server;
import ebizch.oracle.apps.fnd.dwld.server.CheckBoxVOImpl;
import ebizch.oracle.apps.fnd.dwld.server.CustomeWLTLOVImpl;
import ebizch.oracle.apps.fnd.dwld.server.EbizChdwldAMImpl;
import ebizch.oracle.apps.fnd.dwld.server.EbizchTransHistVOImpl;
import ebizch.oracle.apps.fnd.dwld.server.PaymentsInboundVOImpl;
import ebizch.oracle.apps.fnd.dwld.server.PaymentsInvInboundVOImpl;
import ebizch.oracle.apps.fnd.dwld.server.StatusWalletVOImpl;
import ebizch.oracle.apps.fnd.dwld.server.TypeWalletVOImpl;
import oracle.apps.fnd.framework.server.OAApplicationModuleImpl;

public class EbizChdwldAMImpl extends OAApplicationModuleImpl {
  public static void main(String[] paramArrayOfString) {
    launchTester("ebizch.oracle.apps.fnd.ach.server", "EbizChAchAMLocal");
  }
  
  public EbizchTransHistVOImpl getEbizchTransHistVO1() {
    return (EbizchTransHistVOImpl)findViewObject("EbizchTransHistVO1");
  }
  
  public void initEbizchTransHistVO() {
    EbizchTransHistVOImpl ebizchTransHistVOImpl = getEbizchTransHistVO1();
    ebizchTransHistVOImpl.executeQuery();
  }
  
  public void initEbizchTransHistWhereClauseVO() {
    EbizchTransHistVOImpl ebizchTransHistVOImpl = getEbizchTransHistVO1();
    String str = "0.05";
    ebizchTransHistVOImpl.setWhereClause("AMOUNT <> " + str);
    ebizchTransHistVOImpl.executeQuery();
  }
  
  public void initEbizchTransHistWhereClausenotZeroVO() {
    EbizchTransHistVOImpl ebizchTransHistVOImpl = getEbizchTransHistVO1();
   // String str = "0.05";
    //ebizchTransHistVOImpl.setWhereClause("AMOUNT = " + str);
	ebizchTransHistVOImpl.setWhereClause(null);
    ebizchTransHistVOImpl.executeQuery();
  }
  
  public PaymentsInboundVOImpl getPaymentsInboundVO() {
    return (PaymentsInboundVOImpl)findViewObject("PaymentsInboundVO");
  }
  
  public PaymentsInvInboundVOImpl getPaymentsInvInboundVO() {
    return (PaymentsInvInboundVOImpl)findViewObject("PaymentsInvInboundVO");
  }
  
  public void initPaymentsInvInboundVO() {
    PaymentsInvInboundVOImpl paymentsInvInboundVOImpl = getPaymentsInvInboundVO();
    paymentsInvInboundVOImpl.executeQuery();
  }
  
  public void initPaymentsInboundVO() {
    PaymentsInboundVOImpl paymentsInboundVOImpl = getPaymentsInboundVO();
    paymentsInboundVOImpl.executeQuery();
  }
  
  public CheckBoxVOImpl getCheckBoxVO1() {
    return (CheckBoxVOImpl)findViewObject("CheckBoxVO1");
  }
  
  public StatusWalletVOImpl getStatusWalletVO1() {
    return (StatusWalletVOImpl)findViewObject("StatusWalletVO1");
  }
  
  public TypeWalletVOImpl getTypeWalletVO1() {
    return (TypeWalletVOImpl)findViewObject("TypeWalletVO1");
  }
  
  public CustomeWLTLOVImpl getCustomeWLTLOV1() {
    return (CustomeWLTLOVImpl)findViewObject("CustomeWLTLOV1");
  }
}
