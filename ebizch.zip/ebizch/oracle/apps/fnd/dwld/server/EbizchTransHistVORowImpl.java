package ebizch.oracle.apps.fnd.dwld.server;

import ebizch.oracle.apps.fnd.dwld.server.EbizchTransHistVORowImpl;
import oracle.apps.fnd.framework.server.OAViewRowImpl;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.AttributeDefImpl;

public class EbizchTransHistVORowImpl extends OAViewRowImpl {
  public static final int TRANSACTIONDATE = 0;
  
  public static final int OPERATINGUNIT = 1;
  
  public static final int CUSTOMERID = 2;
  
  public static final int CUSTOMERNUMBER = 3;
  
  public static final int CUSTOMERNAME = 4;
  
  public static final int AMOUNT = 5;
  
  public static final int PAYMENTMETHOD = 6;
  
  public static final int TRANSACTIONTYPE = 7;
  
  public static final int STATUS = 8;
  
  public static final int AUTHCODE = 9;
  
  public static final int REFERENCE = 10;
  
  public static final int RESULT = 11;
  
  public static final int SOURCE = 12;
  
  public static final int ACTIONTAKEN = 13;
  
  public static final int CREATEDBY = 14;
  
  public static final int CREATIONDATE = 15;
  
  public static final int LASTUPDATEDBY = 16;
  
  public static final int LASTUPDATEDATE = 17;
  
  public static final int LASTUPDATELOGIN = 18;
  
  public static final int ORDERNO = 19;
  
  public static final int INVOICE = 20;
  
  public static final int VIEWATTR = 21;
  
  public Date getTransactionDate() {
    return (Date)getAttributeInternal(0);
  }
  
  public void setTransactionDate(Date paramDate) {
    setAttributeInternal(0, paramDate);
  }
  
  public String getOperatingUnit() {
    return (String)getAttributeInternal(1);
  }
  
  public void setOperatingUnit(String paramString) {
    setAttributeInternal(1, paramString);
  }
  
  public Number getCustomerId() {
    return (Number)getAttributeInternal(2);
  }
  
  public void setCustomerId(Number paramNumber) {
    setAttributeInternal(2, paramNumber);
  }
  
  public String getCustomerNumber() {
    return (String)getAttributeInternal(3);
  }
  
  public void setCustomerNumber(String paramString) {
    setAttributeInternal(3, paramString);
  }
  
  public String getCustomerName() {
    return (String)getAttributeInternal(4);
  }
  
  public void setCustomerName(String paramString) {
    setAttributeInternal(4, paramString);
  }
  
  public String getAmount() {
    return (String)getAttributeInternal(5);
  }
  
  public void setAmount(String paramNumber) {
    setAttributeInternal(5, paramNumber);
  }
  
  public String getPaymentMethod() {
    return (String)getAttributeInternal(6);
  }
  
  public void setPaymentMethod(String paramString) {
    setAttributeInternal(6, paramString);
  }
  
  public String getTransactionType() {
    return (String)getAttributeInternal(7);
  }
  
  public void setTransactionType(String paramString) {
    setAttributeInternal(7, paramString);
  }
  
  public String getStatus() {
    return (String)getAttributeInternal(8);
  }
  
  public void setStatus(String paramString) {
    setAttributeInternal(8, paramString);
  }
  
  public String getAuthCode() {
    return (String)getAttributeInternal(9);
  }
  
  public void setAuthCode(String paramString) {
    setAttributeInternal(9, paramString);
  }
  
  public String getReference() {
    return (String)getAttributeInternal(10);
  }
  
  public void setReference(String paramString) {
    setAttributeInternal(10, paramString);
  }
  
  public String getResult() {
    return (String)getAttributeInternal(11);
  }
  
  public void setResult(String paramString) {
    setAttributeInternal(11, paramString);
  }
  
  public String getSource() {
    return (String)getAttributeInternal(12);
  }
  
  public void setSource(String paramString) {
    setAttributeInternal(12, paramString);
  }
  
  public String getActionTaken() {
    return (String)getAttributeInternal(13);
  }
  
  public void setActionTaken(String paramString) {
    setAttributeInternal(13, paramString);
  }
  
  public Number getCreatedBy() {
    return (Number)getAttributeInternal(14);
  }
  
  public void setCreatedBy(Number paramNumber) {
    setAttributeInternal(14, paramNumber);
  }
  
  public Date getCreationDate() {
    return (Date)getAttributeInternal(15);
  }
  
  public void setCreationDate(Date paramDate) {
    setAttributeInternal(15, paramDate);
  }
  
  public Number getLastUpdatedBy() {
    return (Number)getAttributeInternal(16);
  }
  
  public void setLastUpdatedBy(Number paramNumber) {
    setAttributeInternal(16, paramNumber);
  }
  
  public Date getLastUpdateDate() {
    return (Date)getAttributeInternal(17);
  }
  
  public void setLastUpdateDate(Date paramDate) {
    setAttributeInternal(17, paramDate);
  }
  
  public Number getLastUpdateLogin() {
    return (Number)getAttributeInternal(18);
  }
  
  public void setLastUpdateLogin(Number paramNumber) {
    setAttributeInternal(18, paramNumber);
  }
  
  protected Object getAttrInvokeAccessor(int paramInt, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        return getTransactionDate();
      case 1:
        return getOperatingUnit();
      case 2:
        return getCustomerId();
      case 3:
        return getCustomerNumber();
      case 4:
        return getCustomerName();
      case 5:
        return getAmount();
      case 6:
        return getPaymentMethod();
      case 7:
        return getTransactionType();
      case 8:
        return getStatus();
      case 9:
        return getAuthCode();
      case 10:
        return getReference();
      case 11:
        return getResult();
      case 12:
        return getSource();
      case 13:
        return getActionTaken();
      case 14:
        return getCreatedBy();
      case 15:
        return getCreationDate();
      case 16:
        return getLastUpdatedBy();
      case 17:
        return getLastUpdateDate();
      case 18:
        return getLastUpdateLogin();
      case 19:
        return getOrderno();
      case 20:
        return getInvoice();
      case 21:
        return getViewAttr();
    } 
    return super.getAttrInvokeAccessor(paramInt, paramAttributeDefImpl);
  }
  
  protected void setAttrInvokeAccessor(int paramInt, Object paramObject, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        setTransactionDate((Date)paramObject);
        return;
      case 1:
        setOperatingUnit((String)paramObject);
        return;
      case 2:
        setCustomerId((Number)paramObject);
        return;
      case 3:
        setCustomerNumber((String)paramObject);
        return;
      case 4:
        setCustomerName((String)paramObject);
        return;
      case 5:
        setAmount((String)paramObject);
        return;
      case 6:
        setPaymentMethod((String)paramObject);
        return;
      case 7:
        setTransactionType((String)paramObject);
        return;
      case 8:
        setStatus((String)paramObject);
        return;
      case 9:
        setAuthCode((String)paramObject);
        return;
      case 10:
        setReference((String)paramObject);
        return;
      case 11:
        setResult((String)paramObject);
        return;
      case 12:
        setSource((String)paramObject);
        return;
      case 13:
        setActionTaken((String)paramObject);
        return;
      case 14:
        setCreatedBy((Number)paramObject);
        return;
      case 15:
        setCreationDate((Date)paramObject);
        return;
      case 16:
        setLastUpdatedBy((Number)paramObject);
        return;
      case 17:
        setLastUpdateDate((Date)paramObject);
        return;
      case 18:
        setLastUpdateLogin((Number)paramObject);
        return;
      case 19:
        setOrderno((String)paramObject);
        return;
      case 20:
        setInvoice((String)paramObject);
        return;
      case 21:
        setViewAttr((String)paramObject);
        return;
    } 
    super.setAttrInvokeAccessor(paramInt, paramObject, paramAttributeDefImpl);
  }
  
  public String getViewAttr() {
    return (String)getAttributeInternal(21);
  }
  
  public void setViewAttr(String paramString) {
    setAttributeInternal(21, paramString);
  }
  
  public String getOrderno() {
    return (String)getAttributeInternal(19);
  }
  
  public void setOrderno(String paramString) {
    setAttributeInternal(19, paramString);
  }
  
  public String getInvoice() {
    return (String)getAttributeInternal(20);
  }
  
  public void setInvoice(String paramString) {
    setAttributeInternal(20, paramString);
  }
}
