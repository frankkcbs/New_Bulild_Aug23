package ebizch.oracle.apps.fnd.comm.webui;

import java.sql.CallableStatement;
import java.sql.Types;

import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

public class EbizChargeOrclTokenCall {

private String securityId, userName, password, rtCust, rtItem, rtInvoice, rtSaleOrder, errMsg;


    public EbizChargeOrclTokenCall(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
        OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
        CallableStatement callableStatement =  txn.createCallableStatement("begin  EBIZCH_COMMON_PKG.GET_TOKENDETAILS(:1,:2,:3,:4,:5,:6,:7,:8); end;", 
                                                         OADBTransaction.DEFAULT);
           try { 
             callableStatement.registerOutParameter(2, Types.VARCHAR);  
             callableStatement.registerOutParameter(3, Types.VARCHAR);  
             callableStatement.registerOutParameter(4, Types.VARCHAR);  
             callableStatement.registerOutParameter(5, Types.VARCHAR);  
             callableStatement.registerOutParameter(6, Types.VARCHAR);
             callableStatement.registerOutParameter(7, Types.VARCHAR);  
             callableStatement.registerOutParameter(8, Types.VARCHAR);
             int inOrgId = paramOAPageContext.getOrgId();
             callableStatement.setInt(1, inOrgId);
           
           
             callableStatement.execute();  
           
             securityId = callableStatement.getString(2);  
             userName = callableStatement.getString(3);  
             password = callableStatement.getString(4);  
             rtCust = callableStatement.getString(5);  
             rtItem = callableStatement.getString(6);
             rtInvoice = callableStatement.getString(7);  
             rtSaleOrder = callableStatement.getString(8);   
             
             callableStatement.close();                                                  
           }
           catch(Exception e){
           errMsg = e.getMessage();
           }   

    }
    public String getsecurityId()
    {
        return securityId;
    }
    public String getuserName()
    {
        return userName;
    }
    public String getpassword()
    {
        return password;
    }
    public String getrtCust()
    {
        return rtCust;
    }
    public String getrtItem()
    {
        return rtItem;
    }
    public String getrtInvoice()
    {
        return rtInvoice;
    }
    public String getrtSaleOrder()
    {
        return rtSaleOrder;
    }
}
