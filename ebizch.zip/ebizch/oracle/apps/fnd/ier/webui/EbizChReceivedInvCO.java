package ebizch.oracle.apps.fnd.ier.webui;


import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;

import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;

import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvResendVOImpl;
import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvResendVORowImpl;
import ebizch.oracle.apps.fnd.ier.server.EbizChReceivedInvVOImpl;
import ebizch.oracle.apps.fnd.ier.server.EbizChReceivedInvVORowImpl;

import oracle.jbo.Row;
import oracle.jbo.domain.Number;

import java.text.DateFormat;

import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;


public class EbizChReceivedInvCO extends OAControllerImpl
{

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
      

	
		   Date date = Calendar.getInstance().getTime();
           Calendar cal1 = Calendar.getInstance();
           cal1.setTime(date);
		   
           Calendar cal2 = Calendar.getInstance();
           cal2.add(Calendar.YEAR, -1);
           Date date1 = cal2.getInstance().getTime();
           cal2.setTime(date1);
	 	   
      
      
	  String[] pendinEmail = new String[2]; 
     pendinEmail =received_webform_email(pageContext, webBean,cal2.toString(), cal1.toString());
     
     am.initEbizChReceivedInvVO();
      
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
	   

    super.processFormRequest(pageContext, webBean);
  
  }	
      
    public String[] received_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String to_date ,String from_Date){
         CallableStatement stmtaddTemplate;
                        String[] addDetails = new String[2]; 
              try {
                     OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.Receive_payments_email_inv(:1,:2,:3,:4,:5); end;", OADBTransaction.DEFAULT);
                          stmtaddTemplate.setString(1, "");
						 stmtaddTemplate.setString(2, to_date);
                         stmtaddTemplate.setString(3, from_Date); 
                         stmtaddTemplate.registerOutParameter(4, Types.VARCHAR);
                         stmtaddTemplate.registerOutParameter(5, Types.VARCHAR);
                         
                         
                     stmtaddTemplate.execute();
                       addDetails[0] = stmtaddTemplate.getString(4);
                       addDetails[1] = stmtaddTemplate.getString(5);
                     stmtaddTemplate.close();   
                                    
                } catch (SQLException e) {
                    throw new OAException("Exception in received_webform_email: " + e.getMessage(), OAException.ERROR);
                }
                            
         return addDetails;
    }  
      
      
      
    public String[] isValidate(String invnum,int inSentCount  , int inPendingReqIdNumb) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
      if ("".equals(String.valueOf(inSentCount))) {
        retMessage = retMessage + "Sent Count,";
      }
   
      if ("".equals(String.valueOf(inPendingReqIdNumb)) || String.valueOf(inPendingReqIdNumb) == null) {
        retMessage = retMessage + "Pending Req Id,";
      }

      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invnum;
        output[1] = retValue;
		output[2] = invnum;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Data is validated.";
		output[3] = invnum;
      }
      return output;
    }
       
    
     public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   }
    
}
