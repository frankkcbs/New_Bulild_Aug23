package ebizch.oracle.apps.fnd.ier.webui;


import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;

import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;

import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvResendVOImpl;
import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvResendVORowImpl;
import ebizch.oracle.apps.fnd.ier.server.EbizChPendingInvResendVOImpl;
import ebizch.oracle.apps.fnd.ier.server.EbizChPendingInvResendVORowImpl;

import oracle.jbo.Row;
import oracle.jbo.domain.Number;

import java.text.DateFormat;

import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;


public class EbizChPendingInvResendCO extends OAControllerImpl
{

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
      EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
      deleteMail(pageContext, webBean);

	 // Calendar to_Date = Calendar.getInstance();
     // Calendar From_date = Calendar.getInstance();  
     // From_date.add(Calendar.DAY_OF_YEAR,-1);
	  
		   Date date = Calendar.getInstance().getTime();
           Calendar cal1 = Calendar.getInstance();
           cal1.setTime(date);
		   
           Calendar cal2 = Calendar.getInstance();
           cal2.add(Calendar.YEAR, -1);
           Date date1 = cal2.getInstance().getTime();
           cal2.setTime(date1);
	 	   
      
      
	  String[] pendinEmail = new String[2]; 
     pendinEmail =pending_webform_email(pageContext, webBean,cal2.toString(), cal1.toString());
     
     am.initEbizChPendingInvResendVO();
      
  }


  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
	   if (pageContext.getParameter("resendEmailInvBtn1") != null) {

          EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
          EbizChPendingInvResendVOImpl custVo = am.getEbizChPendingInvResendVO1();
          EbizChPendingInvResendVORowImpl payMethodPendingVo = null;
          String excCollectAdd = " ";
          
          Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = rows.length;
			String invNums="";  
		    String SucinvNums="";
          String inUrlId="";
          String inSentCount="";
          String inUrlIdStr = "";
	       String messageValue="";
	       int error_count = 0;
		  int requestSentCount=0;
          
          if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  payMethodPendingVo = (EbizChPendingInvResendVORowImpl) rows[i];
                  
                  
                  Number inPendingReqIdNumb = (Number) payMethodPendingVo.getAttribute("InvSentId");
                  String inPendingReqIdString = inPendingReqIdNumb.toString();
                  int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                  
                  String CustNumVal = (String) payMethodPendingVo.getAttribute("CustNum");
		          String PayIntId = (String) payMethodPendingVo.getAttribute("PayIntId");		  
				  String invnum = (String) payMethodPendingVo.getAttribute("InvNum");//

                  
				  if (payMethodPendingVo.getAttribute("SentCount") != null){
					inSentCount = (String) payMethodPendingVo.getAttribute("SentCount");
				  }
				  else{
					inSentCount = "0";
				  }
                  
                  int inSentCountInt = Integer.parseInt(inSentCount);
                  inSentCountInt = inSentCountInt + 1;
				  String countIncStr = Integer.toString(inSentCountInt);
                  
                  String[] validationsMessage = isValidate(invnum,inSentCountInt ,inPendingReqIdInt);

                   if (validationsMessage[0].equals("1")) {
                     messageValue = messageValue + validationsMessage[1];
                   invNums =validationsMessage[2]+", "+invNums;
			      }
				  else
				   {
					  SucinvNums =validationsMessage[3]+", "+SucinvNums;  
				   }
                       /*New Code by hamza*/
                   if (validationsMessage[0].equals("1")){
                      error_count++; 
                   }
                   else{
		 
                  String[] resendEmail=resend_webform_email(pageContext, webBean,CustNumVal ,PayIntId,  inPendingReqIdString,countIncStr);
                   
                  if(resendEmail[0].equals("S")) {
                      requestSentCount++;
                  }else{
					  error_count++;
                     
                  }
                   }
                  
                  
              }
			 messageValue = getDistinctString(pageContext,webBean,messageValue);
             if(requestSentCount>0 && error_count>0){
				 am.initEbizChPendingInvResendVO();
                // throw new OAException(requestSentCount+" request(s) sent successfully. " + error_count + " request(s) not sent successfully " +" Beacuase " +messageValue, OAException.WARNING);          
             throw new OAException(requestSentCount+" request(s) sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) +" and " + error_count + " request(s) were not sent successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2)   , OAException.WARNING);                        
			 }
             else if(requestSentCount>0 && error_count==0)
             {
				  am.initEbizChPendingInvResendVO();
                 throw new OAException(requestSentCount+" request(s) sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) , OAException.INFORMATION);
             }
             else if(requestSentCount<=0 && error_count>0)
             {
				  am.initEbizChPendingInvResendVO();
                 throw new OAException(error_count + " request(s) not sent successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2), OAException.ERROR);
             }
             else{
				  am.initEbizChPendingInvResendVO();
                 throw new OAException("Error sending request(s), check log.", OAException.ERROR);
             }
             
          }
	   }

if (pageContext.getParameter("removeEmailInvBtn") != null) {

          EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
          EbizChPendingInvResendVOImpl custVo = am.getEbizChPendingInvResendVO1();
          EbizChPendingInvResendVORowImpl payMethodPendingVo = null;
          String excCollectAdd = " ";
          
          Row rows[] = custVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = rows.length;
		  String invNums="";  
		  String SucinvNums="";
          String inUrlId="";
          String inSentCount="";
          String inUrlIdStr = "";
	      String messageValue="";
	      int error_count = 0;
		  int requestSentCount=0;
          
          if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  payMethodPendingVo = (EbizChPendingInvResendVORowImpl) rows[i];
                  
                  
                  Number inPendingReqIdNumb = (Number) payMethodPendingVo.getAttribute("InvSentId");
                  String inPendingReqIdString = inPendingReqIdNumb.toString();
                  int inPendingReqIdInt = Integer.parseInt(inPendingReqIdString);
                  
                  String CustNumVal = (String) payMethodPendingVo.getAttribute("CustNum");
		          String PayIntId = (String) payMethodPendingVo.getAttribute("PayIntId");		  
				  String invnum = (String) payMethodPendingVo.getAttribute("InvNum");

                  
				  if (payMethodPendingVo.getAttribute("SentCount") != null){
					inSentCount = (String) payMethodPendingVo.getAttribute("SentCount");
				  }
				  else{
					inSentCount = "0";
				  }
                  
                  int inSentCountInt = Integer.parseInt(inSentCount);
                  inSentCountInt = inSentCountInt + 1;
				  
                  
                  String[] validationsMessage = isValidate(invnum,inSentCountInt ,inPendingReqIdInt);

                   if (validationsMessage[0].equals("1")) {
                     messageValue = messageValue + validationsMessage[1];
                     invNums =validationsMessage[2]+", "+invNums;
			      }
				  else
				   {
					  SucinvNums =validationsMessage[3]+", "+SucinvNums;  
				   }
                       
                   if (validationsMessage[0].equals("1")){
                      error_count++; 
                   }
                   else{
		 
                  String[] deleteEmail=delete_webform_email(pageContext, webBean,CustNumVal ,PayIntId);
                   
                  if(deleteEmail[0].equals("S")) {
                      requestSentCount++;
                  }else{
					  error_count++;
                     
                  }
                   }
                  
                  
              }
			 messageValue = getDistinctString(pageContext,webBean,messageValue);
             if(requestSentCount>0 && error_count>0){
				 am.initEbizChPendingInvResendVO();
                
             throw new OAException(requestSentCount+" request(s) deleted successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) +" and " + error_count + " request(s) were not deleted successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2)   , OAException.WARNING);                        
			 }
             else if(requestSentCount>0 && error_count==0)
             {
				  am.initEbizChPendingInvResendVO();
                 throw new OAException(requestSentCount+" request(s) deleted successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) , OAException.INFORMATION);
             }
             else if(requestSentCount<=0 && error_count>0)
             {
				  am.initEbizChPendingInvResendVO();
                 throw new OAException(error_count + " request(s) not deleted successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2), OAException.ERROR);
             }
             else{
				  am.initEbizChPendingInvResendVO();
                 throw new OAException("Error deleting request(s), check log.", OAException.ERROR);
             }
             
          }
	   }
    super.processFormRequest(pageContext, webBean);
  
  }
  	   
	public String[] resend_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String CustNumVal ,String pay_int_id ,String pendingreqId, String count){
             CallableStatement stmtaddTemplate;
			    String[] addDetails = new String[2]; 
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.resend_webform_pending_pay(:1,:2,:3,:4,:5, :6); end;", OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, CustNumVal);
                             stmtaddTemplate.setString(2, pay_int_id);
                             stmtaddTemplate.setString(3, pendingreqId); 
                             stmtaddTemplate.setString(4, count); 
                             stmtaddTemplate.registerOutParameter(5, Types.VARCHAR);
                             stmtaddTemplate.registerOutParameter(6, Types.VARCHAR);
                             
                             
                         stmtaddTemplate.execute();
                           addDetails[0] = stmtaddTemplate.getString(5);
                           addDetails[1] = stmtaddTemplate.getString(6);
                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return addDetails;
      }	
      
    public String[] pending_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String to_date ,String from_Date){
         CallableStatement stmtaddTemplate;
                        String[] addDetails = new String[2]; 
              try {
                     OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.get_pendingpayment_call(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
                         stmtaddTemplate.setString(1, to_date);
                         stmtaddTemplate.setString(2, from_Date); 
                         stmtaddTemplate.registerOutParameter(3, Types.VARCHAR);
                         stmtaddTemplate.registerOutParameter(4, Types.VARCHAR);
                         
                         
                     stmtaddTemplate.execute();
                       addDetails[0] = stmtaddTemplate.getString(3);
                       addDetails[1] = stmtaddTemplate.getString(4);
                     stmtaddTemplate.close();   
                                    
                } catch (SQLException e) {
                    throw new OAException("Exception in pending_webform_email: " + e.getMessage(), OAException.ERROR);
                }
                            
         return addDetails;
    }  
      
      
      
    public String[] isValidate(String invnum,int inSentCount  , int inPendingReqIdNumb) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
      if ("".equals(String.valueOf(inSentCount))) {
        retMessage = retMessage + "Sent Count,";
      }
   
      if ("".equals(String.valueOf(inPendingReqIdNumb)) || String.valueOf(inPendingReqIdNumb) == null) {
        retMessage = retMessage + "Pending Req Id,";
      }

      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invnum;
        output[1] = retValue;
		output[2] = invnum;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Data is validated.";
		output[3] = invnum;
      }
      return output;
    }
    
    public void deleteMail(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
       CallableStatement stmtaddTemplate;
                      String[] addDetails = new String[2]; 
            try {
                   OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                       stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.deleteEMail; end;", OADBTransaction.DEFAULT);
                       
                       
                       
                   stmtaddTemplate.execute();

                   stmtaddTemplate.close();   
                                  
              } catch (SQLException e) {
                  throw new OAException("Exception in delete Email: " + e.getMessage(), OAException.ERROR);
              }
                          
    }
      
    
     public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   }
    public String[] delete_webform_email(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,  String CustNumVal ,String pay_int_id ){
             CallableStatement stmtaddTemplate;
			    String[] addDetails = new String[2]; 
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                             stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_creditcard_pkg.delete_webform_email(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, CustNumVal);
                             stmtaddTemplate.setString(2, pay_int_id);
                             stmtaddTemplate.registerOutParameter(3, Types.VARCHAR);
                             stmtaddTemplate.registerOutParameter(4, Types.VARCHAR);
                             
                             
                         stmtaddTemplate.execute();
                           addDetails[0] = stmtaddTemplate.getString(3);
                           addDetails[1] = stmtaddTemplate.getString(4);
                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return addDetails;
      }	
}
