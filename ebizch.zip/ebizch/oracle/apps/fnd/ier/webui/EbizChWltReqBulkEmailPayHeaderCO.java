package ebizch.oracle.apps.fnd.ier.webui;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;

import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVOImpl;
import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVORowImpl;

import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

import oracle.jbo.Row;
import oracle.jbo.domain.Number;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;

public class EbizChWltReqBulkEmailPayHeaderCO extends OAControllerImpl
{

    String inSubjectText ="" ; 
	String inEmailTemplate="";
	String inFromMail="";
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	
      EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
	     am.initBulkEmailPayInvVO();
		 
	    if (!am.getEbizChCreateRowVO1().isPreparedForExecution())
                 {
                 am.getEbizChCreateRowVO1().executeQuery();
                 am.getEbizChCreateRowVO1().first();
                 }
	 
	  String[] getTemplateDetails=getEmailTemplates(pageContext, webBean);
	  
	  if (getTemplateDetails[4]!="E" || !getTemplateDetails[4].equals("E"))
	  {
		  
	   inSubjectText=getTemplateDetails[0];
	   inEmailTemplate=getTemplateDetails[1];
	   inFromMail=getTemplateDetails[2];
	  

	   OAMessageLovInputBean lovBean =(OAMessageLovInputBean)webBean.findChildRecursive("EmailTemplate");
       lovBean.setText(pageContext,inEmailTemplate);
	  
	   OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
	   textBean.setText(inSubjectText);	
		
	   OAMessageTextInputBean textBeanEmailFromIn = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
       textBeanEmailFromIn.setText(inFromMail);
	   
       OAFormValueBean TemplateIdFvInput = (OAFormValueBean)webBean.findIndexedChildRecursive("TemplateIdFv");
       TemplateIdFvInput.setValue(inEmailTemplate);
	   
	   OAFormValueBean inFromMailInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailSubjectFv");
       inFromMailInputSet1.setValue(pageContext,inSubjectText);
	  
	   OAFormValueBean inSubjectTextInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromFv");
       inSubjectTextInputSet1.setValue(pageContext,inFromMail);
	  
	
		    pageContext.putSessionValue("inSubjectText", inSubjectText);
		    pageContext.putSessionValue("inFromMail", inFromMail);
		   
	 

	  }
	  
    
    
  }

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
       
	   if (pageContext.isLovEvent())
       {
		   String lovInputSourceId = pageContext.getLovInputSourceId();
		   String lovEvent = pageContext.getParameter(EVENT_PARAM);
		   
	   if("lovUpdate".equals(lovEvent)) { 
	   
		   if("EmailTemplate".equals(lovInputSourceId))
		   {
			 
			 OAFormValueBean inSubjectFv = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailSubjectFv");
             String inSubjectFv1 = String.valueOf(inSubjectFv.getValue(pageContext)) ;
			   
             OAFormValueBean fromEmailFv = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromFv");
             String infromEmailFv =  String.valueOf(fromEmailFv.getValue(pageContext));
			 
             OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
             textBean.setText(inSubjectFv1); 
                                          
             OAMessageTextInputBean EmailFromIntextBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
             EmailFromIntextBean.setText(infromEmailFv);
			 
			 }
	   }
	      
     }
	 
	  if(pageContext.isLovEvent())  
      {
		  
      String lovInputSourceId = pageContext.getLovInputSourceId();
	  
	  
	  if("EmailTemplate".equals(lovInputSourceId))
	  {
		 OAFormValueBean inFromMailInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailFromFv");
		 String inFromMail = (String) inFromMailInputSet1.getValue(pageContext);
		 
		 OAFormValueBean inSubjectTextInputSet1 = (OAFormValueBean)webBean.findIndexedChildRecursive("EmailSubjectFv");
         String inSubjectText = (String) inSubjectTextInputSet1.getValue(pageContext);
		 
        if(String.valueOf(inSubjectText).equals("null") || String.valueOf(inSubjectText).equals(""))
		{
			
		OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
	    textBean.setText("");	
		
	    OAMessageTextInputBean textBeanEmailFromIn = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
        textBeanEmailFromIn.setText("");
		
		 pageContext.putSessionValue("inSubjectText", "");
	     pageContext.putSessionValue("inFromMail", "");
		}
		else if(String.valueOf(inFromMail).equals("null") || String.valueOf(inFromMail).equals(""))
			{
				OAMessageTextInputBean textBean = (OAMessageTextInputBean)webBean.findChildRecursive("EmailSubjectIn");
				textBean.setText("");	
				
				OAMessageTextInputBean textBeanEmailFromIn = (OAMessageTextInputBean)webBean.findChildRecursive("EmailFromIn");
				textBeanEmailFromIn.setText("");
				
				 pageContext.putSessionValue("inSubjectText", "");
				 pageContext.putSessionValue("inFromMail", "");
			}
		else
			
		{
			
		 pageContext.putSessionValue("inSubjectText", inSubjectText);
	     pageContext.putSessionValue("inFromMail", inFromMail);  
		 
		} 
	  }
      }
	  
     super.processFormRequest(pageContext, webBean);
  }

    public String[] getInvDetails (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inInvNo){
        String[] invDetails = new String[17]; 
                    CallableStatement stmtGetCustAddDetails;
        try {
              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetrtinv(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19); end;",
                                      OADBTransaction.DEFAULT);
                              
                              
                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(9, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(10, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(11, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(12, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(13, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(14, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(15, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(16, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(17, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(18, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(19, Types.VARCHAR);
                            
                              stmtGetCustAddDetails.setInt(1, inOrgId);
                              stmtGetCustAddDetails.setString(2, inInvNo);      
                                    
                              stmtGetCustAddDetails.execute();
                              
                              invDetails[0] = stmtGetCustAddDetails.getString(3);
                              invDetails[1] = stmtGetCustAddDetails.getString(4);
                              invDetails[2] = stmtGetCustAddDetails.getString(5);
                              invDetails[3] = stmtGetCustAddDetails.getString(6);
                              invDetails[4] = stmtGetCustAddDetails.getString(7);
                              invDetails[5] = stmtGetCustAddDetails.getString(8);
                              invDetails[6] = stmtGetCustAddDetails.getString(9);
                              invDetails[7] = stmtGetCustAddDetails.getString(10);
                              invDetails[8] = stmtGetCustAddDetails.getString(11);
                              invDetails[9] = stmtGetCustAddDetails.getString(12);
                              invDetails[10] = stmtGetCustAddDetails.getString(13);
                              invDetails[11] = stmtGetCustAddDetails.getString(14);
                              invDetails[12] = stmtGetCustAddDetails.getString(15);
                              invDetails[13] = stmtGetCustAddDetails.getString(16);
                              invDetails[14] = stmtGetCustAddDetails.getString(17);
                              invDetails[15] = stmtGetCustAddDetails.getString(18);
                              invDetails[16] = stmtGetCustAddDetails.getString(19);
                                    
                              stmtGetCustAddDetails.close();   
             
          } catch (SQLException e) {
              throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
          }
                      
                      return invDetails;
    }
    
    
    public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo) {
        String[] addDetails = new String[6];
        CallableStatement stmtGetCustAddDetails;
        try {
            OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
            stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetcustsiteadd(:1,:2,:3,:4,:5,:6,:7); end;",
                OADBTransaction.DEFAULT);

            stmtGetCustAddDetails.registerOutParameter(2, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);

            stmtGetCustAddDetails.setInt(1, siteNo);

            stmtGetCustAddDetails.execute();

            addDetails[0] = stmtGetCustAddDetails.getString(2);
            addDetails[1] = stmtGetCustAddDetails.getString(3);
            addDetails[2] = stmtGetCustAddDetails.getString(4);
            addDetails[3] = stmtGetCustAddDetails.getString(5);
            addDetails[4] = stmtGetCustAddDetails.getString(6);
            addDetails[5] = stmtGetCustAddDetails.getString(7);

            stmtGetCustAddDetails.close();

        } catch (SQLException e) {
            throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
        }

        return addDetails;
    }

  
 public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum, String inEmailArr,String inFromMail,String emSubject,String tempName){
                 String[] sendInvDetails = new String[2]; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_invoice(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      sendInvoiceDetails.setString(1, custNum);
                                      sendInvoiceDetails.setString(2, inSO);
                                      sendInvoiceDetails.setString(3, orgId);
                                      sendInvoiceDetails.setString(4, invNum);
									  sendInvoiceDetails.setString(5, inEmailArr);
									  sendInvoiceDetails.setString(6, inFromMail);
									  sendInvoiceDetails.setString(7, emSubject);
									  sendInvoiceDetails.setString(8, tempName);
                                       sendInvoiceDetails.registerOutParameter(9, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
									   
                                      sendInvoiceDetails.execute();
                                       
                                       sendInvDetails[0] = sendInvoiceDetails.getString(9);
                                       sendInvDetails[1] = sendInvoiceDetails.getString(10);
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return sendInvDetails;
     }  
    public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_inv_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_invoice_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                         OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, p_cust_num);
                             stmtaddTemplate.setString(2, p_cust_name);
                             stmtaddTemplate.setString(3, p_inv_num);
                             stmtaddTemplate.setString(4, p_inv_org_id);
                             stmtaddTemplate.setString(5, p_email_to);
                             stmtaddTemplate.setString(6, p_out_ebiz_url);
                             stmtaddTemplate.setString(7, p_in_from_mail);
                             stmtaddTemplate.setString(8, p_in_to_mail);
                             stmtaddTemplate.setString(9, p_created_by);
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      }

	 public String[] getEmailTemplates(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
                 String[] getTemplateDetails = new String[5]; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.get_multiple_emailtemp_div(:1,:2,:3,:4,:5); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      
                                       sendInvoiceDetails.registerOutParameter(1, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(2, Types.VARCHAR);
									   sendInvoiceDetails.registerOutParameter(3, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(4, Types.VARCHAR);
									   sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                       
                                      sendInvoiceDetails.execute();
                                       
                                       getTemplateDetails[0] = sendInvoiceDetails.getString(1);
                                       getTemplateDetails[1] = sendInvoiceDetails.getString(2);
									   getTemplateDetails[2] = sendInvoiceDetails.getString(3);
                                       getTemplateDetails[3] = sendInvoiceDetails.getString(4);
									   getTemplateDetails[4] = sendInvoiceDetails.getString(5);
                                       
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the templates from the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return getTemplateDetails;
     }   

    public String[] isValidate(String CustomerNum,String orgId,String invNumb,String inFromMail,String inEmailArr,String inSubject,String inEmailArrNew) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(CustomerNum)) || "".equals(String.valueOf(CustomerNum))) {
        retMessage = retMessage + "Customer Id,";
      }

      if ("null".equals(String.valueOf(orgId)) || "".equals(String.valueOf(orgId))) {
        retMessage = retMessage + "Invoice Org Id,";
      }

      if ("null".equals(String.valueOf(invNumb)) || "".equals(String.valueOf(invNumb))) {
        retMessage = retMessage + "Invoice Number,";
      }

        if ("null".equals(String.valueOf(inFromMail)) || "".equals(String.valueOf(inFromMail)))  {
          retMessage = retMessage + "From Email,";
        }

        if ("null".equals(String.valueOf(inSubject)) || "".equals(String.valueOf(inSubject)))  {
          retMessage = retMessage + "Subject,";
        }
      //inEmailArrNew
       if ("null".equals(String.valueOf(inEmailArrNew)) || "".equals(String.valueOf(inEmailArrNew)))  {
         retMessage = retMessage + "To Email,";
       }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invNumb+ " . ";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Invoice data is validated.";
      }
      return output;
    }
       
}
