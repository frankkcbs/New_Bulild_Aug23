package ebizch.oracle.apps.fnd.ier.webui;

import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import ebizch.oracle.apps.fnd.ier.server.EbizChIerAMImpl;
import java.util.Arrays;
import java.util.List;
import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVOImpl;
import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVORowImpl;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.cabo.style.CSSStyle;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;
import oracle.jbo.Row;
import oracle.jbo.domain.Number;
import oracle.apps.fnd.framework.webui.beans.OABodyBean;


public class EbizChWltReqBulkEmailPayCO extends OAControllerImpl
{

    String inSubjectText ="" ; 
	String inEmailTemplate="";
	String inFromMail="";
  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
	EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
	am.initBulkEmailPayInvVO();
	if (!am.getEbizChCreateRowVO1().isPreparedForExecution())
	{
		am.getEbizChCreateRowVO1().executeQuery();
		am.getEbizChCreateRowVO1().first();
	}
	 

 
	 String query ="SELECT   r.trx_number, r.creation_date, hca.account_number, party_name,email_address to_email, r.org_id,  to_char(arpaymentschedulesv.amount_due_original, 'fm99999999999.90') amount_due_original,TO_CHAR(arpaymentschedulesv.amount_due_remaining, 'fm99999999999.90') amount_due_remaining FROM ra_customer_trx_all r,hz_cust_accounts_all hca,hz_parties hp,ar_payment_schedules_all arpaymentschedulesv WHERE 1 = 1 AND status_trx = 'OP' AND r.sold_to_customer_id = hca.cust_account_id AND hca.party_id = hp.party_id AND arpaymentschedulesv.customer_trx_id = r.customer_trx_id AND arpaymentschedulesv.amount_due_remaining <> 0 AND arpaymentschedulesv.trx_number NOT IN ( SELECT   inv_num FROM ebizch_invoice_email_sent GROUP BY inv_num) AND arpaymentschedulesv.trx_number NOT IN (SELECT rcta.trx_number FROM ar_receivable_applications_all araa,ar_cash_receipts_all acra,ra_customer_trx_all rcta WHERE araa.cash_receipt_id = acra.cash_receipt_id AND araa.applied_customer_trx_id = rcta.customer_trx_id AND rcta.trx_number = arpaymentschedulesv.trx_number) ORDER BY r.creation_date DESC";
			 try
			 {
				BulkEmailPayInvVOImpl vo1 = (BulkEmailPayInvVOImpl)am.findViewObject("BulkEmailPayInvVO1");
				   vo1.setFullSqlMode(vo1.FULLSQL_MODE_AUGMENTATION);
					vo1.setQuery(query);
				   vo1.executeQuery();
			  }
			  catch (Exception e)
			  {
				  throw new OAException("Updating Query.  Exception: " + e.getMessage(), OAException.ERROR);
			  }
			  
			  CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                csNum.setProperty("text-align", "right");
                OAMessageTextInputBean omstb1 =(OAMessageTextInputBean)webBean.findChildRecursive("AmountDueOriginal");
				OAMessageTextInputBean omstb11 =(OAMessageTextInputBean)webBean.findChildRecursive("AmountDueRemaining");
				
                omstb1.setInlineStyle(csNum);
				omstb11.setInlineStyle(csNum);
    
  }

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
      String inFromMail="";
      String inEmailArr="",inSubject="";
	  int success_count = 0;
	  int error_count = 0;
	  
	  String excCollectAdd = " ";
      String messageValue="";
					
      if (pageContext.getParameter("sendEmailInvBtn") != null) {
		  
		  EbizChIerAMImpl am = (EbizChIerAMImpl) pageContext.getApplicationModule(webBean);
          BulkEmailPayInvVOImpl custVo = am.getBulkEmailPayInvVO1();
          BulkEmailPayInvVORowImpl payMethodMasterVo = null;
		  
		  Row[] arrayOfRow = custVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = arrayOfRow.length;
			 String invNums="";  
		    String SucinvNums="";
		  if (pageContext.getParameter("EmailTemplate") != null) {
				  inEmailTemplate = pageContext.getParameter("EmailTemplate");
		  }	
		  
		  if (pageContext.getParameter("EmailSubjectIn") != null) {
              inSubject = (String)pageContext.getSessionValue("inSubjectText"); 
          }
		  
		  inFromMail = (String)pageContext.getSessionValue("inFromMail");
		  inSubject = (String)pageContext.getSessionValue("inSubjectText");
		  

		  
		  if (rowsLength > 0) {
              for (int i = 0; i < rowsLength; i++) {
                  payMethodMasterVo = (BulkEmailPayInvVORowImpl) arrayOfRow[i];
				  
				  
				  
				  String inInvNum = (String) payMethodMasterVo.getAttribute("TrxNumber");
				  
				  Number OrgId = (Number) payMethodMasterVo.getAttribute("OrgId");
                                  String inInvOrg = OrgId.toString();
				  
				  inEmailArr = (String) payMethodMasterVo.getAttribute("ToEmail");
			         String inEmailArrNew = (String) payMethodMasterVo.getAttribute("ToEmail");
				
				  String[] invDetails = getInvDetails (pageContext, webBean, Integer.parseInt(inInvOrg), inInvNum) ;
				  
				  String CustAccNoString = invDetails[2];
			      String invNumb = invDetails[3];			     
			      String invOrgIdStr = inInvOrg;
			      String invSaleOrder = invDetails[14]; 

			      if (pageContext.getParameter("EmailFromIn") != null) {
			              inFromMail = pageContext.getParameter("EmailFromIn");
			      }

			      if (pageContext.getParameter("EmaiToArrIn") != null) {
			              inEmailArr = pageContext.getParameter("EmaiToArrIn");
			      }
				  
			      String[] validationsMessage = isValidate(CustAccNoString,invOrgIdStr,invNumb,inFromMail,inEmailArr,inSubject,inEmailArrNew,inEmailTemplate);

			      if (validationsMessage[0].equals("1")) {
			        messageValue = messageValue + validationsMessage[1];
					invNums =validationsMessage[2]+", "+invNums;
			      }
				  else
				   {
					  SucinvNums =validationsMessage[3]+", "+SucinvNums;  
				   }
			      if (validationsMessage[0].equals("1")){
			         error_count++; 
			      }
			      else{
					 String[] sendinv=sendInvoice(pageContext, webBean, CustAccNoString,invSaleOrder,invOrgIdStr,invNumb,inEmailArr,inFromMail,inSubjectText,inEmailTemplate);
                                if (sendinv[0]!="E" || !sendinv[0].equals("E"))
                                     {
									success_count++;
									excCollectAdd="Request has been sent Successfully. Invoice Number :" +invNumb;
									 }
									 else{
										 error_count++;  
										 excCollectAdd="Request has not been sent Successfully. Invoice Number :" +invNumb;
									 }
                              }
					 
			  }
            messageValue = getDistinctString(pageContext,webBean,messageValue);
           /*   
           if(success_count ==  1 && ){
				am.initBulkEmailPayInvVO();
               throw new OAException(excCollectAdd, OAException.INFORMATION);
            }
                       
            if(error_count == 1 ){
				am.initBulkEmailPayInvVO();
                if (!messageValue.equals("") ||!messageValue.equals(null))
                    {
                        throw new OAException(error_count + " request(s) were not sent because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2), OAException.ERROR);
                      }
                      else
                      {
                      throw new OAException(excCollectAdd, OAException.ERROR);
                      }
            }
            */
            if(success_count>0 && error_count<=0)//(success_count > 1 && error_count < 1)
			{
				//custVo.clearCache();
				
				am.initBulkEmailPayInvVO();
				    OABodyBean bodyBean = (OABodyBean) pageContext.getRootWebBean();
					String javaS = "javascript:window.history.forward(1);";
					bodyBean.setOnLoad(javaS);
                throw new OAException("Success: "+ success_count +" request(s) sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) , OAException.INFORMATION);
            }
            
            if(success_count<=0 && error_count>0)//(success_count < 1 && error_count > 1)
			 {
				 //custVo.clearCache();
				 
				am.initBulkEmailPayInvVO();
				OABodyBean bodyBean = (OABodyBean) pageContext.getRootWebBean();
				String javaS = "javascript:window.history.forward(1);";
				bodyBean.setOnLoad(javaS);
                if (!messageValue.equals("") ||!messageValue.equals(null))
                {
                    //throw new OAException("Error: "+ error_count +" request(s) were not sent successfully "+"because these fields" + messageValue , OAException.ERROR);
					 throw new OAException(error_count + " request(s) were not sent because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2) , OAException.ERROR);
                }
                else
                {
                    throw new OAException("Error: "+ error_count +" request(s) were not sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) , OAException.ERROR);
                }
              
            }
            
            if(success_count>0 && error_count>0)//(success_count > 1 && error_count > 1)
			{
				//custVo.clearCache();
				
				am.initBulkEmailPayInvVO();
				//Row rows[] = custVo.getAllRowsInRange();    
				//  for(Row row : rows){  
				//	   row.setAttribute("ViewAttr","N");  
				 // }
                OABodyBean bodyBean = (OABodyBean) pageContext.getRootWebBean();
				String javaS = "javascript:window.history.forward(1);";
				bodyBean.setOnLoad(javaS);

                if (!messageValue.equals("") ||!messageValue.equals(null))
                {
                   // throw new OAException("Success: "+ success_count +" request(s) sent successfully but "+ error_count +" request(s) were not sent successfully " + "because these fields" + messageValue, OAException.WARNING);
                    throw new OAException(success_count+" request(s) sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) +" and " + error_count + " request(s) were not sent successfully because these fields '"+messageValue+"' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2)   , OAException.WARNING);                        
 			   }
                else
                {
                    throw new OAException("Success: "+ success_count +" request(s) sent successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() -2) +" but "+ error_count +" request(s) were not sent successfully against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() -2) , OAException.WARNING);
                }
                
            }

          }

	 throw new OAException("Please select Invoice to send the request.", OAException.WARNING);      
      
      }
    super.processFormRequest(pageContext, webBean);
    
  }

    public String[] getInvDetails (OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int inOrgId, String inInvNo){
        String[] invDetails = new String[17]; 
                    CallableStatement stmtGetCustAddDetails;
        try {
              OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                              stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetrtinv(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10,:11,:12,:13,:14,:15,:16,:17,:18,:19); end;",
                                      OADBTransaction.DEFAULT);
                              
                              
                              stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(8, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(9, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(10, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(11, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(12, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(13, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(14, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(15, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(16, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(17, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(18, Types.VARCHAR);
                              stmtGetCustAddDetails.registerOutParameter(19, Types.VARCHAR);
                            
                              stmtGetCustAddDetails.setInt(1, inOrgId);
                              stmtGetCustAddDetails.setString(2, inInvNo);      
                                    
                              stmtGetCustAddDetails.execute();
                              
                              invDetails[0] = stmtGetCustAddDetails.getString(3);
                              invDetails[1] = stmtGetCustAddDetails.getString(4);
                              invDetails[2] = stmtGetCustAddDetails.getString(5);
                              invDetails[3] = stmtGetCustAddDetails.getString(6);
                              invDetails[4] = stmtGetCustAddDetails.getString(7);
                              invDetails[5] = stmtGetCustAddDetails.getString(8);
                              invDetails[6] = stmtGetCustAddDetails.getString(9);
                              invDetails[7] = stmtGetCustAddDetails.getString(10);
                              invDetails[8] = stmtGetCustAddDetails.getString(11);
                              invDetails[9] = stmtGetCustAddDetails.getString(12);
                              invDetails[10] = stmtGetCustAddDetails.getString(13);
                              invDetails[11] = stmtGetCustAddDetails.getString(14);
                              invDetails[12] = stmtGetCustAddDetails.getString(15);
                              invDetails[13] = stmtGetCustAddDetails.getString(16);
                              invDetails[14] = stmtGetCustAddDetails.getString(17);
                              invDetails[15] = stmtGetCustAddDetails.getString(18);
                              invDetails[16] = stmtGetCustAddDetails.getString(19);
                                    
                              stmtGetCustAddDetails.close();   
             
          } catch (SQLException e) {
              throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
          }
                      
                      return invDetails;
    }
    
    
    public String[] getCustAddressDetails(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, int siteNo) {
        String[] addDetails = new String[6];
        CallableStatement stmtGetCustAddDetails;
        try {
            OADBTransactionImpl txnGetCustAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
            stmtGetCustAddDetails = txnGetCustAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizchargegetcustsiteadd(:1,:2,:3,:4,:5,:6,:7); end;",
                OADBTransaction.DEFAULT);

            stmtGetCustAddDetails.registerOutParameter(2, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(3, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(4, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(5, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(6, Types.VARCHAR);
            stmtGetCustAddDetails.registerOutParameter(7, Types.VARCHAR);

            stmtGetCustAddDetails.setInt(1, siteNo);

            stmtGetCustAddDetails.execute();

            addDetails[0] = stmtGetCustAddDetails.getString(2);
            addDetails[1] = stmtGetCustAddDetails.getString(3);
            addDetails[2] = stmtGetCustAddDetails.getString(4);
            addDetails[3] = stmtGetCustAddDetails.getString(5);
            addDetails[4] = stmtGetCustAddDetails.getString(6);
            addDetails[5] = stmtGetCustAddDetails.getString(7);

            stmtGetCustAddDetails.close();

        } catch (SQLException e) {
            throw new OAException("e.getMessage(1):" + e.getMessage(), OAException.INFORMATION);
        }

        return addDetails;
    }

  
 public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum, String inEmailArr,String inFromMail,String emSubject,String tempName){
                 String[] sendInvDetails = new String[2]; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.send_invoice(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;",
                                               OADBTransaction.DEFAULT);
                                       
										sendInvoiceDetails.setString(1, custNum);
										sendInvoiceDetails.setString(2, inSO);
										sendInvoiceDetails.setString(3, orgId);
										sendInvoiceDetails.setString(4, invNum);
										sendInvoiceDetails.setString(5, inEmailArr);
										sendInvoiceDetails.setString(6, inFromMail);
										sendInvoiceDetails.setString(7, emSubject);
										sendInvoiceDetails.setString(8, tempName);
											sendInvoiceDetails.registerOutParameter(9, Types.VARCHAR);
											sendInvoiceDetails.registerOutParameter(10, Types.VARCHAR);
									   
										sendInvoiceDetails.execute();
                                       
                                       sendInvDetails[0] = sendInvoiceDetails.getString(9);
                                       sendInvDetails[1] = sendInvoiceDetails.getString(10);
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return sendInvDetails;
     }  
    public Boolean addEmailInvSent(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String p_cust_num , String p_cust_name , String p_inv_num , String p_inv_org_id  , String p_email_to  ,String p_out_ebiz_url , String p_in_from_mail  , String p_in_to_mail , String p_created_by ){
             CallableStatement stmtaddTemplate;
                  try {
                         OADBTransactionImpl txnaddTemplate = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                         stmtaddTemplate = txnaddTemplate.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.ebizch_add_invoice_email_sent(:1,:2,:3,:4,:5,:6,:7,:8,:9); end;",
                         OADBTransaction.DEFAULT);
                     
                             stmtaddTemplate.setString(1, p_cust_num);
                             stmtaddTemplate.setString(2, p_cust_name);
                             stmtaddTemplate.setString(3, p_inv_num);
                             stmtaddTemplate.setString(4, p_inv_org_id);
                             stmtaddTemplate.setString(5, p_email_to);
                             stmtaddTemplate.setString(6, p_out_ebiz_url);
                             stmtaddTemplate.setString(7, p_in_from_mail);
                             stmtaddTemplate.setString(8, p_in_to_mail);
                             stmtaddTemplate.setString(9, p_created_by);
                             
                         stmtaddTemplate.execute();

                         stmtaddTemplate.close();   
                                        
                    } catch (SQLException e) {
                        throw new OAException("Invoice Email Sent Inserting into DB. Exception: " + e.getMessage(), OAException.ERROR);
                    }
                                
             return true;
      }
	  
	
	public String[] getEmailTemplates(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
                 String[] getTemplateDetails = new String[5]; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_ep_CreditCard_pkg.get_multiple_emailtemp_div(:1,:2,:3,:4,:5); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      
                                       sendInvoiceDetails.registerOutParameter(1, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(2, Types.VARCHAR);
									   sendInvoiceDetails.registerOutParameter(3, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(4, Types.VARCHAR);
									   sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                       
                                      sendInvoiceDetails.execute();
                                       
                                       getTemplateDetails[0] = sendInvoiceDetails.getString(1);
                                       getTemplateDetails[1] = sendInvoiceDetails.getString(2);
									   getTemplateDetails[2] = sendInvoiceDetails.getString(3);
                                       getTemplateDetails[3] = sendInvoiceDetails.getString(4);
									   getTemplateDetails[4] = sendInvoiceDetails.getString(5);
                                       
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the templates from the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return getTemplateDetails;
     }   
 
    public String[] isValidate(String CustomerNum,String orgId,String invNumb,String inFromMail,String inEmailArr,String inSubject,String inEmailArrNew,String inTemplate) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[4];
      output[0] = "0";
      if ("null".equals(String.valueOf(CustomerNum)) || "".equals(String.valueOf(CustomerNum))) {
        retMessage = retMessage + "Customer Id,";
      }

      if ("null".equals(String.valueOf(orgId)) || "".equals(String.valueOf(orgId))) {
        retMessage = retMessage + "Invoice Org Id,";
      }

      if ("null".equals(String.valueOf(invNumb)) || "".equals(String.valueOf(invNumb))) {
        retMessage = retMessage + "Invoice Number,";
      }
         if ("null".equals(String.valueOf(inTemplate)) || "".equals(String.valueOf(inTemplate))) {
        retMessage = retMessage + "Template Name,";
      }
	  
        if ("null".equals(String.valueOf(inFromMail)) || "".equals(String.valueOf(inFromMail)))  {
          retMessage = retMessage + "From Email Address,";
        }

        if ("null".equals(String.valueOf(inSubject)) || "".equals(String.valueOf(inSubject)))  {
          retMessage = retMessage + "Subject,";
        }
      //inEmailArrNew
       if ("null".equals(String.valueOf(inEmailArrNew)) || "".equals(String.valueOf(inEmailArrNew)))  {
         retMessage = retMessage + "To Email,";
       }
      if (retMessage!="") {
        output[0] = "1";
		//retMessage=  retMessage.substring(0, retMessage.length() -1);
       // retValue = retMessage + "were not found against your selected Invoice No" + " " + invNumb;
	    retValue = retMessage ;
        output[1] = retValue;
		output[2] = invNumb;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Invoice data is validated.";
		output[3] = invNumb;
      }
      return output;
    }
	 public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String message) {
      String myString =message;
      String[] myArray = myString.split(",");
      String arr[] = myArray;
      String messageValue="";
      int n = arr.length;
      int i, j;
      for (i = 0; i < n; ++i)
      {
      for (i = 0; i < n; i++) {
         for (j = 0; j < i; j++)
         if (arr[i].equals(arr[j]))
            break;
         if (i == j)
         {
         messageValue = messageValue + arr[i] + ", ";
         }
   }
  
      }
       messageValue = messageValue.substring(0, messageValue.length() -2);
      return messageValue;
   }
       
}
