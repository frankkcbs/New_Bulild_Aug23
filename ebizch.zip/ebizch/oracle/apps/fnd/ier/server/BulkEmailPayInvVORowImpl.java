package ebizch.oracle.apps.fnd.ier.server;

import ebizch.oracle.apps.fnd.ier.server.BulkEmailPayInvVORowImpl;
import oracle.apps.fnd.framework.server.OAViewRowImpl;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;
import oracle.jbo.server.AttributeDefImpl;

public class BulkEmailPayInvVORowImpl extends OAViewRowImpl {
  public static final int TRXNUMBER = 0;
  
  public static final int CREATIONDATE = 1;
  
  public static final int ACCOUNTNUMBER = 2;
  
  public static final int PARTYNAME = 3;
  
  public static final int TOEMAIL = 4;
  
  public static final int ORGID = 5;
  
  public static final int VIEWATTR = 6;
  
  public static final int AMOUNTDUEORIGINAL = 7;
  
  public static final int AMOUNTDUEREMAINING = 8;
  
  public String getTrxNumber() {
    return (String)getAttributeInternal(0);
  }
  
  public void setTrxNumber(String paramString) {
    setAttributeInternal(0, paramString);
  }
  
  public Date getCreationDate() {
    return (Date)getAttributeInternal(1);
  }
  
  public void setCreationDate(Date paramDate) {
    setAttributeInternal(1, paramDate);
  }
  
  public String getAccountNumber() {
    return (String)getAttributeInternal(2);
  }
  
  public void setAccountNumber(String paramString) {
    setAttributeInternal(2, paramString);
  }
  
  public String getPartyName() {
    return (String)getAttributeInternal(3);
  }
  
  public void setPartyName(String paramString) {
    setAttributeInternal(3, paramString);
  }
  
  public String getToEmail() {
    return (String)getAttributeInternal(4);
  }
  
  public void setToEmail(String paramString) {
    setAttributeInternal(4, paramString);
  }
  
  public String getAmountDueOriginal() {
    return (String)getAttributeInternal(7);
  }
  
  public void setAmountDueOriginal(String paramNumber) {
    setAttributeInternal(7, paramNumber);
  }
  
  public String getAmountDueRemaining() {
    return (String)getAttributeInternal(8);
  }
  
  public void setAmountDueRemaining(String paramNumber) {
    setAttributeInternal(8, paramNumber);
  }
  
  protected Object getAttrInvokeAccessor(int paramInt, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        return getTrxNumber();
      case 1:
        return getCreationDate();
      case 2:
        return getAccountNumber();
      case 3:
        return getPartyName();
      case 4:
        return getToEmail();
      case 5:
        return getOrgId();
      case 6:
        return getViewAttr();
      case 7:
        return getAmountDueOriginal();
      case 8:
        return getAmountDueRemaining();
    } 
    return super.getAttrInvokeAccessor(paramInt, paramAttributeDefImpl);
  }
  
  protected void setAttrInvokeAccessor(int paramInt, Object paramObject, AttributeDefImpl paramAttributeDefImpl) throws Exception {
    switch (paramInt) {
      case 0:
        setTrxNumber((String)paramObject);
        return;
      case 1:
        setCreationDate((Date)paramObject);
        return;
      case 2:
        setAccountNumber((String)paramObject);
        return;
      case 3:
        setPartyName((String)paramObject);
        return;
      case 4:
        setToEmail((String)paramObject);
        return;
      case 5:
        setOrgId((Number)paramObject);
        return;
      case 6:
        setViewAttr((String)paramObject);
        return;
      case 7:
        setAmountDueOriginal((String)paramObject);
        return;
      case 8:
        setAmountDueRemaining((String)paramObject);
        return;
    } 
    super.setAttrInvokeAccessor(paramInt, paramObject, paramAttributeDefImpl);
  }
  
  public String getViewAttr() {
    return (String)getAttributeInternal(6);
  }
  
  public void setViewAttr(String paramString) {
    setAttributeInternal(6, paramString);
  }
  
  public Number getOrgId() {
    return (Number)getAttributeInternal(5);
  }
  
  public void setOrgId(Number paramNumber) {
    setAttributeInternal(5, paramNumber);
  }
}
