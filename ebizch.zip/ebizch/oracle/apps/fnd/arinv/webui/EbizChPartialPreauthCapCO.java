 /*===========================================================================+
   |   Copyright (c) 2001, 2005 Oracle Corporation, Redwood Shores, CA, USA    |
   |                         All rights reserved.                              |
   +===========================================================================+
   |  HISTORY                                                                  |
   +===========================================================================*/
 package ebizch.oracle.apps.fnd.arinv.webui;

 import ebizch.oracle.apps.fnd.arinv.server.EbizChArinvAMImpl;

 import ebizch.oracle.apps.fnd.arinv.server.EbizChPartialPreauthListVOImpl;

 import ebizch.oracle.apps.fnd.arinv.server.EbizChPartialPreauthListVORowImpl;

 import java.sql.CallableStatement;

 import java.sql.SQLException;

 import java.sql.Types;

 import oracle.apps.fnd.common.VersionInfo;
 import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
 import oracle.apps.fnd.framework.server.OADBTransactionImpl;
 import oracle.apps.fnd.framework.webui.OAControllerImpl;
 import oracle.apps.fnd.framework.webui.OAPageContext;
 import oracle.apps.fnd.framework.webui.beans.OAWebBean;

 import oracle.jbo.Row;
 import oracle.jbo.domain.Number;


 public class EbizChPartialPreauthCapCO extends OAControllerImpl {
     public static final String RCS_ID = "$Header$";
     public static final boolean RCS_ID_RECORDED =
         VersionInfo.recordClassVersion(RCS_ID, "%packagename%");

     public void processRequest(OAPageContext pageContext, OAWebBean webBean) {
         super.processRequest(pageContext, webBean);
         EbizChArinvAMImpl am = (EbizChArinvAMImpl) pageContext.getApplicationModule(webBean);
         am.initEbizChPartialCapVO();
     }


     public void processFormRequest(OAPageContext pageContext, OAWebBean webBean) {
         super.processFormRequest(pageContext, webBean);

         if (pageContext.getParameter("CaptureInvoices") != null) {
             int success_count = 0;
             int error_count = 0;
             String invNums = "";
             String messageValue = "";
             String SucinvNums = "";
			 int capture_count=0;

             EbizChArinvAMImpl am = (EbizChArinvAMImpl) pageContext.getApplicationModule(webBean);

             EbizChPartialPreauthListVOImpl invVo = am.getEbizChPartialPreauthListVO1();

             EbizChPartialPreauthListVORowImpl invRowVo = null;

             Row rows[] = invVo.getFilteredRows("ViewAttr", "Y");
             int rowsLength = rows.length;

             if (rowsLength > 0) {

                 for (int i = 0; i < rowsLength; i++) {

                     invRowVo = (EbizChPartialPreauthListVORowImpl) rows[i];

                     Number orderAmount = (Number) invRowVo.getAttribute("OrderAmount");
                     String saleOrder = (String) invRowVo.getAttribute("SaleOrder");
                     String accountNumber = (String) invRowVo.getAttribute("AccountNumber");
                     String invoiceNo = (String) invRowVo.getAttribute("InvoiceNo");
                     String preauthRefnum = (String) invRowVo.getAttribute("PreauthRefnum");
                     Number preAuthAmt = (Number) invRowVo.getAttribute("PreAuthAmt");
                     Number amountDueRemaining = (Number) invRowVo.getAttribute("AmountDueRemaining");

                     String[] validationsMessage = isValidate(accountNumber, saleOrder, invoiceNo, String.valueOf(amountDueRemaining), preauthRefnum, String.valueOf(preAuthAmt));

                     if (validationsMessage[0].equals("1")) {
                         messageValue = messageValue + validationsMessage[1];
                         invNums = validationsMessage[2] + ", " + invNums;
                     } else {
                         SucinvNums = validationsMessage[3] + ", " + SucinvNums;
                     }

                     if (validationsMessage[0].equals("1")) {
                         error_count++;
                     } else {
                         String[] getTrans = getTransaction(pageContext, webBean, preauthRefnum, accountNumber);

                         if (!"E".equals(getTrans[2])) {
                             if ("Authorized (Pending Settlement)".equals(getTrans[0]) && "Sale".equals(getTrans[1])) {
                                 updatePreauthCapture(pageContext, webBean, saleOrder,"","");
                                 success_count++;
								// capture_count++;
                             } else if ("Authorized (Will not be captured)".equals(getTrans[0]) && "Auth Only".equals(getTrans[1])) {
                                 String[] arrayOfString = runTransactionAmt(pageContext, webBean, saleOrder, String.valueOf(amountDueRemaining), accountNumber, preauthRefnum);
								 
                                 if (!arrayOfString[2].equals("E")) {
                                     updatePreauthCapture(pageContext, webBean, saleOrder,String.valueOf(arrayOfString[0]),String.valueOf(arrayOfString[1]));
                                     success_count++;
                                 } else {
                                     error_count++;

                                 }
                             } else {

                                 error_count++;
                             }
                         }
                     }
                     /*else if (Float.parseFloat(String.valueOf(preAuthAmt)) < Float.parseFloat(String.valueOf(orderAmount)) )
                     {
                         String[] arrayOfString = runTransactionAmt(pageContext, webBean, saleOrder, String.valueOf(preAuthAmt), accountNumber, preauthRefnum);
                         
                         if (!arrayOfString[0].equals("E"))
                         {
                             updatePreauthCapture(pageContext, webBean, saleOrder);
                             String[] arrayOfString1 = runCustomerTransaction(pageContext, webBean, saleOrder, String.valueOf(orderAmount));
                             if (!arrayOfString1[0].equals("E"))
                             {
                             updatePreauthCapture(pageContext, webBean, saleOrder);
                             success_count++;
                             }
                             else
                             {
                             error_count++;
                             
                             }
                         }
                   
                     }
                                     */

                 }
                 messageValue = getDistinctString(pageContext, webBean, messageValue);
                 if (success_count > 0 && error_count == 0) {
                     am.initEbizChPartialCapVO();
                     throw new OAException("Success: " + success_count + " invoices has been processed successfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() - 2), OAException.INFORMATION);
                 }
                 if (success_count == 0 && error_count > 0) {
                     am.initEbizChPartialCapVO();

                     if (!messageValue.equals("") || !messageValue.equals(null)) {
                         throw new OAException(error_count + " invoices has not been processed successfully because these fields '" + messageValue + "' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() - 2), OAException.ERROR);
                     } else {
                         throw new OAException("Error: " + error_count + " invoices has not been processed successfully against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() - 2), OAException.ERROR);
                     }
                 }
                 if (success_count > 0 && error_count > 0) {

                     if (!messageValue.equals("") || !messageValue.equals(null)) {
                         throw new OAException(success_count + " invoices has been processed sucessfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() - 2) + " and " + error_count + " invoices has not processed sucessfully because these fields '" + messageValue + "' were not found against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() - 2), OAException.WARNING);
                     } else {
                         throw new OAException("Success: " + success_count + " invoices has been processed sucessfully against your selected Invoice No.(s) " + SucinvNums.substring(0, SucinvNums.length() - 2) + " but " + error_count + "  invoices has not processed sucessfully against your selected Invoice No.(s) " + invNums.substring(0, invNums.length() - 2), OAException.WARNING);
                     }

                 }

             }

         }
     }
     // }
     public void updatePreauthCapture(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String orderNum,String refNum,String authCode) {
         OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
         CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.update_par_preauth_capture(:1,:2,:3); end;", OADBTransaction.DEFAULT);
         try {
             callableStatement.setString(1, orderNum);
			 callableStatement.setString(2, refNum);
			 callableStatement.setString(3, authCode);
             callableStatement.execute();
             callableStatement.close();
         } catch (SQLException sQLException) {
             String str = sQLException.getMessage();
             throw new OAException(str, OAException.ERROR);
         }
     }


     public String[] runTransactionAmt(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String orderNum, String inAmt, String inCustNum, String refNum) {
         String[] arrayOfString = new String[4];
         try {
             OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
             CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.run_transaction_pp(:1,:2,:3,:4,:5,:6,:7,:8); end;", OADBTransaction.DEFAULT);
             callableStatement.setString(1, orderNum);
             callableStatement.setString(2, inAmt);
             callableStatement.setString(3, inCustNum);
             callableStatement.setString(4, refNum);
             callableStatement.registerOutParameter(5, Types.VARCHAR);
             callableStatement.registerOutParameter(6, Types.VARCHAR);
			 callableStatement.registerOutParameter(7, Types.VARCHAR);
             callableStatement.registerOutParameter(8, Types.VARCHAR);
             callableStatement.execute();
             arrayOfString[0] = callableStatement.getString(5);
             arrayOfString[1] = callableStatement.getString(6);
			 arrayOfString[2] = callableStatement.getString(7);
             arrayOfString[3] = callableStatement.getString(8);
             callableStatement.close();
         } catch (SQLException sQLException) {
             throw new OAException("Error While Capturing the Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
         }
         return arrayOfString;
     }

     public String[] runCustomerTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String orderNum, String inAmt) {
         String[] arrayOfString = new String[2];
         try {
             OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
             CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.run_customer_transaction(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
             callableStatement.setString(1, orderNum);
             callableStatement.setString(2, inAmt);
             callableStatement.registerOutParameter(3, Types.VARCHAR);
             callableStatement.registerOutParameter(4, Types.VARCHAR);
             callableStatement.execute();
             arrayOfString[0] = callableStatement.getString(3);
             arrayOfString[1] = callableStatement.getString(4);
             callableStatement.close();
         } catch (SQLException sQLException) {
             throw new OAException("Error While Capturing the Customer Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
         }
         return arrayOfString;
     }

     public String[] getTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inrefnum, String inCustNum) {
         String[] arrayOfString = new String[4];
         try {
             OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
             CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.get_transaction_dup(:1,:2,:3,:4,:5,:6); end;", OADBTransaction.DEFAULT);

             callableStatement.setString(1, inrefnum);
             callableStatement.setString(2, inCustNum);

             callableStatement.registerOutParameter(3, Types.VARCHAR);
             callableStatement.registerOutParameter(4, Types.VARCHAR);
             callableStatement.registerOutParameter(5, Types.VARCHAR);
             callableStatement.registerOutParameter(6, Types.VARCHAR);
             callableStatement.execute();
             arrayOfString[0] = callableStatement.getString(3);
             arrayOfString[1] = callableStatement.getString(4);
             arrayOfString[2] = callableStatement.getString(5);
             arrayOfString[3] = callableStatement.getString(6);
             callableStatement.close();
         } catch (SQLException sQLException) {
             throw new OAException("Error While getting the Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
         }
         return arrayOfString;
     }

     public String[] isValidate(String CustomerNum, String orderNum, String invNumb, String amt, String refNum, String preAuthAmt) {
         String retMessage = "";
         String retValue = "null";
         String[] output = new String[4];
         output[0] = "0";
         if ("null".equals(String.valueOf(CustomerNum)) || "".equals(String.valueOf(CustomerNum))) {
             retMessage = retMessage + "Customer Id,";
         }

         if ("null".equals(String.valueOf(orderNum)) || "".equals(String.valueOf(orderNum))) {
             retMessage = retMessage + "Order No,";
         }

         if ("null".equals(String.valueOf(invNumb)) || "".equals(String.valueOf(invNumb))) {
             retMessage = retMessage + "Invoice Number,";
         }
         if ("null".equals(String.valueOf(amt)) || "".equals(String.valueOf(amt))) {
             retMessage = retMessage + "Invoice Amount,";
         }

         if ("null".equals(String.valueOf(refNum)) || "".equals(String.valueOf(refNum))) {
             retMessage = retMessage + "Reference No,";
         }

         if ("null".equals(String.valueOf(preAuthAmt)) || "".equals(String.valueOf(preAuthAmt))) {
             retMessage = retMessage + "Pre Auth Amount,";
         }

         if (retMessage != "") {
             output[0] = "1";
             retValue = retMessage;
             output[1] = retValue;
             output[2] = invNumb;
         } else if (retMessage == "") {

             output[0] = "0";
             output[1] = "Invoice data is validated.";
             output[3] = invNumb;
         }
         return output;
     }
     public String getDistinctString(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String message) {
         String myString = message;
         String[] myArray = myString.split(",");
         String arr[] = myArray;
         String messageValue = "";
         int n = arr.length;
         int i, j;
         for (i = 0; i < n; ++i) {
             for (i = 0; i < n; i++) {
                 for (j = 0; j < i; j++)
                     if (arr[i].equals(arr[j]))
                         break;
                 if (i == j) {
                     messageValue = messageValue + arr[i] + ", ";
                 }
             }

         }
         messageValue = messageValue.substring(0, messageValue.length() - 2);
         return messageValue;
     }
 }