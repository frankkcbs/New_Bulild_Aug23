package ebizch.oracle.apps.fnd.arinv.webui;

import ebizch.oracle.apps.fnd.arinv.server.EbizChArInvWoSOVOImpl;
import ebizch.oracle.apps.fnd.arinv.server.EbizChArInvWoSOVORowImpl;
import ebizch.oracle.apps.fnd.arinv.server.EbizChArinvAMImpl;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.sql.Types;

import oracle.apps.fnd.framework.OAException;
import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
import oracle.apps.fnd.framework.OARow;
import oracle.apps.fnd.framework.OARow;
import com.sun.java.util.collections.HashMap;

import oracle.apps.fnd.framework.webui.beans.message.OAMessageLovInputBean;

import oracle.jbo.Row;
import oracle.jbo.domain.Date;
import oracle.jbo.domain.Number;

public class EbizChWltInvWoSoCO extends OAControllerImpl
{

  public void processRequest(OAPageContext pageContext, OAWebBean webBean)
  {
    super.processRequest(pageContext, webBean);
    EbizChArinvAMImpl am = (EbizChArinvAMImpl) pageContext.getApplicationModule(webBean);   
    am.initEbizChArInvWoSOVO();
    String CustAccountNumber = ""  , CreditCard = "";
      EbizChArInvWoSOVOImpl invVo = am.getEbizChArInvWoSOVO1();
      EbizChArInvWoSOVORowImpl invRowVo = null;
      Row rows[] = invVo.getAllRowsInRange();// getFilteredRows("ViewAttr", "Y");
      int rowsLength = rows.length;

  }

  public void processFormRequest(OAPageContext pageContext, OAWebBean webBean)
  {
	        String lovEvent = pageContext.getParameter(EVENT_PARAM);  
			
    
    
	  if("lovPrepare".equals(lovEvent)) {  
		  String lovInputSourceId = pageContext.getLovInputSourceId();  
		  if("methodLovInput".equals(lovInputSourceId)) {  
				//OAFormValueBean mIdFvCustNum = (OAFormValueBean)webBean.findChildRecursive("mIdFv");
				//String mIdFvCustNumVal = (String) mIdFvCustNum.getValue(pageContext);
				EbizChArinvAMImpl am =
					(EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
				String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
				OARow currRow = (OARow)am.findRowByRef(rowReference);
				String attrValue = (String)currRow.getAttribute("AccountNumber");
				String[] ccLov = creditCardLov(pageContext, webBean, attrValue);
				currRow.setAttribute("ViewAttr5",null);
				currRow.setAttribute("ViewAttr6",null);
				currRow.setAttribute("ViewAttr7",null);
				
				  if(!ccLov[0].equals("S")){
					  throw new OAException("Credit Card List are not populated. Error Message: "+ccLov[1], OAException.ERROR);    
				  }
				 
		  } 

        if("methodLovInputBank".equals(lovInputSourceId)) {  
				//OAFormValueBean mIdFvCustNum = (OAFormValueBean)webBean.findChildRecursive("mIdFv");
				//String mIdFvCustNumVal = (String) mIdFvCustNum.getValue(pageContext);
				EbizChArinvAMImpl am =
					(EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
				String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
				OARow currRow = (OARow)am.findRowByRef(rowReference);
				String attrValue = (String)currRow.getAttribute("AccountNumber");
				String[] ccLov = creditCardLov(pageContext, webBean, attrValue);
				currRow.setAttribute("ViewAttr1",null);
				currRow.setAttribute("ViewAttr2",null);
				currRow.setAttribute("ViewAttr4",null);
				  if(!ccLov[0].equals("S")){
					  throw new OAException("Credit Card List are not populated. Error Message: "+ccLov[1], OAException.ERROR);    
				  }
				//throw new OAException("mIdFvCustNumVal: "+mIdFvCustNumVal+" attrValue: "+ attrValue, OAException.ERROR); 
		  }		  
		}
		
		 if(pageContext.isLovEvent())  {   
			String lovInputSourceId = pageContext.getLovInputSourceId();  
			if("methodLovInput".equals(lovInputSourceId)) {  
            
           EbizChArinvAMImpl am =
					(EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
				String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
				OARow currRow = (OARow)am.findRowByRef(rowReference);
				String attrValue = (String)currRow.getAttribute("ViewAttr1");
			    currRow.setAttribute("CcNumbers",attrValue);
               
				
		}
		
		if("methodLovInputBank".equals(lovInputSourceId)) {  
            
           EbizChArinvAMImpl am =
					(EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
				String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
				OARow currRow = (OARow)am.findRowByRef(rowReference);
				String attrValue = (String)currRow.getAttribute("ViewAttr5");
				currRow.setAttribute("CcNumbers",attrValue);
             
				
		}
	 }
	   
	   
	   
	  if ("Create".equals(pageContext.getParameter(EVENT_PARAM)))
	  {
		   pageContext.putSessionValue("Type", "Manual");
		   EbizChArinvAMImpl am =
					(EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
				String rowReference =  pageContext.getParameter(EVENT_SOURCE_ROW_REFERENCE);
				OARow currRow = (OARow)am.findRowByRef(rowReference);
				String attrValue = (String)currRow.getAttribute("AccountNumber");
		   HashMap vhashMap = new HashMap(1);
			vhashMap .put("CUST_NO", attrValue);
	   pageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChWltCreditCardPG&retainAM=Y", null, (byte)0, null, vhashMap, true, "Y", (byte)99);  
		
	 }
	  if (pageContext.getParameter("CreateCreditCard")!=null)
	  {
		  
		pageContext.setForwardURL("OA.jsp?page=/ebizch/oracle/apps/fnd/rtsync/webui/EbizChCreateCreditCardPG&retainAM=Y", null, (byte)0, null, null, true, "Y", (byte)99);    
		  
	  }
      if (pageContext.getParameter("processTranWoSO") != null) {
          int success_count = 0;
          int error_count = 0;
		  String cvv="";
          EbizChArinvAMImpl am =
            (EbizChArinvAMImpl)pageContext.getApplicationModule(webBean);
          EbizChArInvWoSOVOImpl invVo = am.getEbizChArInvWoSOVO1();
          EbizChArInvWoSOVORowImpl invRowVo = null;
          String excCollectAdd = " ";
          String messageValue ="";
          Row rows[] = invVo.getFilteredRows("ViewAttr", "Y");
          int rowsLength = rows.length;

          if (rowsLength > 0) {
            for (int i = 0; i < rowsLength; i++) {
                invRowVo = (EbizChArInvWoSOVORowImpl)rows[i];
              
			  if (invRowVo.getAttribute("ViewAttr3")!=null)
					{
						cvv = (String) invRowVo.getAttribute("ViewAttr3");
				
					}
					 else
					{
						cvv = "";
            
					} 
         
			   
              Number selectedInstrid = 
                  (Number)invRowVo.getAttribute("PaymentTrxnExtensionId");

              Number custId = 
                  (Number)invRowVo.getAttribute("CustAccountId");
              String custIdStr = custId.toString();

              Number invOrgId = (Number)invRowVo.getAttribute("OrgId");
              String invOrgIdStr = invOrgId.toString();


              String CustAccNoString = 
                  (String)invRowVo.getAttribute("AccountNumber");

              String invCustomerName = 
                  (String)invRowVo.getAttribute("Customername");

              String invNumb = 
                  (String)invRowVo.getAttribute("InvoiceNumber");

              Date invdate = (Date)invRowVo.getAttribute("InvDate");
              String invdateStr = invdate.toString();

              String invCurr = (String)invRowVo.getAttribute("Currency");

              Number invAmtDue = 
                  (Number)invRowVo.getAttribute("Balance");
              String invAmtDueStr = invAmtDue.toString();
       
              Number invInvoiceTo = 
                  (Number)invRowVo.getAttribute("BillToSiteUseId");

              Number invShipTo = 
                  (Number)invRowVo.getAttribute("ShipToSiteUseId");
				  
         		//  String paymethdId=(String)invRowVo.getAttribute("ViewAttr1");//CcNumbers
				  String paymethdId=(String)invRowVo.getAttribute("CcNumbers");
                
					String[] validationsMessage = new String[2];
					validationsMessage[0] = "0";
					validationsMessage[1] = "Invoice data is validated.";
                  if (validationsMessage[0].equals("1")) {
                    messageValue = messageValue + validationsMessage[1];
                  }
                     
                  if (validationsMessage[0].equals("1")){
                     error_count++; 
                  }
                  else{
					  
					   String[] sendinv=sendInvoice(pageContext, webBean, CustAccNoString,"",invOrgIdStr,invNumb);
					    if (sendinv[0]!="E" || !sendinv[0].equals("E"))
						  //if (true)
							{
								
								String gwToken= getGwTokenNo(pageContext, webBean, paymethdId,CustAccNoString );
								/*if(true){
									throw new OAException("Error gwToken: "+gwToken+" paymethdId: "+paymethdId+" CustAccNoString:"+CustAccNoString, OAException.ERROR);	
									}*/
							String[] runcusttrans=runCustomerTransaction(pageContext, webBean,invNumb,invAmtDueStr,gwToken,paymethdId,CustAccNoString,cvv);
							String RefNum="";
							String authCode="";
								if(runcusttrans[2]!=null){
									 RefNum=runcusttrans[2];
								}
								if (runcusttrans[3]!=null)
								{
									authCode=runcusttrans[3];
								}
							if (!"E".equals(runcusttrans[0]) )
							{
								
							if (insertlogs(pageContext,webBean, CustAccNoString,invCustomerName,invNumb,"Y",gwToken,RefNum,paymethdId,authCode))	
							{
							
							String retValue =ebizchreceipts(pageContext,webBean,invNumb,RefNum);
							if (retValue!="E")
                                 {	
							excCollectAdd = excCollectAdd + " Success: The Invoice " + 
                                            invNumb+ 
                                            " has processed sucessfully for the customer " + 
                                            invCustomerName + ".";
                                success_count++;
								}
							else
							  {			excCollectAdd = excCollectAdd + " Error: The Invoice " + 
																 invNumb + 
																  " has not processed sucessfully for the customer " + 
																 invCustomerName + ". Because Receipts has not been created in oracle" ;
												error_count++;
                                         }
							}
							   else
                                         {
												excCollectAdd = excCollectAdd + " Error: The Invoice " + 
																 invNumb + 
																  " has not processed sucessfully for the customer " + 
																 invCustomerName + "." ;
												error_count++;
                                         }
							}
							else
							{
							if (insertlogs(pageContext,webBean, CustAccNoString,invCustomerName,invNumb,"N",gwToken,RefNum,paymethdId,authCode))
							{
							excCollectAdd = 
                              excCollectAdd + " Error: The Invoice " + 
                             invNumb + 
                              " has not processed sucessfully for the customer " + 
                             invCustomerName + ".";
                              error_count++;	
							}								
							  	
							}
							}
							else
							{
							throw new OAException("Error while syncing the transactions details.", OAException.ERROR);	
								
							}
                  }
              }
              /*
              if(success_count ==  1 ){
				  am.initEbizChArInvWoSOVO(); 
              throw new OAException(excCollectAdd, OAException.INFORMATION);
              }
              
              if(error_count == 1 ){
                  if (!messageValue.equals("") ||!messageValue.equals(null))
                      {
						  am.initEbizChArInvWoSOVO(); 
                          throw new OAException(messageValue, OAException.ERROR);
                        }
                        else
                        {
							am.initEbizChArInvWoSOVO(); 
                        throw new OAException(excCollectAdd, OAException.ERROR);
                        }
              }*/
              
              if(success_count > 0 && error_count <= 0){
				  am.initEbizChArInvWoSOVO(); 
                  throw new OAException("The "+ success_count +" Invoice(s) has been processed sucessfully.", OAException.INFORMATION);
              }
              
              if(success_count <= 0 && error_count > 0){
                  //if (!messageValue.equals("") ||!messageValue.equals(null))
					  if (messageValue!="")
                  {
					  am.initEbizChArInvWoSOVO(); 
                      throw new OAException(error_count +" Invoice(s) has not been processed sucessfully. "+"Because" + messageValue , OAException.ERROR);
                  }
                  else
                  {
					  am.initEbizChArInvWoSOVO(); 
                      throw new OAException(error_count +" Invoice(s) has not been processed sucessfully.", OAException.ERROR);
                  }
                  
              }
              
              if(success_count > 1 && error_count > 1){
                  //if (!messageValue.equals("") ||!messageValue.equals(null))
                   if (messageValue!="")
				  {
					  am.initEbizChArInvWoSOVO(); 
                      throw new OAException(success_count +" Invoice(s) has been processed sucessfully but the "+ error_count +" Invoice(s) has not processed sucessfully. " + "Because" + messageValue, OAException.WARNING);
                  }
                  else
                  {
					  am.initEbizChArInvWoSOVO(); 
                      throw new OAException(success_count +" Invoice(s) has processed sucessfully but the "+ error_count +" Invoice(s) has not processed sucessfully.", OAException.WARNING);
                  }
                  
              }
           // am.initEbizChArInvWoSOVO();  
          }
          
      }
    super.processFormRequest(pageContext, webBean);
  }
  
	  
	    public boolean insertlogs(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean,String CustId,String custName,String invNumb,String invFlag,String gwCustNum,String RefNum,String PaymethodId,String authCode)
               {
               try{
                        String userId = String.valueOf(paramOAPageContext.getUserId());
                                       int userIdInt = Integer.parseInt(userId);
                       
                   OADBTransactionImpl txnAddPayMethod = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                   CallableStatement stmtAddPayMethod =  txnAddPayMethod.createCallableStatement("begin  EBIZCH_WLT_MANUAL_INV_PKG.INSERT_INVOICES_LOG(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;", 
                                                                                                     OADBTransaction.DEFAULT);
                   stmtAddPayMethod.setString(1, CustId);
                   stmtAddPayMethod.setString(2, custName);
                   stmtAddPayMethod.setString(3, invNumb);
                   stmtAddPayMethod.setString(4, invFlag);
				    stmtAddPayMethod.setString(5, gwCustNum);
                   stmtAddPayMethod.setString(6, RefNum);
                   stmtAddPayMethod.setString(7, PaymethodId);
                   stmtAddPayMethod.setInt(8, userIdInt);
                   stmtAddPayMethod.setInt(9, userIdInt);
				   stmtAddPayMethod.setString(10, authCode);
                               
                                   
                   stmtAddPayMethod.execute();
                   stmtAddPayMethod.close();
                   return true;
                   }
               catch(SQLException e){
                   e.getMessage();
                    throw new OAException("Error while inserting invoice log. Error Message " + e.getMessage(), OAException.INFORMATION);
                  }
               
               }
			    public String[] runCustomerTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String invNumb,String inamt,String gwToken,String payMethodId,String CustAccNoString,String cvv){
                 String[] runTransDetails = new String[4]; 
                 CallableStatement stmtTransAddDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       stmtTransAddDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.run_customer_transaction(:1,:2,:3,:4,:5,:6,:7,:8,:9,:10); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       stmtTransAddDetails.setString(1, invNumb);
									   stmtTransAddDetails.setString(2, inamt);
									   stmtTransAddDetails.setString(3, gwToken);
									   stmtTransAddDetails.setString(4, payMethodId);
									   stmtTransAddDetails.setString(5, CustAccNoString);
									    stmtTransAddDetails.setString(6, cvv);
                                       stmtTransAddDetails.registerOutParameter(7, Types.VARCHAR);
                                       stmtTransAddDetails.registerOutParameter(8, Types.VARCHAR);
                                       stmtTransAddDetails.registerOutParameter(9, Types.VARCHAR);
									   stmtTransAddDetails.registerOutParameter(10, Types.VARCHAR);
                                       stmtTransAddDetails.execute();
                                       
                                       runTransDetails[0] = stmtTransAddDetails.getString(7);
                                       runTransDetails[1] = stmtTransAddDetails.getString(8);
                                       runTransDetails[2] = stmtTransAddDetails.getString(9);
									   runTransDetails[3] = stmtTransAddDetails.getString(10);
									   
                                       stmtTransAddDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While Capturing the Customer Transaction Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return runTransDetails;
     } 

  public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String custNum,String inSO,String orgId,String invNum){
                 String[] sendInvDetails = new String[2]; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.send_invoice(:1,:2,:3,:4,:5,:6); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      sendInvoiceDetails.setString(1, custNum);
                                      sendInvoiceDetails.setString(2, inSO);
                                      sendInvoiceDetails.setString(3, orgId);
                                      sendInvoiceDetails.setString(4, invNum);
                                       sendInvoiceDetails.registerOutParameter(5, Types.VARCHAR);
                                       sendInvoiceDetails.registerOutParameter(6, Types.VARCHAR);
									   
                                      sendInvoiceDetails.execute();
                                       
                                       sendInvDetails[0] = sendInvoiceDetails.getString(5);
                                       sendInvDetails[1] = sendInvoiceDetails.getString(6);
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While Sending the invoice into the gateway Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return sendInvDetails;
     }  
	 public String getGwTokenNo(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String PayMethodId, String custNo){
                 String gwTokenNo = ""; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.get_gw_token_no(:1,:2,:3); end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      sendInvoiceDetails.setString(1, custNo);
                                      sendInvoiceDetails.setString(2, PayMethodId);
                                       sendInvoiceDetails.registerOutParameter(3, Types.VARCHAR);
									   
                                      sendInvoiceDetails.execute();
                                       
                                       gwTokenNo = sendInvoiceDetails.getString(3);
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the gateway token no Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return gwTokenNo;
     }  
	 public String updateCreditCards(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean){
                 String gwTokenNo = ""; 
                 CallableStatement sendInvoiceDetails;
                 try {
                       OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                       sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin   EBIZCH_WLT_CC_LOV_PKG.insert_cc_man_inv; end;",
                                               OADBTransaction.DEFAULT);
                                       
                                       
                                             
                                      
									   
                                      sendInvoiceDetails.execute();
                                       
									   
                                       sendInvoiceDetails.close();   
                                       
                   } catch (SQLException e) {
                       throw new OAException("Error While getting the gateway token no Error Message:" + e.getMessage(), OAException.INFORMATION);
                   }
                               
                               return gwTokenNo;
     }   
     
     
    public String getCreditCard(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean , String custNo){
        String CardNum = "";
        String[] sendInvDetails = new String[2]; 
        CallableStatement sendInvoiceDetails;
            try {
                  OADBTransactionImpl TransactionAddDetails = (OADBTransactionImpl) paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
                                  sendInvoiceDetails = TransactionAddDetails.createCallableStatement("begin  xx_get_creditcard(:1,:2); end;",
                                          OADBTransaction.DEFAULT);
                  sendInvoiceDetails.setString(1, custNo);
                  sendInvoiceDetails.registerOutParameter(2, Types.VARCHAR);                                                                         
                  sendInvoiceDetails.execute();
                  CardNum = sendInvoiceDetails.getString(2);           
                  sendInvoiceDetails.close();   
                                  
              } catch (SQLException e) {
                  throw new OAException("Error While getting the Credit Card For lov Error Message:" + e.getMessage(), OAException.INFORMATION);
              }
                          
                          return CardNum;
    }
     
    public String[] isValidate(String custId,String custName,String invoiceNumb,String invoiceDate,String orgId,String curr,String Invamt,String invdueDate,
                                String amtDue,String sft,String taxAmt,String billToSiteUseId,String ShipToSiteUseId,String extId,String accId) {
      String retMessage = "";
      String retValue = "null";
      String[] output = new String[2];
      output[0] = "0";
      if ("null".equals(String.valueOf(custId)) || "".equals(String.valueOf(custId))) {
        retMessage = retMessage + "Customer Id,";
      }

      if ("null".equals(String.valueOf(custName)) || "".equals(String.valueOf(custName))) {
        retMessage = retMessage + "Customer Name,";
      }

      if ("null".equals(String.valueOf(invoiceNumb)) || "".equals(String.valueOf(invoiceNumb))) {
        retMessage = retMessage + "Invoice Number,";
      }

      if ("null".equals(String.valueOf(invoiceDate)) || "".equals(String.valueOf(invoiceDate))) {
        retMessage = retMessage + "Invoice Date,";
      }
      if ("null".equals(String.valueOf(orgId)) || "".equals(String.valueOf(orgId))) {
        retMessage = retMessage + "Invoice Org Id,";
      }
      if ("null".equals(String.valueOf(curr)) || "".equals(String.valueOf(curr))) {
        retMessage = retMessage + "Currency,";
      }

      if ("null".equals(String.valueOf(Invamt)) || "".equals(String.valueOf(Invamt))) {
        retMessage = retMessage + "Invoice Amount,";
      }
      
      if ("null".equals(String.valueOf(invdueDate)) || "".equals(String.valueOf(invdueDate)))  {
          retMessage = retMessage + "Invoice Due Date,";
        }  
        
      if ("null".equals(String.valueOf(amtDue)) || "".equals(String.valueOf(amtDue)))  {
        retMessage = retMessage + "Amount Due,";
      }

       if ("null".equals(String.valueOf(sft)) || "".equals(String.valueOf(sft)))  {
         retMessage = retMessage + "Software,";
       }
        if ("null".equals(String.valueOf(taxAmt)) || "".equals(String.valueOf(taxAmt)))  {
          retMessage = retMessage + "Total Tax Amount,";
        }
        if ("null".equals(String.valueOf(billToSiteUseId)) || "".equals(String.valueOf(billToSiteUseId)))  {
          retMessage = retMessage + "Bill to Use Id,";
        }
        if ("null".equals(String.valueOf(ShipToSiteUseId)) || "".equals(String.valueOf(ShipToSiteUseId)))  {
          retMessage = retMessage + "Ship to use id,";
        }
        if ("null".equals(String.valueOf(extId)) || "".equals(String.valueOf(extId)))  {
          retMessage = retMessage + "Payment Extension Id,";
        }
        if ("null".equals(String.valueOf(accId)) || "".equals(String.valueOf(accId)))  {
          retMessage = retMessage + "Customer Account id,";
        }
      if (retMessage!="") {
        output[0] = "1";
        retValue = retMessage + "are not found against your selected Invoice No" + " : " + invoiceNumb + " . ";
        output[1] = retValue;
      } else if (retMessage=="") {

        output[0] = "0";
        output[1] = "Invoice data is validated.";
      }
      return output;
    }
	
	
    public String[] creditCardLov(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNo)
    {
    
    String[] resp = new String[2];
    
    OADBTransactionImpl txn = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement =  txn.createCallableStatement("begin  EBIZCH_WLT_CC_LOV_PKG.INSERT_CUSTOMER_CC_LOCALLY(:1,:2,:3); end;",
                                                    OADBTransaction.DEFAULT);
      try { 
          callableStatement.setString(1, inCustNo);
          callableStatement.registerOutParameter(2, Types.VARCHAR);  
          callableStatement.registerOutParameter(3, Types.VARCHAR);  
              
          
          callableStatement.execute();  
          
          resp[0] = callableStatement.getString(2);    
          resp[1] = callableStatement.getString(3);    
          callableStatement.close();
          return resp;
      }
      catch(SQLException e){
                          
          throw new OAException("creditCardLov: " + e.getMessage(), OAException.INFORMATION);
      }
    
    }
	    public String ebizchreceipts(OAPageContext paramOAPageContext,
                                 OAWebBean paramOAWebBean,String invnum, String inRefNum ) {

            CallableStatement stmtInertGwPayToLocaldb;
            try {
                OADBTransactionImpl txnGetPayAddDetails =
                    (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();

                stmtInertGwPayToLocaldb = txnGetPayAddDetails.createCallableStatement("begin  ebizch_wlt_manual_inv_pkg.ebiz_cash_receipts_vone(:1,:2,:3); end;",
                                                                                      OADBTransaction.DEFAULT);
				stmtInertGwPayToLocaldb.registerOutParameter(3,Types.VARCHAR);
                stmtInertGwPayToLocaldb.setString(1, invnum);
				stmtInertGwPayToLocaldb.setString(2, inRefNum);
                stmtInertGwPayToLocaldb.execute();
                String retValue=stmtInertGwPayToLocaldb.getString(3);
                stmtInertGwPayToLocaldb.close();
                 return retValue;
            } catch (SQLException e) {
                throw new OAException("Error from database: " + e.getMessage(),
                                      OAException.ERROR);
            }
        }
}
