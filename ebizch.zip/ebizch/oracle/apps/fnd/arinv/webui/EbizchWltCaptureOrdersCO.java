package ebizch.oracle.apps.fnd.arinv.webui;

import ebizch.oracle.apps.fnd.arinv.server.EbizChArinvAMImpl;
import ebizch.oracle.apps.fnd.arinv.server.EbizChCaptureOrdersVOImpl;
import ebizch.oracle.apps.fnd.arinv.server.EbizChCaptureOrdersVORowImpl;
import ebizch.oracle.apps.fnd.arinv.webui.EbizChAuthorization;

import java.sql.CallableStatement;
import java.sql.SQLException;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.OAException;
 import oracle.apps.fnd.framework.server.OADBTransaction;
import oracle.apps.fnd.framework.server.OADBTransactionImpl;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.jbo.Row;
 import oracle.apps.fnd.framework.webui.beans.form.OAFormValueBean;
 import java.sql.Types;

import oracle.apps.fnd.framework.server.OAViewObjectImpl;

public class EbizchWltCaptureOrdersCO extends OAControllerImpl {
       public static final String RCS_ID = "$Header$";
     public static final boolean RCS_ID_RECORDED =VersionInfo.recordClassVersion(RCS_ID, "%packagename%");
  
  public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    super.processRequest(paramOAPageContext, paramOAWebBean);
    EbizChArinvAMImpl ebizChArinvAMImpl = (EbizChArinvAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
    ebizChArinvAMImpl.initEbizChCaptureOrdersVO();
  }
  
  public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    EbizChArinvAMImpl ebizChArinvAMImpl = (EbizChArinvAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
    EbizChCaptureOrdersVOImpl ebizChCaptureOrdersVOImpl = ebizChArinvAMImpl.getEbizChCaptureOrdersVO1();
	
    int success_count = 0;
    int error_count = 0;
	String holdId ="";
	String holdtype="";
	String holdtypeid="";
    String orderAmount = "";

 
   // String invAmount = "";
  //  String prosInvAmount = "";
	
    if (paramOAPageContext.getParameter("CaptureOrders") != null || paramOAPageContext.getParameter("Retry") != null)
      if (ebizChCaptureOrdersVOImpl != null) {
        Row[] arrayOfRow = ebizChCaptureOrdersVOImpl.getFilteredRows("selectFlag", "Y");
        int rowsLength = arrayOfRow.length;
		
        if (rowsLength > 0)
          for (int i = 0; i < rowsLength; i++) {
            EbizChCaptureOrdersVORowImpl ebizChCaptureOrdersVORowImpl = null;
            ebizChCaptureOrdersVORowImpl = (EbizChCaptureOrdersVORowImpl)arrayOfRow[i];

            EbizChAuthorization ebizChAuthorization = new EbizChAuthorization();
			
            String inSO = (String)ebizChCaptureOrdersVORowImpl.getAttribute("SaleOrder");
            orderAmount = ebizChCaptureOrdersVORowImpl.getAttribute("OrderAmount").toString();
            String customerNumber = (String)ebizChCaptureOrdersVORowImpl.getAttribute("AccountNumber");
            String refNum = (String)ebizChCaptureOrdersVORowImpl.getAttribute("PreauthRefnum");
			holdId = (String)ebizChCaptureOrdersVORowImpl.getAttribute("HoldId");
			holdtypeid = (String)ebizChCaptureOrdersVORowImpl.getAttribute("holdTypeId");
		//	if ((holdId.equals("0") || holdId.equals("") || holdId.equals("null")) && (!"null".equals(holdtypeid) || !"".equals(holdtypeid) ||holdtypeid!="null"))
		//	if ((holdId=="0" || holdId=="null" || holdId=="" ) && (holdtypeid!="null" || holdtypeid!=""))	
				
		if("0".equals(holdId) || "null".equals(holdId) ) 
			{
				
				holdtypeid = (String)ebizChCaptureOrdersVORowImpl.getAttribute("holdTypeId");
				
				//holdtype = (String)ebizChCaptureOrdersVORowImpl.getAttribute("holdType");	
				holdId=holdtypeid;
				//throw new OAException("holdIdaa -> " + holdId + " holdtype ->" + holdtype + " holdtypeid ->" +holdtypeid,OAException.ERROR);
				
			}
		   /* if (true)
			{
				throw new OAException("holdId -> " + holdId + " holdtype ->" + holdtype + " holdtypeid ->" +holdtypeid,OAException.ERROR);
				
			}*/
				String[]  gettrans=getTransaction(paramOAPageContext, paramOAWebBean, refNum, customerNumber);
				if(!"Sale".equals(gettrans[1]))
				{
			
            String[] arrayOfString = runTransactionAmt(paramOAPageContext, paramOAWebBean, inSO, orderAmount, customerNumber, refNum ,holdId);
			
            if (!arrayOfString[0].equals("E")) {
             updatePreauthCapture(paramOAPageContext, paramOAWebBean, inSO);
			 success_count++;
			  /*String retValue =ebizchreceipts(paramOAPageContext,paramOAWebBean,invoiceNo);
               if (retValue!="E")
					{	
					success_count++;
					}
				else
					{
					error_count++;
					}*/
            } else {
              error_count++;
            } 
			
			 } 
			 else
			{
			 error_count++;	
			}
		  }
            if (success_count > 0 && error_count < 1) {
				  
              ebizChArinvAMImpl.initEbizChCaptureOrdersVO();
			  Row rows[] = ebizChCaptureOrdersVOImpl.getAllRowsInRange();  
				  for(Row row : rows){  
					   row.setAttribute("selectFlag","N");  
				  } 
              throw new OAException("Success: " + success_count + " transactions have been captured.", OAException.INFORMATION);
            } 
            if (success_count < 1 && error_count > 0) {
				
              ebizChArinvAMImpl.initEbizChCaptureOrdersVO();
			  Row rows[] = ebizChCaptureOrdersVOImpl.getAllRowsInRange();    
				  for(Row row : rows){  
					   row.setAttribute("selectFlag","N");  
				  }
              throw new OAException("Error: " + error_count + " transactions have not been captured.", OAException.ERROR);
            } 
            if (success_count > 0 && error_count > 0) {
			  ebizChArinvAMImpl.initEbizChCaptureOrdersVO();
			  Row rows[] = ebizChCaptureOrdersVOImpl.getAllRowsInRange();    
				  for(Row row : rows){  
					   row.setAttribute("selectFlag","N");  
				  }
              throw new OAException("Success: " + success_count + " transactions have been captured but " + error_count + " transactions have not been captured", OAException.WARNING);
            } 
          
      }  
    super.processFormRequest(paramOAPageContext, paramOAWebBean);
  }
  
  public void updatePreauthCapture(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSO) {
    OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
    CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.update_preauth_capture(:1); end;", OADBTransaction.DEFAULT);
    try {
      callableStatement.setString(1, inSO);
      callableStatement.execute();
      callableStatement.close();
    } catch (SQLException sQLException) {
      String str = sQLException.getMessage();
      throw new OAException(str, OAException.ERROR);
    } 
  }
  
  public String[] getTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inRefNum, String inCustNum) {
    String[] arrayOfString = new String[4];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.get_transaction_dup(:1,:2,:3,:4,:5,:6); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inRefNum);
      callableStatement.setString(2, inCustNum);
      callableStatement.registerOutParameter(3, Types.VARCHAR);
      callableStatement.registerOutParameter(4, Types.VARCHAR);
      callableStatement.registerOutParameter(5, Types.VARCHAR);
	  callableStatement.registerOutParameter(6, Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(3);
      arrayOfString[1] = callableStatement.getString(4);
      arrayOfString[2] = callableStatement.getString(5);
	  arrayOfString[3] = callableStatement.getString(6);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While getting the Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return arrayOfString;
  }
  
  public String[] runTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSo) {
    String[] arrayOfString = new String[2];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.run_transaction(:1,:2,:3); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inSo);
      callableStatement.registerOutParameter(2, Types.VARCHAR);
      callableStatement.registerOutParameter(3, Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(2);
      arrayOfString[1] = callableStatement.getString(3);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While Capturing the Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return arrayOfString;
  }
  
  public String[] runCustomerTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSo, String inAmt) {
    String[] arrayOfString = new String[2];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.run_customer_transaction(:1,:2,:3,:4); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inSo);
      callableStatement.setString(2, inAmt);
      callableStatement.registerOutParameter(3, Types.VARCHAR);
      callableStatement.registerOutParameter(4, Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(3);
      arrayOfString[1] = callableStatement.getString(4);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While Capturing the Customer Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return arrayOfString;
  }
  
  public String[] sendInvoice(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inCustNum, String inSo, String inOrg, String inInvoice) {
    String[] arrayOfString = new String[2];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.send_invoice(:1,:2,:3,:4,:5,:6); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inCustNum);
      callableStatement.setString(2, inSo);
      callableStatement.setString(3, inOrg);
      callableStatement.setString(4, inInvoice);
      callableStatement.registerOutParameter(5, Types.VARCHAR);
      callableStatement.registerOutParameter(6, Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(5);
      arrayOfString[1] = callableStatement.getString(6);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While Sending the invoice into the gateway Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return arrayOfString;
  }
  
  public String[] voidTransaction(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inRefNum) {
    String[] arrayOfString = new String[2];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.void_transaction(:1,:2,:3); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inRefNum);
      callableStatement.registerOutParameter(2,Types.VARCHAR);
      callableStatement.registerOutParameter(3,Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(2);
      arrayOfString[1] = callableStatement.getString(3);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While voiding the Transaction Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return arrayOfString;
  }
  
  
  public String getHeaderId(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSO) {
    String str = "";
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.get_header_id(:1,:2); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inSO);
      callableStatement.registerOutParameter(2, Types.VARCHAR);
      callableStatement.execute();
      str = callableStatement.getString(2);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While getting header Id Error Message:" + sQLException.getMessage(), OAException.ERROR);
    } 
    return str;
  }
  
  public String[] runTransactionAmt(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean, String inSo, String inAmt, String inCustNum, String inAuthCode ,String inHoldId) {
    String[] arrayOfString = new String[2];
    try {
      OADBTransactionImpl oADBTransactionImpl = (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();
      CallableStatement callableStatement = oADBTransactionImpl.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.run_transaction_so(:1,:2,:3,:4,:5,:6,:7); end;", OADBTransaction.DEFAULT);
      callableStatement.setString(1, inSo);
      callableStatement.setString(2, inAmt);
      callableStatement.setString(3, inCustNum);
      callableStatement.setString(4, inAuthCode);
	  callableStatement.setString(5, inHoldId);
      callableStatement.registerOutParameter(6, Types.VARCHAR);
      callableStatement.registerOutParameter(7, Types.VARCHAR);
      callableStatement.execute();
      arrayOfString[0] = callableStatement.getString(6);
      arrayOfString[1] = callableStatement.getString(7);
      callableStatement.close();
    } catch (SQLException sQLException) {
      throw new OAException("Error While Capturing the Transaction Error Message:" + sQLException.getMessage(),OAException.ERROR);
    } 
    return arrayOfString;
  }
    public String ebizchreceipts(OAPageContext paramOAPageContext,
                                 OAWebBean paramOAWebBean,String invnum ) {

            CallableStatement stmtInertGwPayToLocaldb;
            try {
                OADBTransactionImpl txnGetPayAddDetails =
                    (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();

                stmtInertGwPayToLocaldb = txnGetPayAddDetails.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.ebiz_cash_receipts(:1,:2); end;",
                                                                                      OADBTransaction.DEFAULT);
				stmtInertGwPayToLocaldb.registerOutParameter(2,Types.VARCHAR);
                stmtInertGwPayToLocaldb.setString(1, invnum);
                stmtInertGwPayToLocaldb.execute();
                String retValue=stmtInertGwPayToLocaldb.getString(2);
                stmtInertGwPayToLocaldb.close();
                 return retValue;
            } catch (SQLException e) {
                throw new OAException("Error from database: " + e.getMessage(),
                                      OAException.ERROR);
            }
        }
		
		public String getHoldStatus(OAPageContext paramOAPageContext,
									OAWebBean paramOAWebBean,String inSO ) {

            CallableStatement stmtInertGwPayToLocaldb;
            try {
                OADBTransactionImpl txnGetPayAddDetails =
                    (OADBTransactionImpl)paramOAPageContext.getApplicationModule(paramOAWebBean).getOADBTransaction();

                stmtInertGwPayToLocaldb = txnGetPayAddDetails.createCallableStatement("begin  ebizch_wlt_preauth_process_pkg.ebizch_check_status(:1,:2); end;",
                                                                                      OADBTransaction.DEFAULT);
				stmtInertGwPayToLocaldb.registerOutParameter(2,Types.VARCHAR);
                stmtInertGwPayToLocaldb.setString(1, inSO);
                stmtInertGwPayToLocaldb.execute();
                String retValue=stmtInertGwPayToLocaldb.getString(2);
                stmtInertGwPayToLocaldb.close();
                 return retValue;
            } catch (SQLException e) {
                throw new OAException("Error from database: " + e.getMessage(),
                                      OAException.ERROR);
            }
        }
		
		
}
