package ebizch.oracle.apps.fnd.arinv.webui;

import ebizch.oracle.apps.fnd.arinv.server.EbizChArinvAMImpl;
import ebizch.oracle.apps.fnd.arinv.webui.EbizChCaptureInvoicesLogCO;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;
import oracle.apps.fnd.framework.webui.beans.message.OAMessageTextInputBean;
import oracle.cabo.style.CSSStyle;


public class EbizChCaptureInvoicesLogCO extends OAControllerImpl {
  public static final String RCS_ID = "$Header$";
  
  public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header$", "%packagename%");
  
  public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    super.processRequest(paramOAPageContext, paramOAWebBean);
    EbizChArinvAMImpl ebizChArinvAMImpl = (EbizChArinvAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
    ebizChArinvAMImpl.initEbizChCaptureInvoicesLogVO();
    ebizChArinvAMImpl.initEbizChCaptureInvoicesLogLinesVO();
	
				CSSStyle csNum = new CSSStyle();
                csNum.setProperty("display", "block");
                csNum.setProperty("text-align", "right");
                OAMessageTextInputBean omstb12 =(OAMessageTextInputBean)paramOAWebBean.findChildRecursive("OrderAmount1");
				 OAMessageTextInputBean omstb13 =(OAMessageTextInputBean)paramOAWebBean.findChildRecursive("AmountDueRemaining1");
				  OAMessageTextInputBean omstb1 =(OAMessageTextInputBean)paramOAWebBean.findChildRecursive("RAmount");
				omstb1.setInlineStyle(csNum);
				omstb12.setInlineStyle(csNum);
				omstb13.setInlineStyle(csNum);
  }
  
  public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    super.processFormRequest(paramOAPageContext, paramOAWebBean);
  }
}