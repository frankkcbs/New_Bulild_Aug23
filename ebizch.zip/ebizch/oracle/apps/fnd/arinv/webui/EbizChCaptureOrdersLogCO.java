package ebizch.oracle.apps.fnd.arinv.webui;

import ebizch.oracle.apps.fnd.arinv.server.EbizChArinvAMImpl;
import oracle.apps.fnd.common.VersionInfo;
import oracle.apps.fnd.framework.webui.OAControllerImpl;
import oracle.apps.fnd.framework.webui.OAPageContext;
import oracle.apps.fnd.framework.webui.beans.OAWebBean;

public class EbizChCaptureOrdersLogCO extends OAControllerImpl {
  public static final String RCS_ID = "$Header$";
  
  public static final boolean RCS_ID_RECORDED = VersionInfo.recordClassVersion("$Header$", "%packagename%");
  
  public void processRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    super.processRequest(paramOAPageContext, paramOAWebBean);
    EbizChArinvAMImpl ebizChArinvAMImpl = (EbizChArinvAMImpl)paramOAPageContext.getApplicationModule(paramOAWebBean);
    ebizChArinvAMImpl.initEbizChCaptureOrdersLogVO();
  }
  
  public void processFormRequest(OAPageContext paramOAPageContext, OAWebBean paramOAWebBean) {
    super.processFormRequest(paramOAPageContext, paramOAWebBean);
  }
}
